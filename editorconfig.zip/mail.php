<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
include 'db.php';
$mail = new PHPMailer(true);

 try {
    $date = date('Y-m-d');
    $day_before = date( 'm/d/Y', strtotime( $date . ' +1 day' ));
    $query = "SELECT * FROM `sales` WHERE nextCommitedDate = '".$day_before."' and coursePriceRemain > 0";
    $result = mysqli_query($db, $query);
    foreach($result as $row){
        $studentDetails = "SELECT * FROM `students` WHERE studentId = ".$row['studentId'];
        $resultRow = mysqli_query($db, $studentDetails);
        $rowStudent = mysqli_fetch_assoc($resultRow);
        if($rowStudent['studentEmail'] != ''){
            $email = $rowStudent['studentEmail'];
        }
        //Batch Details
        $batchDetails = "SELECT * FROM `batches` WHERE batchId = ".$row['batchId'];
        $resultBatch = mysqli_query($db, $batchDetails);
        $rowBatch = mysqli_fetch_assoc($resultBatch);
        
        //Course Details
        $courseDetails = "SELECT * FROM `courses` WHERE courseId = ".$rowBatch['courseId'];
        $resultCourse = mysqli_query($db, $courseDetails);
        $rowCourse = mysqli_fetch_assoc($resultCourse);
        
        //SR Name
        $SRDetails = "SELECT * FROM `users` WHERE userId = ".$row['userId'];
        $resultSR = mysqli_query($db, $SRDetails);
        $rowSR = mysqli_fetch_assoc($resultSR);
        
        $mail->SMTPDebug = 1;
        $mail->isSMTP();
        //$mail->Mailer = "smtp";
        $mail->SMTPAuth = true;
        $mail->SMTPSecure = "ssl";
        $mail->Port = 465;
        $mail->Host = "sg1-ss3.a2hosting.com";//"smtp.gmail.com";
        $mail->Username = "reminder@thebatraanumerology.com";
        $mail->Password = "@#India2020";
        $Mail->Priority = 1;
        //Recipients
        $mail->setFrom('reminder@thebatraanumerology.com', 'The Batraa Numerology');
        $mail->addAddress('resourcebyte.shrivastava@gmail.com', 'Aabhishek Shrivasstava');
        //$mail->addAddress($email, $rowBatch['studentName']);
        $mail->addCC('thebatraanumerology@gmail.com', 'The Batra Numerology');
        $mail->addCC($rowSR['userEmail'], $rowSR['userName']);
        $mail->isHTML(true);
        $mail->Subject = 'Your Pending payment amount : '.$row['coursePriceRemain'].' dated : '.$day_before;
        $content = "This Student ".$rowStudent['studentName']." payment ".$row['coursePriceRemain']." is pending.<br/><br/>";
        $content .= "<strong>Some other details are: </strong><br/><br/>";
        $content .= "Course Name: ".$rowCourse['courseName']."<br/><br/>";
        $content .= "Sales Representative Name: ".$rowSR['userName']."<br/><br/>";
        $content .= "Committed Date: ".$row['nextCommitedDate']."<br/><br/>";
        $content .= "Total Amount that is pending: ".$row['coursePriceRemain']."<br/><br/>";
        $content .= "Last Transaction Date: ".$row['transactionDate']."<br/><br/>";
        $mail->Body = $content;
        $mail->send();
        echo 'Message has been sent';
    }
    
}catch(Exception $e){
    echo 'Message Could not be sent.';
    echo 'Mailer Error: '.$mail->ErrorInfo;
}