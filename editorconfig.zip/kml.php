<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" integrity="sha384-....">
  <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js" integrity="sha384-...."></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/togeojson/0.15.0/togeojson.min.js"></script>
  <style>
    #mapid { height: 1080px; }
  </style>
</head>
<body>
  <div id="mapid"></div>
  <script>
    

    $.get("ward_17.kml", function(data) {
      var geojson = toGeoJSON.kml(data);
      var selectedLayer = null;
      L.geoJSON(geojson, {
        style: {
          color: "red"
        },
        onEachFeature: function(feature, layer) {
          layer.on('click', function() {
            if (layer instanceof L.Polygon) {
              if (selectedLayer === layer) {
                // Remove the marker and reset the layer style
                map.removeLayer(marker);
                layer.setStyle({
                  color: "red"
                });
                selectedLayer = null;
              } else {
                // Add a marker and change the layer style to green
                var bounds = layer.getBounds();
                var latlng = bounds.getCenter();
                alert(latlng);
                var currentLatlng = null;
                // Get current location
                if ("geolocation" in navigator) {
                  navigator.geolocation.getCurrentPosition(function(position) {
                    currentLatlng = L.latLng(position.coords.latitude, position.coords.longitude);
                    var distance = currentLatlng.distanceTo(latlng);
                    alert(distance);
                    if (distance <= 50) {
                      // Display green marker and set layer style to green
                      if (selectedLayer !== null) {
                        // Deselect previously selected layer
                        map.removeLayer(marker);
                        selectedLayer.setStyle({
                          color: "red"
                        });
                      }
                      var icon = L.icon({
                        iconUrl: 'https://cdn.rawgit.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-green.png',
                        iconSize: [25, 41],
                        iconAnchor: [12, 41]
                      });
                      marker = L.marker(latlng, {
                        icon: icon
                      }).addTo(map);
                      layer.setStyle({
                        color: "green"
                      });
                      selectedLayer = layer;
                    } else {
                      // Display error message if distance is more than 5 meters
                      alert("You are too far away from this location!");
                    }
                  });
                } else {
                  alert("Geolocation is not supported by this browser.");
                }
              }
            }
          });
        }
      }).addTo(map);
    });
    
        if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(function(position) {
        var latlng = L.latLng(position.coords.latitude, position.coords.longitude);
        // alert(latlng);
        var icon = L.icon({
          iconUrl: 'https://cdn.rawgit.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-blue.png',
          iconSize: [25, 41],
          iconAnchor: [12, 41]
        });
        var map = L.map('mapid').setView(latlng, 20);
        // var marker = null; // initialize marker variable
    
        // L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        //   attribution: 'Map data © <a href="https://openstreetmap.org">OpenStreetMap</a> contributors',
        //   maxZoom: 18,
        // }).addTo(map);
        L.marker(latlng, {
          icon: icon
        }).addTo(map);
      });
    }

  </script>
</body>
</html>