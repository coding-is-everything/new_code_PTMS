<?php
// Set your current latitude and longitude
$current_lat = 22.0866535;
$current_lng = 82.142605;

// Connect to the database
$conn = mysqli_connect("localhost", "digicar1_proptax", "@#India2020", "digicar1_proptax");

// Query the database to get the closest latitude and longitude
$query = "SELECT id, latitude, longitude, (6371000 * acos(cos(radians(" . $current_lat . ")) * cos(radians(latitude)) * cos(radians(longitude) - radians(" . $current_lng . ")) + sin(radians(" . $current_lat . ")) * sin(radians(latitude)))) AS distance FROM bmc_coordinate HAVING distance <= 5 ORDER BY distance ASC LIMIT 1";
$result = mysqli_query($conn, $query);

// Check if there is a result
if (mysqli_num_rows($result) > 0) {
    // Get the closest latitude and longitude
    $row = mysqli_fetch_assoc($result);
    $closest_lat = $row['latitude'];
    $closest_lng = $row['longitude'];

    // Output the closest latitude and longitude
    echo "The closest latitude is " . $closest_lat . " and the closest longitude is " . $closest_lng;
} else {
    echo "No latitude and longitude points within 5 meters found.";
}

// Close the database connection
mysqli_close($conn);
