<!DOCTYPE html>
<html>
<head>
<title>Google Location Refresh</title>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB9nv9hU4-qx08mLhyhK8RjrfkYskfZF1I"></script>
<script>
function refreshLocation() {
  // Get the current location.
  alert('Hello');
//   var currentLocation = navigator.geolocation.getCurrentPosition(function(position) {
//                 lat = position.coords.latitude;
//                 long = position.coords.longitude;
//             });
var lat = 0;
        var long = 0;
if ("geolocation" in navigator) {
            navigator.geolocation.getCurrentPosition(function(position) {
                lat = position.coords.latitude;
                long = position.coords.longitude;
            });
        } else {
            alert("Geolocation is not supported by this browser.");
        }

  // Set the map's center to the current location.
//   map.setCenter(lat, long);
map.setCenter({ lat: lat, lng: long });

  // Zoom the map in by one level.
  map.setZoom(map.getZoom() + 1);
}

setInterval(refreshLocation, 10000); // Refresh the location every 10 seconds.
</script>
</head>
<body>
<div id="map"></div>
</body>
</html>
