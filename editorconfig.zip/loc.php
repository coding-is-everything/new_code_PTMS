<?php
function generateRandomCoordinates($latitude, $longitude, $radiusInMeters) {
  $radiusInKm = $radiusInMeters / 1000.0;
  $radiusInRadians = $radiusInKm / 6371.0;

  $latitudeInRadians = deg2rad($latitude);
  $longitudeInRadians = deg2rad($longitude);

  $minLatitude = $latitudeInRadians - $radiusInRadians;
  $maxLatitude = $latitudeInRadians + $radiusInRadians;

  $minLongitude = $longitudeInRadians - $radiusInRadians;
  $maxLongitude = $longitudeInRadians + $radiusInRadians;

  $result = array();

  for ($i = 0; $i < 10; $i++) { // generate 10 random coordinates
    $u = rand() / getrandmax();
    $v = rand() / getrandmax();

    $w = $radiusInRadians * sqrt($u);
    $t = 2 * pi() * $v;

    $x = $w * cos($t);
    $y = $w * sin($t);

    $newLatitude = $x + $latitudeInRadians;
    $newLongitude = $y + $longitudeInRadians;

    if ($newLatitude >= $minLatitude && $newLatitude <= $maxLatitude && $newLongitude >= $minLongitude && $newLongitude <= $maxLongitude) {
      $result[] = array(rad2deg($newLatitude), rad2deg($newLongitude));
    }
  }

  return $result;
}

// Example usage:
$currentLatitude = 22.1009182;
$currentLongitude = 82.1524119;

$coordinates = generateRandomCoordinates($currentLatitude, $currentLongitude, 5);

foreach ($coordinates as $coordinate) {
  echo $coordinate[0] . ", " . $coordinate[1] . "\n<br/>";
}