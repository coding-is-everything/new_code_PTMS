<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Reports_model extends CI_Model{
function __construct() {
        // Set table name
        $this->table = 'sales';
    }
     /* Fetch  data from the database */
    function getRows($params = array()){
        $this->db->select('*');
        $this->db->from($this->table);
       if(array_key_exists("returnType",$params) && $params['returnType'] == 'count'){
            $result = $this->db->count_all_results();
        }else{
            if(array_key_exists("incentiveId", $params)){
                $this->db->where('incentiveId', $params['incentiveId']);
                $query = $this->db->get();
                $result = $query->row_array();
            }else{
                $this->db->order_by('incentiveId', 'desc');           
                $query = $this->db->get();
                $result = ($query->num_rows() > 0)?$query->result_array():FALSE;
            }
        }   
        return $result;
    }
    
    function getTotalFPending($params = array()) {
        $result1 = new stdClass();
        $query = $this->db->query('SELECT coursePriceRemain as CPR, couesePriceGiven as CPG, coursePriceCommited as CPC FROM sales group by studentId, batchId');
        $result = $query->result();
        foreach($result as $row) {
            $result1->CPC += (int)$row->CPC;
            $result1->CPG += (int)$row->CPG;
            $result1->CPR += (int)$row->CPR;
            $result1->incentive += (int)$row->coursePriceCommited * ((int)$row->courseIncentivePer / 100);
        }
        // print_r($result1);
        return $result1;
    }
    
    function getTotalFPendingAjax($sd, $ed, $roleId) {
        if($roleId == 1){
            $query = $this->db->query("SELECT SUM(coursePriceRemain) as CPR, SUM(couesePriceGiven) as CPG, SUM(coursePriceCommited) as CPC FROM sales WHERE (`transactionDate` BETWEEN '".date('m/d/Y', strtotime($sd))."' AND '".date('m/d/Y', strtotime($ed))."')");
        }else{
            $userId = $this->session->userdata('userId');
            $query = $this->db->query("SELECT SUM(coursePriceRemain) as CPR, SUM(couesePriceGiven) as CPG, SUM(coursePriceCommited) as CPC FROM sales WHERE (`transactionDate` BETWEEN '".date('m/d/Y', strtotime($sd))."' AND '".date('m/d/Y', strtotime($ed))."') AND userId = ".$userId);
        }
        return $query->result();
    }
    
    function getTotalFPending1($params = array()) {
        $userId = $this->session->userdata('userId');
        // $query = $this->db->query('SELECT SUM(coursePriceRemain) as CPR, SUM(couesePriceGiven) as CPG, SUM(coursePriceCommited) as CPC FROM sales WHERE userId = '.$userId);
        $result1 = new stdClass();
        $query = $this->db->query('SELECT coursePriceRemain as CPR, couesePriceGiven as CPG, coursePriceCommited as CPC FROM sales WHERE userId = '.$userId.' group by studentId, batchId');
        $result = $query->result();
        foreach($result as $row) {
            $result1->CPC += (int)$row->CPC;
            $result1->CPG += (int)$row->CPG;
            $result1->CPR += (int)$row->CPR;
            $result1->incentive += (int)$row->coursePriceCommited * ((int)$row->courseIncentivePer / 100);
        }
        // print_r($result1);
        return $result1;
    }
    
    function getTotalFPendingRep($params = array()) {
        
    }
    
    function getTotalFPendingRep1($params = array()) {
        
    }
    
    function getSales($params = array()) {
        $query = $this->db->query('SELECT * FROM `sales` GROUP BY studentId, batchId');
        return $query->result();
    }
    
    function getSRUser($SRId) {
        $query = $this->db->query('SELECT * FROM `users` WHERE `userId` = '.$SRId);
        return $query->result();
    }
    
    function getSalesAjax($sd, $ed, $roleId) {
        if($roleId == 1){
            $query = $this->db->query("SELECT * FROM `sales` WHERE (`transactionDate` BETWEEN '".date('m/d/Y', strtotime($sd))."' AND '".date('m/d/Y', strtotime($ed))."')");
        }else{
            $userId = $this->session->userdata('userId');
            $query = $this->db->query("SELECT * FROM `sales` WHERE (`transactionDate` BETWEEN '".date('m/d/Y', strtotime($sd))."' AND '".date('m/d/Y', strtotime($ed))."') AND userId = ".$userId);
        }
        return $query->result();
    }
    
    function getStudentName($id) {
        $query = $this->db->query('SELECT * FROM `students` WHERE `studentId` = '.$id);
        return $query->result();
    }
    
    function getPriceById($id, $batchId) {
        $query = $this->db->query('SELECT SUM(`couesePriceGiven`) as CPG, SUM(`coursePriceRemain`) as CPR FROM `sales` WHERE studentId = '.$id.' AND batchId = '.$batchId);
        return $query->result();
    }
    
    function getPriceCPR($id, $batchId) {
        $query = $this->db->query("SELECT * FROM `sales` WHERE `studentId`=".$id." and `batchId`=".$batchId." ORDER BY createdDate DESC");
        return $query->result();
    }
    
    function getRows1($params = array()){
        $this->db->select('*');
        $this->db->from($this->table);
        $this->db->where('userId',$this->session->userdata('userId')); 
       if(array_key_exists("returnType",$params) && $params['returnType'] == 'count'){
            $result = $this->db->count_all_results();
        }else{
            if(array_key_exists("incentiveId", $params)){
                $this->db->where('incentiveId', $params['incentiveId']);
                $query = $this->db->get();
                $result = $query->row_array();
            }else{
                $this->db->order_by('incentiveId', 'desc');           
                $query = $this->db->get();
                $result = ($query->num_rows() > 0)?$query->result_array():FALSE;
            }
        }   
        // echo $this->db->last_query();
        return $result;
    }
    
    function getSales1($params = array()){
        $this->db->select('*');
        $this->db->from($this->table);
        $this->db->where('userId',$this->session->userdata('userId')); 
       if(array_key_exists("returnType",$params) && $params['returnType'] == 'count'){
            $result = $this->db->count_all_results();
        }else{
            $query = $this->db->get();
                $result = ($query->num_rows() > 0)?$query->result():FALSE;
        }   
        // echo $this->db->last_query();
        return $result;
    }

 /* Insert batch data into the database*/
   
    public function insert($data = array()) {
        if(!empty($data)){
            // Add created and modified date if not included
            if(array_key_exists("createdDate", $data)){
                date_default_timezone_set("Asia/Kolkata");
                $data['createdDate'] = date("Y-m-d H:i:s");
            }
            
            // Insert batch data
            $insert = $this->db->insert($this->table, $data);
            
            // Return the status
            return $insert?$this->db->insert_id():false;
        }
        return false;
    }
  
/*select  dropdown */
  function getAllBatches()
    { 
        $query = $this->db->get('batches');
        $query = $this->db->query('SELECT * FROM batches INNER JOIN courses ON batches.courseId=courses.courseId');
        return $query->result();
        //SELECT * FROM batches INNER JOIN courses ON batches.courseId=courses.courseId
    }
    function getAllUsers()
    { 
        $query = $this->db->get('users');
        $query = $this->db->query('SELECT * FROM users where roleId=2 OR roleId = 4');
        return $query->result();
    }
    
    function getAllUsers1()
    { 
        $query = $this->db->get('users');
        $query = $this->db->query('SELECT * FROM users where roleId=2 OR roleId = 4 and userId='.$this->session->userdata('userId'));
        return $query->result();
    }
      function getAllUsers11()
    { 
        $query = $this->db->get('users');
        $query = $this->db->query('SELECT * FROM users where roleId=2 and userId='.$this->session->userdata('userId'));
        return $query->result();
    }
     function getAllUsers12()
    { 
        $query = $this->db->get('users');
        $query = $this->db->query('SELECT * FROM users where roleId=3 and  userId='.$this->session->userdata('userId'));
        return $query->result();
    }
     function getAllUsers13()
    { 
        $query = $this->db->get('users');
        $query = $this->db->query('SELECT * FROM users where roleId=4 and userId='.$this->session->userdata('userId'));
        return $query->result();
    }
    
    
     function getAllLeads()
    { 
        $query = $this->db->get('users');
        $query = $this->db->query('SELECT * FROM users where roleId=4');
        return $query->result();
    }
    function getAllStudents()
    { 
        $query = $this->db->get('students');
        $query = $this->db->query('SELECT * FROM students');
        return $query->result();
    }
    
    function checkIncentiveAjax($startDate, $endDate, $id)
    {
        $query = $this->db->query("SELECT SUM(coursePriceCommited) as coursePriceCommited, 
                                SUM(couesePriceGiven) as couesePriceGive, 
                                SUM(coursePriceRemain) as coursePriceRemain 
                                FROM thebatra_incentive.sales WHERE 
                                `transactionDate` BETWEEN '".date('m/d/Y', strtotime($startDate))."' AND '".date('m/d/Y', strtotime($endDate))."' AND userId =".$id);
        // print_r($this->db->last_query());
        return $query->result();
    }
    
    function checkIncentive($id)
    {
        $query = $this->db->query('SELECT SUM(coursePriceCommited) as coursePriceCommited, SUM(couesePriceGiven) as couesePriceGive, SUM(coursePriceRemain) as coursePriceRemain FROM thebatra_incentive.sales WHERE userId ='.$id);
        return $query->result();
    }
    
    function getDataAjax($sd, $ed, $id) {
        $query = $this->db->query("SELECT * FROM sales WHERE (`transactionDate` BETWEEN '".date('m/d/Y', strtotime($sd))."' AND '".date('m/d/Y', strtotime($ed))."') AND (userId = ".$id." OR TLId = ".$id." OR uId = ".$id.")");
        // print_r($this->db->last_query());
        return $query->result();
    }
    
    function incentiveForTL($id) {
        $query = $this->db->query('SELECT sum(courseIncentiveTeam) as ITL FROM `sales` where TLId = '.$id);
        return $query->result();
    }
    
    function incentiveForTLAjax($sd, $ed, $id) {
        $query = $this->db->query("SELECT sum(courseIncentiveTeam) as ITL FROM `sales` where `transactionDate` BETWEEN '".date('m/d/Y', strtotime($sd))."' AND '".date('m/d/Y', strtotime($ed))."' AND TLId = ".$id);
        // print_r($this->db->last_query());
        return $query->result();
    }
    
    //Second SR Value
    function incentiveForSSR($id) {
        // echo 'Hello';
        $query = $this->db->query('SELECT sum(incentiveAmtSR) as SSR  FROM `sales` where uId = '.$id);
        return $query->result();
    }
    
    function incentiveForSSRAjax($sd, $ed, $id) {
        $query = $this->db->query("SELECT sum(incentiveAmtSR) as SSR FROM `sales` where `transactionDate` BETWEEN '".date('m/d/Y', strtotime($sd))."' AND '".date('m/d/Y', strtotime($ed))."' AND uId = ".$id);
        // print_r($this->db->last_query());
        return $query->result();
    }
    
    function checkTL($id) {
        $query = $this->db->query('SELECT * FROM users where userId = '.$id);
        // print_r($query->result());
        return $query->result();
    }
    
    function studentList($id) {
        $query = $this->db->query("SELECT * FROM sales WHERE userId = ".$id." OR TLId = ".$id. " OR uId = ".$id);
        // print_r($this->db->last_query());
        return $query->result();
    }
    function getAllUsers3()
    { 
        $query = $this->db->get('users');
        $query = $this->db->query('SELECT * FROM users where roleId=2');
        return $query->result();
    }
     function getAllUsers_1()
    { 
        $query = $this->db->get('users');
        $query = $this->db->query('SELECT * FROM users where roleId=3');
        return $query->result();
    }
     function getAllUsers2()
    { 
        $query = $this->db->get('users');
        $query = $this->db->query('SELECT * FROM users where roleId=4');
        return $query->result();
    }

     /* Update batch data into the database */
    public function update($data, $id) {
        if(!empty($data) && !empty($id)){
            // Add modified date if not included
            if(array_key_exists("updatedDate", $data)){
                date_default_timezone_set("Asia/Kolkata");
                $data['updatedDate'] = date("Y-m-d H:i:s");
            }
            
            // Update batch data
            $update = $this->db->update($this->table, $data, array('incentiveId' => $id));
            
            // Return the status
            return $update?true:false;
        }
        return false;
    }
    
     /* Delete batch data from the database*/
    public function delete($id){
        // Delete batch data
        $delete = $this->db->delete($this->table, array('incentiveId' => $id));
        // Return the status
        return $delete?true:false;
    }

}


