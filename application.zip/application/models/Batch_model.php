<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Batch_model extends CI_Model
{

    function __construct()
    {
        // Set table name
        $this->table = 'batches';
        $this->salestable = 'sales';
    }

    /* Fetch  data from the database */
    function getRows($params = array())
    {
        $this->db->select('*');
        $this->db->from($this->table);

        if (array_key_exists("conditions", $params)) {
            foreach ($params['conditions'] as $key => $val) {
                $this->db->where($key, $val);
            }
        }

        if (array_key_exists("returnType", $params) && $params['returnType'] == 'count') {
            $result = $this->db->count_all_results();
        } else {
            if (array_key_exists("batchId", $params)) {
                $this->db->where('batchId', $params['batchId']);
                $query = $this->db->get();
                $result = $query->row_array();
            } else {
                $this->db->order_by('batchId', 'desc');
                $query = $this->db->get();
                $result = ($query->num_rows() > 0) ? $query->result_array() : FALSE;
            }
        }
        // print_r($this->db->last_query());
        // Return fetched data
        return $result;
    }
    
    //Get Data From Ajax Data
    function getData($sd, $ed, $id) {
        $result = $this->db->query("SELECT *, sum(couesePriceGiven) as CPG FROM `sales` WHERE `createdDate` BETWEEN '".date('Y-m-d', strtotime($sd))."' AND '".date('Y-m-d', strtotime($ed))."' AND batchId = ".$id." GROUP BY studentId, batchId");
        if($result->num_rows() > 0){
            return $result->result_array();
        }else{
            return 0;
        }
    }
    
    function getComments($id, $batchId) {
        $result = $this->db->query("SELECT * FROM batchStudentComments WHERE studentId = ".$id." and batchId = ".$batchId." ORDER BY createdAt DESC");
        if($result->num_rows() > 0) {
            return $result->row_array();
        }else{
            return 0;
        }
    }
    
    function getDetails($id, $batchId) {
        $result = $this->db->query('SELECT * FROM sales WHERE studentId = '.$id.' and batchId = '.$batchId);
        // print_r($this->db->last_query());
        if($result->num_rows() > 0){
            // print_r($result->result_array());
            return $result->result_array();
        }else{
            return 0;
        }
    }
    //Fetch Sales Student Data From Database
    function getStudentRows($params = array())
    {
        $query = $this->db->query("SELECT * FROM `sales` WHERE batchId = ".$params['batchId']." GROUP BY studentId");
        // echo $this->db->last_query();
        $result = $query->result_array();
        //Return fetched data
        return $result;
    }
    
    function getLeadStudentRows($params = array()) {
        $query = $this->db->query("SELECT * FROM `leadsBatches` WHERE batchId = ".$params['batchId'])->result();
        $result = array();
        foreach($query as $row) {
            $queryLeads = $this->db->query("SELECT * FROM `leads` WHERE id = ".$row->studentId)->row_array();
            $result[] = $queryLeads;
        }
        return $result;
    }
    
    function getStudentRowsStaff($params = array()) {
        $query = $this->db->query("SELECT * FROM `sales` WHERE batchId = ".$params['batchId']." AND userId = ".$params['userId']." GROUP BY studentId");
        $result = $query->result_array();
        return $result;
    }
    
    function coursePriseGiven($id, $batchId) {
        $query = $this->db->query('SELECT sum(couesePriceGiven) as CPG FROM `sales` WHERE (studentId = '.$id.') and batchId =  '.$batchId);
        // print_r($this->db->last_query());
        return $query->result();
    }

    //Fetch Student Data from table
    function studentData($params = array()) {
        $this->db->select('*');
        $this->db->from('students');

        if(array_key_exists("conditions", $params)) {
            foreach($params['conditions'] as $key => $val) {
                $this->db->where($key, $val);
            }
        }

        if(array_key_exists("returnType", $params) && $params['returnType'] == "count") {
            $result = $this->db->count_all_results();
        }else{
            if(array_key_exists("studentId", $params)) {
                $this->db->where("studentId", $params['studentId']);
                $query = $this->db->get();
                $result = $query->row_array();
            }else{
                $this->db->order_by('studentId', 'desc');
                $query = $this->db->get();
                $result = ($query->num_rows() > 0) ? $query->result_array() : FALSE;
            }
        }

        // print_r($result);
        return $result;
    }

    //Sales Representative Data from Table
   function getAllUsers()
    { 
        $query = $this->db->get('users');
        $query = $this->db->query('SELECT * FROM users where roleId=2 OR roleId = 3 OR roleId = 4');
        return $query->result();
    }
    function getAllUsers11()
    { 
        $query = $this->db->get('users');
        $query = $this->db->query('SELECT * FROM users where roleId=2');
        return $query->result();
    }
   function getAllUsers12()
    { 
        $query = $this->db->get('users');
        $query = $this->db->query('SELECT * FROM users where roleId=3');
        return $query->result();
    }
    function getAllUsers13()
    { 
        $query = $this->db->get('users');
        $query = $this->db->query('SELECT * FROM users where roleId=4');
        return $query->result();
    }

    //Fetch sales data for count
    function getSalesCount($params = array())
    {
        $result1 = new stdClass();
        $i = 0;
        $query = $this->db->query("SELECT count(*) as count FROM `sales` WHERE `batchId` = ".$params['batchId']." GROUP BY `studentId`");
        // print_r($this->db->last_query());
        $result = $query->result();
        foreach($result as $row) {
            $i++;
            // echo $i."<br/>";
            $result1->count = $i;
        }
        // print_r($result1);
        return $result1;
    }
    
    function getLeadCount($params = array()) {
        $result1 = new stdClass();
        $i = 0;
        $query = $this->db->query("SELECT count(*) as count FROM `leadsBatches` WHERE `batchId` = ".$params['batchId']);
        $result = $query->row_array();
        // print_r($result);
        return $result;
    }
    
    function totalCoursePriceGiven($id, $batchId, $userId = 0) {
        $query = $this->db->query("SELECT SUM(couesePriceGiven) as coursePriceGiven, SUM(courseIncentive) as CI, SUM(coursePricePre) as CPP FROM `sales` WHERE `studentId` = ".$id." AND `batchId` = ".$batchId." AND (`userId` = ".$userId." OR `TLId` = ".$userId." OR `uId` = ".$userId.")");
        // print_r($this->db->last_query());
        return $query->result();
    }
    
    function courseName($studentId){
        $courseName = array();
        $finalNew = array();
        $queryBatch = $this->db->query("SELECT * FROM sales WHERE studentId = ".$studentId." GROUP BY batchId");
        $resultBatch = $queryBatch->result();
        foreach($resultBatch as $row) {
            $queryCourse = $this->db->query("SELECT * FROM batches WHERE batchId = ".$row->batchId);
            $resultCourse = $queryCourse->result();
            foreach($resultCourse as $rowCourse) {
                $queryCourseFinal = $this->db->query("SELECT * FROM courses WHERE courseId = ".$rowCourse->courseId);
                $resultFinal[] = $queryCourseFinal->row_array();
            }
        }
        if(!empty($resultFinal)) {
            foreach($resultFinal as $final){
                array_push($finalNew, $final['courseName']);
            }
            return implode(', ', $finalNew);
        }else{
            return 'No Couse Enrolled.';
        }
    }
    
    function courseNameBalance($studentId){
        $courseName = array();
        $finalNew = array();
        $queryBatch = $this->db->query("SELECT * FROM sales WHERE studentId = ".$studentId." AND coursePriceRemain > 0 GROUP BY batchId");
        $resultBatch = $queryBatch->result();
        foreach($resultBatch as $row) {
            $queryCourse = $this->db->query("SELECT * FROM batches WHERE batchId = ".$row->batchId);
            $resultCourse = $queryCourse->result();
            foreach($resultCourse as $rowCourse) {
                $queryCourseFinal = $this->db->query("SELECT * FROM courses WHERE courseId = ".$rowCourse->courseId);
                $resultFinal[] = $queryCourseFinal->row_array();
            }
        }
        print_r($resultFinal);
        foreach($resultFinal as $final){
            array_push($finalNew, $final['courseName']);
        }
        return implode(', ', $finalNew);
    }

    //Fetch student committed, given and remaining
    function getFeeDetails($params = array())
    {
        $result1 = new stdClass();
        $result = $this->db->query("SELECT coursePriceCommited as cpc
                                    FROM 
                                    thebatra_incentive.sales WHERE batchId =" . $params['batchId']." GROUP BY studentId")->result();
        foreach($result as $row) {
            $result1->cpc += (int)$row->cpc;
        }
        return $result1;
    }
    
    function getFeeDetailsLeads($params = array()) {
        $result1 = new stdClass();
        $sumAmount = 0;
        $result = $this->db->query("SELECT * FROM leadsBatches WHERE batchId = ".$params['batchId'])->result();
        foreach($result as $row) {
            $resultStudent = $this->db->query("SELECT * FROM leads WHERE id = ".$row->studentId)->row_array();
            $sumAmount += $resultStudent['amount'];
        }
        // print_r($sumAmount);
        return $sumAmount;
    }
    
    function getGivenPrice($id) {
        $query = $this->db->query('SELECT sum(couesePriceGiven) as CPG from sales WHERE batchId = '.$id);
        // print_r($this->db->last_query());
        return $query->result();
    }

    /* Insert batch data into the database*/

    public function insert($data = array())
    {
        if (!empty($data)) {
            // Add created and modified date if not included
            if (array_key_exists("createdDate", $data)) {
                date_default_timezone_set("Asia/Kolkata");
                $data['createdDate'] = date("Y-m-d H:i:s");
            }

            // Insert batch data
            $insert = $this->db->insert($this->table, $data);

            // Return the status
            return $insert ? $this->db->insert_id() : false;
        }
        return false;
    }
    
    /**
     * Insert Comment related to data
     */
     public function insertComment($data = array()) {
         if(!empty($data)) {
             if(array_key_exists("createdAt", $data)) {
                 date_default_timezone_set("Asia/Kolkata");
                 $data['createdAt'] = date('Y-m-d H:i:s');
             }
             
             $insert = $this->db->insert('batchStudentComments', $data);
             
             return $insert ? $this->db->insert_id() : false;
         }
         
         return false;
     }

    /*select  dropdown */
    function getAllGroups()
    {
        $query = $this->db->get('courses');
        $query = $this->db->query('SELECT * FROM courses');
        return $query->result();
    }
    /* Update batch data into the database */
    public function update($data, $id)
    {
        if (!empty($data) && !empty($id)) {
            // Add modified date if not included
            if (array_key_exists("updatedDate", $data)) {
                date_default_timezone_set("Asia/Kolkata");
                $data['updatedDate'] = date("Y-m-d H:i:s");
            }

            // Update batch data
            $update = $this->db->update($this->table, $data, array('batchId' => $id));

            // Return the status
            return $update ? true : false;
        }
        return false;
    }


    /* Delete batch data from the database*/
    public function delete($id)
    {
        // Delete batch data
        $delete = $this->db->delete($this->table, array('batchId' => $id));

        // Return the status
        return $delete ? true : false;
    }
}
