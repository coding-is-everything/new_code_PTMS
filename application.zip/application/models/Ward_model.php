<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Ward_model extends CI_Model{

function __construct() {
        // Set table name
        $this->table = 'sales';
    }
    function getAllWards()
    { 
        $query = $this->db->query('SELECT * FROM `ward_table` WHERE deleteStatus IS NULL OR deleteStatus = 0');
        return $query->result();
    }
    
    function checkAccess($ariId) {
        $query = $this->db->query('SELECT * FROM `ari_data_table` WHERE userId = '.$ariId);
        return $query->result();
    }
    
    function getAllWardsZoneWise()
    { 
        $ward = $this->Property_model->getAROData($this->session->userdata('userId'))[0]->AROZoneNo;
        $query = $this->db->query('SELECT * FROM `ward_table` WHERE (deleteStatus IS NULL OR deleteStatus = 0) AND zoneId = '.$ward);
        return $query->result();
    }
    
    function getAllZones()
    { 
        $query = $this->db->query('SELECT * FROM `zone_table` WHERE deleteStatus IS NULL OR deleteStatus = 0');
        return $query->result();
    }
    
    function getAllAri()
    {
        $query = $this->db->query('SELECT *
                                    FROM ari_data_table
                                    WHERE deleteStatus IS NULL OR deleteStatus = 0;');
        return $query->result();
    }
    
    function getWardIdByUser($userId) {
        $query = $this->db->query('SELECT * FROM `ari_data_table` WHERE userId = '.$userId);
        return $query->result();
    }
    
    function getAllAro()
    {
        $query = $this->db->query('SELECT * FROM `aro_data_table` WHERE deleteStatus IS NULL OR deleteStatus = 0');
        return $query->result();
    }
    
    function getAllZC()
    {
        $query = $this->db->query('SELECT * FROM `zone_commissioner_table` WHERE deleteStatus IS NULL OR deleteStatus = 0');
        return $query->result();
    }
    
    function getWardDetail($id) {
        if(!empty($id)) {
            $query = $this->db->query('SELECT * FROM `ward_table` WHERE `id` = '.$id);
            return $query->result();
        }
    }
    
    function getWardDetailWard($id) {
        // echo $id;
        if(!empty($id)) {
            $query = $this->db->query('SELECT * FROM `ward_table` WHERE `ward_kml` = "'.$id.'"');
            return $query->result();
        }
    }
    
    function getZoneDetail($id) {
        if(!empty($id)) {
            $query = $this->db->query('SELECT * FROM `zone_table` WHERE `id` = '.$id);
            return $query->result();
        }
    }
    
    function getUserDetailsBasedOnUserId($id) {
        if(!empty($id)) {
            $query = $this->db->query('SELECT * FROM `ari_data_table` WHERE `userId` = '.$id);
            return $query->row_array();
        }
    }
    
     //Insert Function For Email Content
    public function insert($data = array()) {
        if(!empty($data)){
            print_r($data);
            // Add created and modified date if not included
            $insert = $this->db->insert('property', $data);
            
            // Return the status
            return $insert?$this->db->insert_id():false;
        }
        return false;
    }
    
    public function getPropertyData($ward = 0)
    {
        if($ward == 0){
            $query = $this->db->query('SELECT * FROM `property` WHERE deleted IS NULL OR deleted = 0');
            return $query->result();
        }else{
            $query = $this->db->query('SELECT * FROM `property` WHERE (deleted IS NULL OR deleted = 0) AND `ward_no` = '.$ward);
            return $query->result();
        }
    }
    
    public function getPropertyZoneData($zone = 0)
    {
        if($zone == 0){
            $query = $this->db->query("SELECT * FROM `property` WHERE deleted IS NULL OR deleted = 0");
            return $query->result();
        }else{
            $query = $this->db->query("SELECT * FROM `property` WHERE (deleted IS NULL OR deleted = 0) AND `zone_no` = ".$zone);
            return $query->result();
        }
    }
    
    public function getPropertyZoneWardWise($zone = 0, $ward = 0)
    {
        if($zone == 0 && $ward == 0)
        {
            $query = $this->db->query("SELECT * FROM `property` WHERE deleted IS NULL OR deleted = 0");
            return $query->result();
        }else{
            $query = $this->db->query("SELECT * FROM `property` WHERE (deleted IS NULL OR deleted = 0) AND `zone_no`=".$zone." AND `ward_no` = ".$ward);
            return $query->result();
        }
    }
    
    public function getPropData($propId) {
        // print_r($propId);
        if(!empty($propId)) {
            $query = $this->db->query('SELECT * FROM `property` WHERE `id` = '.$propId);
            return $query->result();
        }
    }
    
    public function getPropData1($propId) {
        if(!empty($propId)) {
            $query = $this->db->get_where('property', ['id' => $propId]);
            return $query->result();
        }
    }
    
    public function logChanges($id, $old_data, $new_data, $table_name, $column_name) {
        $this->db->insert('logs', [
            'user_id' => $this->session->userdata('userId'),
            'table_index_id' => $id,
            'table_name' => $table_name,
            'column_name' => $column_name,
            'old_value' => $old_data,
            'new_value' => $new_data,
        ]);
    }
    
    public function getPropForApproval($zone) {
        $query = $this->db->query('SELECT * FROM `property` WHERE `zone_no` = '.$zone.' AND `ARI_audit_status` != ""');
        
        return $query->result();
        // print_r($this->db->last_query());
    }
    
    public function getARIData($userId) {
        $query = $this->db->query('SELECT * FROM `ari_data_table` WHERE `userId` = '.$userId);
        return $query->result();
    }
    
    public function getARIDataBasedOnId($id) {
        $query = $this->db->query('SELECT * FROM `ari_data_table` WHERE `userId` = '.$id);
        return $query->result();
    }
    
    public function getARODataBasedOnId($id) {
        $query = $this->db->query('SELECT * FROM `aro_data_table` WHERE `userId` = '.$id);
        return $query->result();
    }
    
    public function getZCDataBasedOnId($id) {
        $query = $this->db->query('SELECT * FROM `zone_commissioner_table` WHERE `userId` = '.$id);
        return $query->result();
    }
    
    public function getZCData($userId) {
        $query = $this->db->query('SELECT * FROM `zone_commissioner_table` WHERE `userId` = '.$userId);
        return $query->result();
    }
    
    public function update($data, $id) {
    	print_r($data);
        if(!empty($data) && !empty($id)){
            // Add modified date if not included
            // Update batch data
            $update = $this->db->update('property', $data, array('id' => $id));
            
            // Return the status
            return $update?true:false;
        }
        return false;
    }
    
    public function ApprovedRecord() {
        $property = $this->db->query("SELECT * FROM `property` WHERE (ARI_audit_status = 'Approved' && ARO_audit_status = 'Approved' && ZC_audit_status = 'Approved')");
        return $property->result();
    }
    
    public function RejectedRecord() {
        $property = $this->db->query("SELECT * FROM `property` WHERE (ARI_audit_status = 'Rejected' || ARO_audit_status = 'Rejected' || ZC_audit_status = 'Rejected' || ARI_audit_status IS NULL || ARO_audit_status IS NULL || ZC_audit_status IS NULL)");
        return $property->result();
    }
} 