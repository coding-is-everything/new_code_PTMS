<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Crm_activity_model extends CI_Model{

    function __construct() {
        $this->table = 'activity';
    }
    
    //Insert Function For Email Content
    public function getActivityLogs() {
        $query = $this->db->query("SELECT * FROM `activityLogs`");
        return $query->result_array();
    }
    
    public function getLeadName($leadId) {
        if(!empty($leadId)) {
            $queryLead = $this->db->query("SELECT * FROM `leads` WHERE id = ".$leadId);
            return $queryLead->row_array();
        }
    }
    
    public function getRMName($RMId) {
        if(!empty($RMId)) {
            $queryRM = $this->db->query("SELECT * FROM `RMMaster` WHERE userMasterId = ".$RMId);
            return $queryRM->row_array();
        }
    }
}

?>