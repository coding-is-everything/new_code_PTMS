<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Student_model extends CI_Model{

function __construct() {
        // Set table name
        $this->table = 'students';
    }
     /* Fetch course data from the database */
    function getRows($params = array()){
        $this->db->select('*');
        $this->db->from($this->table); 
        //$this->db->where('userId',$this->session->userdata('userId'));       
        if(array_key_exists("returnType",$params) && $params['returnType'] == 'count'){
            $result = $this->db->count_all_results();
        }else{
            if(array_key_exists("studentId", $params)){
                $this->db->where('studentId', $params['studentId']);
                $query = $this->db->get();
                $result = $query->row_array();
            }else{
                $this->db->order_by('studentId', 'desc');                
                $query = $this->db->get();
                $result = ($query->num_rows() > 0)?$query->result_array():FALSE;
            }
        }
        return $result;
    }

    function getRows1($params = array()){
        $this->db->select('*');
        $this->db->from($this->table); 
        $this->db->where('userId',$this->session->userdata('userId'));       
        if(array_key_exists("returnType",$params) && $params['returnType'] == 'count'){
            $result = $this->db->count_all_results();
        }else{
            if(array_key_exists("studentId", $params)){
                $this->db->where('studentId', $params['studentId']);
                $query = $this->db->get();
                $result = $query->row_array();
            }else{
                $this->db->order_by('studentId', 'desc');                
                $query = $this->db->get();
                $result = ($query->num_rows() > 0)?$query->result_array():FALSE;
            }
        }
        return $result;
    }
    
    /***
     * View Ledger Here we will view the entire transaction of any student.
    */
    function getLedger($id) {
        $query = $this->db->query('SELECT * FROM `sales` WHERE `studentId` = '.$id.' ORDER BY `transactionDate` DESC');
        // print_r($query->result());
        return $query->result();
    }
    
    /**
     * Function to get 
    */
    function getSRName($SRId) {
        $query = $this->db->query('SELECT * FROM `users` WHERE `userId` = '.$SRId);
        return $query->row_array();
    }
    
    function getTotalGiven($id) {
        $query = $this->db->query('SELECT SUM(couesePriceGiven) as CPG FROM `sales` WHERE `studentId` = '.$id);
        // print_r($query->row_array());
        return $query->row_array();
    }
    
    function getTotalCommited($id) {
        $result1 = new stdClass();
        $query = $this->db->query('SELECT coursePriceCommited as CPC from `sales` WHERE `studentId` = '.$id.' GROUP BY studentId, batchId');
        $result = $query->result();
        foreach($result as $row) {
            $result1->CPC += $row->CPC;
        }
        return $result1;
        
    }
    
    function getStudentDetails($id) {
        $query = $this->db->query('SELECT * FROM `students` WHERE `studentId` = '.$id);
        return $query->row_array();
    }

     /* Insert course data into the database
     */
    
    public function insert($data = array()) {
        if(!empty($data)){
            // Add created and modified date if not included
            if(array_key_exists("createdDate", $data)){
                date_default_timezone_set("Asia/Kolkata");
                $data['createdDate'] = date("Y-m-d H:i:s");
                $data['userId'] = $this->session->userdata('userId');
            }
            
            // Insert course data
            $insert = $this->db->insert($this->table, $data);
            
            // Return the status
            return $insert?$this->db->insert_id():false;
        }
        return false;
    }

     /* Update course data into the database */
    public function update($data, $id) {
        if(!empty($data) && !empty($id)){
            // Add modified date if not included
            if(array_key_exists("updatedDate", $data)){
                date_default_timezone_set("Asia/Kolkata");
                $data['updatedDate'] = date("Y-m-d H:i:s");
                $data['userId'] = $this->session->userdata('userId');
            }
            
            // Update course data
            $update = $this->db->update($this->table, $data, array('studentId' => $id));
            
            // Return the status
            return $update?true:false;
        }
        return false;
    }
    
    function getAllUsers()
    { 
        $query = $this->db->get('users');
        $query = $this->db->query('SELECT * FROM users where roleId=2');
        return $query->result();
    }

   
     /* Delete course data from the database*/
    public function delete($id){
        // Delete course data
        $delete = $this->db->delete($this->table, array('studentId' => $id));
        
        // Return the status
        return $delete?true:false;
    }

}


