<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Incentive_model extends CI_Model{
function __construct() {
        // Set table name
        $this->table = 'incentives';
    }
     /* Fetch  data from the database */
    function getRows($params = array()){
        $this->db->select('*');
        $this->db->from($this->table);
       if(array_key_exists("returnType",$params) && $params['returnType'] == 'count'){
            $result = $this->db->count_all_results();
        }else{
            if(array_key_exists("incentiveId", $params)){
                $this->db->where('incentiveId', $params['incentiveId']);
                $query = $this->db->get();
                $result = $query->row_array();
            }else{
                $this->db->order_by('incentiveId', 'desc');           
                $query = $this->db->get();
                $result = ($query->num_rows() > 0)?$query->result_array():FALSE;
            }
        }   
        return $result;
    }
    
    function getRows1($params = array()){
        $this->db->select('*');
        $this->db->from($this->table);
        $this->db->where('userId',$this->session->userdata('userId')); 
       if(array_key_exists("returnType",$params) && $params['returnType'] == 'count'){
            $result = $this->db->count_all_results();
        }else{
            if(array_key_exists("incentiveId", $params)){
                $this->db->where('incentiveId', $params['incentiveId']);
                $query = $this->db->get();
                $result = $query->row_array();
            }else{
                $this->db->order_by('incentiveId', 'desc');           
                $query = $this->db->get();
                $result = ($query->num_rows() > 0)?$query->result_array():FALSE;
            }
        }   
        // echo $this->db->last_query();
        return $result;
    }

 /* Insert batch data into the database*/
   
    public function insert($data = array()) {
        if(!empty($data)){
            // Add created and modified date if not included
            if(array_key_exists("createdDate", $data)){
                date_default_timezone_set("Asia/Kolkata");
                $data['createdDate'] = date("Y-m-d H:i:s");
            }
            
            // Insert batch data
            $insert = $this->db->insert($this->table, $data);
            
            // Return the status
            return $insert?$this->db->insert_id():false;
        }
        return false;
    }
  
/*select  dropdown */
  function getAllBatches()
    { 
        $query = $this->db->get('batches');
        $query = $this->db->query('SELECT * FROM batches INNER JOIN courses ON batches.courseId=courses.courseId');
        return $query->result();
        //SELECT * FROM batches INNER JOIN courses ON batches.courseId=courses.courseId
    }
    function getAllUsers()
    { 
        $query = $this->db->get('users');
        $query = $this->db->query('SELECT * FROM users where roleId=2 OR roleId = 4');
        return $query->result();
    }
    
    function getAllUsers1()
    { 
        $query = $this->db->get('users');
        $query = $this->db->query('SELECT * FROM users where roleId=2 OR roleId = 4 and userId='.$this->session->userdata('userId'));
        return $query->result();
    }
      function getAllUsers11()
    { 
        $query = $this->db->get('users');
        $query = $this->db->query('SELECT * FROM users where roleId=2 and userId='.$this->session->userdata('userId'));
        return $query->result();
    }
     function getAllUsers12()
    { 
        $query = $this->db->get('users');
        $query = $this->db->query('SELECT * FROM users where roleId=3 and  userId='.$this->session->userdata('userId'));
        return $query->result();
    }
     function getAllUsers13()
    { 
        $query = $this->db->get('users');
        $query = $this->db->query('SELECT * FROM users where roleId=4 and userId='.$this->session->userdata('userId'));
        return $query->result();
    }
    
    
     function getAllLeads()
    { 
        $query = $this->db->get('users');
        $query = $this->db->query('SELECT * FROM users where roleId=4');
        return $query->result();
    }
    function getAllStudents()
    { 
        $query = $this->db->get('students');
        $query = $this->db->query('SELECT * FROM students');
        return $query->result();
    }
    
    function checkIncentiveAjax($startDate, $endDate, $id)
    {
        $result1 = new stdClass();
        $query = $this->db->query("SELECT coursePriceCommited as coursePriceCommited, 
                                couesePriceGiven as couesePriceGive, 
                                coursePriceRemain as coursePriceRemain,
                                courseIncentivePer
                                FROM thebatra_incentive.sales WHERE 
                                `transactionDate` BETWEEN '".date('m/d/Y', strtotime($startDate))."' AND '".date('m/d/Y', strtotime($endDate))."' AND (userId =".$id." OR TLId = ".$id." OR uId = ".$id.") GROUP BY studentId, batchId");
        // print_r($this->db->last_query());
        $result = $query->result();
        foreach($result as $row) {
            $result1->coursePriceCommited += (int)$row->coursePriceCommited;
            $result1->couesePriceGive += (float)$row->couesePriceGive;
            $result1->coursePriceRemain += (int)$row->coursePriceRemain;
            $result1->incentive += (int)$row->coursePriceCommited * ((int)$row->courseIncentivePer / 100);
        }
        // print_r($result1);
        return $result1;
    }
    
    function checkIncentiveSRAjax($id)
    {
        $result1 = new stdClass();
        $query = $this->db->query("SELECT coursePriceCommited as coursePriceCommited, 
                                couesePriceGiven as couesePriceGive, 
                                coursePriceRemain as coursePriceRemain ,
                                courseIncentivePer
                                FROM thebatra_incentive.sales WHERE userId =".$id." GROUP BY studentId, batchId");
        // print_r($this->db->last_query());
        $result = $query->result();
        foreach($result as $row) {
            $result1->coursePriceCommited += (int)$row->coursePriceCommited;
            $result1->couesePriceGive += (int)$row->couesePriceGive;
            $result1->coursePriceRemain += (int)$row->coursePriceRemain;
            $result1->incentive += (int)$row->coursePriceCommited * ((int)$row->courseIncentivePer / 100);
        }
        return $result1;
    }
    
    function checkFullIncentiveAjax($startDate, $endDate, $SR = 0)
    {
        $result1 = new stdClass();
        if($SR == 0){
            $query = $this->db->query("SELECT coursePriceCommited, 
                                couesePriceGiven as couesePriceGive, 
                                coursePriceRemain as coursePriceRemain,SUM(courseIncentive) as CI, SUM(incentiveAmtSR) as IASR, SUM(courseIncentiveTeam) as CIT, courseIncentivePer
                                FROM thebatra_incentive.sales WHERE 
                                `transactionDate` BETWEEN '".date('m/d/Y', strtotime($startDate))."' AND '".date('m/d/Y', strtotime($endDate))."' GROUP BY studentId, batchId");
        }else{
            $query = $this->db->query("SELECT coursePriceCommited, 
                                couesePriceGiven as couesePriceGive, 
                                coursePriceRemain as coursePriceRemain,SUM(courseIncentive) as CI, SUM(incentiveAmtSR) as IASR, SUM(courseIncentiveTeam) as CIT, courseIncentivePer
                                FROM thebatra_incentive.sales WHERE 
                                `transactionDate` BETWEEN '".date('m/d/Y', strtotime($startDate))."' AND '".date('m/d/Y', strtotime($endDate))."' AND (userId = ".$SR." OR TLId = ".$SR." OR uId = ".$SR.") GROUP BY studentId, batchId");
        }
        // print_r($this->db->last_query());
        $result = $query->result();
        foreach($result as $row) {
            $result1->coursePriceCommited += (float)$row->coursePriceCommited;
            $result1->couesePriceGive += (float)$row->couesePriceGive;
            $result1->coursePriceRemain += (float)$row->coursePriceRemain;
            $result1->CI += (float)$row->CI;
            $result1->IASR += (float)$row->IASR;
            $result1->CIT += (float)$row->CIT;
            $result1->incentive += (float)$row->coursePriceCommited * ((float)$row->courseIncentivePer / 100);
        }
        return $result1;
    }
    
    function checkIncentive($id)
    {
        $result1 = new stdClass();
        $query = $this->db->query('SELECT coursePriceCommited, 
                    couesePriceGiven as couesePriceGive, 
                    coursePriceRemain as coursePriceRemain, 
                    courseIncentivePer FROM thebatra_incentive.sales WHERE (userId ='.$id.' OR TLId = '.$id.' OR uId = '.$id.') GROUP BY studentId, batchId');
        // print_r($this->db->last_query());
        $result = $query->result();
        foreach($result as $row){
            $result1->coursePriceCommited += (int)$row->coursePriceCommited;
            $result1->couesePriceGive += (int)$row->couesePriceGive;
            $result1->coursePriceRemain += (int)$row->coursePriceRemain;
            $result1->incentive += (int)$row->coursePriceCommited * ((int)$row->courseIncentivePer / 100);
        }
        // print_r($result1);
        return $result1;
    }
    
    function coursePriseGiven($id) {
        $query = $this->db->query('SELECT sum(couesePriceGiven) as CPG FROM `sales` WHERE (userId = '.$id.' OR TLId = '.$id.' OR uId = '.$id.')');
        // print_r($this->db->last_query());
        return $query->result();
    }
    
    function coursePriseGivenAjax($sd, $ed, $id) {
        $result1 = new stdClass();
        $query = $this->db->query("SELECT sum(couesePriceGiven) as CPG FROM `sales` WHERE `transactionDate` BETWEEN '".date('m/d/Y', strtotime($sd))."' AND '".date('m/d/Y', strtotime($ed))."' AND (userId = ".$id." OR TLId = ".$id." OR uId = ".$id.") GROUP BY studentId, batchId");
        $result = $query->result();
        foreach($result as $row){
            $result1->CPG += (float)$row->CPG;
            // $result1->couesePriceGive += (float)$row->couesePriceGive;
            // $result1->coursePriceRemain += (float)$row->coursePriceRemain;
            // $result1->incentive += (float)$row->coursePriceCommited * ((float)$row->courseIncentivePer / 100);
        }
        return $result1;
        // return 
    }
    
    function getFullDirectIncentive() {
        $query = $this->db->query("SELECT SUM(courseIncentive) as CI FROM sales WHERE mode = 'direct'");
        $result = $query->result();
        return $result;
    }
    
    function getFullInDirectIncentive() {
        $query = $this->db->query("SELECT SUM(courseIncentive) as CI FROM sales WHERE mode = 'indirect'");
        $result = $query->result();
        return $result;
    }
    
    
    
    function getFullDirectAjaxIncentive($sd, $ed, $SR = 0){
        if($SR == 0){
            $query = $this->db->query("SELECT sum(courseIncentive) as CI FROM `sales` WHERE mode = 'direct' AND `transactionDate` BETWEEN '".date('m/d/Y', strtotime($sd))."' AND '".date('m/d/Y', strtotime($ed))."'");
        }else{
            $query = $this->db->query("SELECT sum(courseIncentive) as CI FROM `sales` WHERE mode = 'direct' AND `transactionDate` BETWEEN '".date('m/d/Y', strtotime($sd))."' AND '".date('m/d/Y', strtotime($ed))."' AND (userId = ".$SR." OR TLId = ".$SR." OR uId = ".$SR.")");
        }
        // echo $query;
        return $query->row_array();
    }
    
    function getFullInDirectAjaxIncentive($sd, $ed, $SR = 0) {
        if($SR == 0){
            $query = $this->db->query("SELECT sum(courseIncentive) as CI FROM `sales` WHERE mode = 'indirect' AND `transactionDate` BETWEEN '".date('m/d/Y', strtotime($sd))."' AND '".date('m/d/Y', strtotime($ed))."'");
        }else{
            $query = $this->db->query("SELECT sum(courseIncentive) as CI FROM `sales` WHERE mode = 'indirect' AND `transactionDate` BETWEEN '".date('m/d/Y', strtotime($sd))."' AND '".date('m/d/Y', strtotime($ed))."' AND (userId = ".$SR." OR TLId = ".$SR." OR uId = ".$SR.")");
        }
        // echo $query;
        return $query->row_array();
    }
    
    function fullIncentive()
    {
        $result1 = new stdClass();
        // $query = $this->db->query('SELECT 
        //                             coursePriceCommited, 
        //                             couesePriceGiven as couesePriceGive, 
        //                             coursePriceRemain as coursePriceRemain,
        //                             FROM thebatra_incentive.sales GROUP BY studentId, batchId');
        $query = $this->db->query('SELECT 
                                    coursePriceCommited, 
                                    couesePriceGiven as couesePriceGive, 
                                    coursePriceRemain as coursePriceRemain, SUM(courseIncentive) as CI, SUM(incentiveAmtSR) as IASR, SUM(courseIncentiveTeam) as CIT, courseIncentivePer
                                    FROM sales GROUP BY studentId, batchId');
        $result = $query->result();
        foreach($result as $row){
            $result1->coursePriceCommited += (float)$row->coursePriceCommited;
            $result1->couesePriceGive += (float)$row->couesePriceGive;
            $result1->coursePriceRemain += (float)$row->coursePriceRemain;
            $result1->CI += (float)$row->CI;
            $result1->IASR += (float)$row->IASR;
            $result1->CIT += (float)$row->CIT;
            $result1->incentive += (float)$row->coursePriceCommited * ((float)$row->courseIncentivePer / 100);
        }
        return $result1;
    }
    
    function getFullPaymentGiven() {
        $query = $this->db->query('SELECT sum(couesePriceGiven) as CPG, SUM(courseIncentive) as CI, SUM(incentiveAmtSR) as IASR, SUM(courseIncentiveTeam) as CIT FROM `sales`');
        // print_r($query->row_array());
        return $query->row_array();
    }
    
    function getFullPaymentGivenAjax($sd, $ed, $SR = 0) {
        if($SR == 0){
            $query = $this->db->query("SELECT sum(couesePriceGiven) as CPG, SUM(courseIncentive) as CI, SUM(incentiveAmtSR) as IASR, SUM(courseIncentiveTeam) as CIT FROM `sales` WHERE `transactionDate` BETWEEN '".date('m/d/Y', strtotime($sd))."' AND '".date('m/d/Y', strtotime($ed))."'");
        }else{
            $query = $this->db->query("SELECT sum(couesePriceGiven) as CPG, SUM(courseIncentive) as CI, SUM(incentiveAmtSR) as IASR, SUM(courseIncentiveTeam) as CIT FROM `sales` WHERE `transactionDate` BETWEEN '".date('m/d/Y', strtotime($sd))."' AND '".date('m/d/Y', strtotime($ed))."' AND (userId = ".$SR." OR TLId = ".$SR." OR uId = ".$SR.")");
        }
        // print_r($this->db->last_query());
        return $query->row_array();
    }
    
    function getDataAjax($sd, $ed, $id) {
        $query = $this->db->query("SELECT * FROM sales WHERE (`transactionDate` BETWEEN '".date('m/d/Y', strtotime($sd))."' AND '".date('m/d/Y', strtotime($ed))."') AND (userId = ".$id." OR TLId = ".$id." OR uId = ".$id.") GROUP BY studentId, batchId");
        // print_r($this->db->last_query());
        return $query->result();
    }
    
    function getDataSRAjax($id) {
        $query = $this->db->query("SELECT * FROM sales WHERE (userId = ".$id." OR TLId = ".$id." OR uId = ".$id.")");
        // print_r($this->db->last_query());
        return $query->result();
    }
    
    function getFullDataAjax($sd, $ed, $SR = 0) {
        $query = "";
        if($SR != 0){
            // echo 'Hi';
            $query = $this->db->query("SELECT * FROM sales WHERE (`transactionDate` BETWEEN '".date('m/d/Y', strtotime($sd))."' AND '".date('m/d/Y', strtotime($ed))."' AND (userId = ".$SR." OR TLId = ".$SR." OR uId = ".$SR.")) GROUP BY studentId, batchId");
        }else{
            $query = $this->db->query("SELECT * FROM sales WHERE `transactionDate` BETWEEN '".date('m/d/Y', strtotime($sd))."' AND '".date('m/d/Y', strtotime($ed))."' GROUP BY studentId, batchId");
        }
        // print_r($this->db->last_query());
        return $query->result();
    }
    
    function incentiveForTL($id) {
        $query = $this->db->query('SELECT sum(courseIncentiveTeam) as ITL FROM `sales` where TLId = '.$id);
        return $query->result();
    }
    
    function incentiveForSR($id) {
        $query = $this->db->query('SELECT sum(courseIncentive) AS CI FROM `sales` WHERE userId = '.$id);
        // print_r($query->result());
        return $query->result();
    }
    
    function incentiveForSRAjax($sd, $ed, $id) {
        $query = $this->db->query("SELECT sum(courseIncentive) as CI FROM `sales` where `transactionDate` BETWEEN '".date('m/d/Y', strtotime($sd))."' AND '".date('m/d/Y', strtotime($ed))."' AND userId = ".$id);
        // print_r($this->db->last_query());
        return $query->result();
    }
    
    function fullIncentiveForTL() {
        $query = $this->db->query('SELECT sum(courseIncentiveTeam) as ITL FROM `sales`');
        return $query->result();
    }
    
    function incentiveForTLAjax($sd, $ed, $id) {
        $query = $this->db->query("SELECT sum(courseIncentiveTeam) as ITL FROM `sales` where `transactionDate` BETWEEN '".date('m/d/Y', strtotime($sd))."' AND '".date('m/d/Y', strtotime($ed))."' AND TLId = ".$id);
        // print_r($this->db->last_query());
        return $query->result();
    }
    
    function incentiveForTLSRAjax($id) {
        $query = $this->db->query("SELECT sum(courseIncentiveTeam) as ITL FROM `sales` where TLId = ".$id);
        // print_r($this->db->last_query());
        return $query->result();
    }
    
    function incentiveFullForTLAjax($sd, $ed, $SR = 0) {
        if($SR == 0){
        $query = $this->db->query("SELECT sum(courseIncentiveTeam) as ITL FROM `sales` where `transactionDate` BETWEEN '".date('m/d/Y', strtotime($sd))."' AND '".date('m/d/Y', strtotime($ed))."'");
        }else{
            $query = $this->db->query("SELECT sum(courseIncentiveTeam) as ITL FROM `sales` where `transactionDate` BETWEEN '".date('m/d/Y', strtotime($sd))."' AND '".date('m/d/Y', strtotime($ed))."' AND ( TLId = ".$SR." )");    
        }
        // print_r($this->db->last_query());
        return $query->result();
    }
    
    //Second SR Value
    function incentiveForSSR($id) {
        // echo 'Hello';
        $query = $this->db->query('SELECT sum(incentiveAmtSR) as SSR  FROM `sales` where uId = '.$id);
        return $query->result();
    }
    
    function directIncentive($id) {
        $query = $this->db->query("SELECT sum(courseIncentive) as CI FROM `sales` WHERE mode = 'direct' AND (userId = ".$id." OR uId = ".$id." OR TLId = ".$id.")");
        // print_r($query->result());
        return $query->row_array();
    }
    
    function inDirectIncentive($id) {
        $query = $this->db->query("SELECT sum(courseIncentive) as CI FROM `sales` WHERE mode = 'indirect' AND (userId = ".$id." OR uId = ".$id." OR TLId = ".$id.")");
        // print_r($query->result());
        return $query->row_array();
    }
    
    function directIncentiveAjax($sd, $ed, $id) {
        $query = $this->db->query("SELECT sum(courseIncentive) as CI FROM `sales` WHERE `transactionDate` BETWEEN '".date('m/d/Y', strtotime($sd))."' AND '".date('m/d/Y', strtotime($ed))."' AND (userId = ".$id." OR TLId = ".$id." OR uId = ".$id.") AND mode = 'direct'");
        return $query->row_array();
    }
    
    function inDirectIncentiveAjax($sd, $ed, $id) {
        $query = $this->db->query("SELECT sum(courseIncentive) as CI FROM `sales` WHERE `transactionDate` BETWEEN '".date('m/d/Y', strtotime($sd))."' AND '".date('m/d/Y', strtotime($ed))."' AND (userId = ".$id." OR TLId = ".$id." OR uId = ".$id.") AND mode = 'indirect'");
        return $query->row_array();
    }
    
    function incentiveForSSRAjax($sd, $ed, $id) {
        $query = $this->db->query("SELECT sum(incentiveAmtSR) as SSR FROM `sales` where `transactionDate` BETWEEN '".date('m/d/Y', strtotime($sd))."' AND '".date('m/d/Y', strtotime($ed))."' AND uId = ".$id);
        // print_r($this->db->last_query());
        return $query->result();
    }
    
    function incentiveForSSRSRAjax($id) {
        $query = $this->db->query("SELECT sum(incentiveAmtSR) as SSR FROM `sales` where uId = ".$id);
        // print_r($this->db->last_query());
        return $query->result();
    }
    
    function incentiveFullForSSRAjax($sd, $ed, $SR = 0) {
        if($SR == 0){
        $query = $this->db->query("SELECT sum(incentiveAmtSR) as SSR FROM `sales` where `transactionDate` BETWEEN '".date('m/d/Y', strtotime($sd))."' AND '".date('m/d/Y', strtotime($ed))."'");
        }else{
            $query = $this->db->query("SELECT sum(incentiveAmtSR) as SSR FROM `sales` where `transactionDate` BETWEEN '".date('m/d/Y', strtotime($sd))."' AND '".date('m/d/Y', strtotime($ed))."' AND uId = ".$SR);
        }
        // print_r($this->db->last_query());
        return $query->result();
    }
    
    function checkTL($id) {
        $query = $this->db->query('SELECT * FROM users where userId = '.$id);
        // print_r($query->result());
        return $query->result();
    }
    
    function fullCheckTL() {
        $query = $this->db->query('SELECT * FROM users');
        // print_r($query->result());
        return $query->result();
    }
    
    function studentList($id) {
        $query = $this->db->query("SELECT * FROM sales WHERE (userId = ".$id." OR TLId = ".$id." OR uId = ".$id.") GROUP BY studentId, batchId");
        // print_r($this->db->last_query());
        return $query->result();
    }
    
    function totalCoursePriceGiven($id, $batchId, $userId = 0) {
        $query = $this->db->query("SELECT SUM(couesePriceGiven) as coursePriceGiven, SUM(courseIncentive) as CI FROM `sales` WHERE `studentId` = ".$id." AND `batchId` = ".$batchId." AND (`userId` = ".$userId." OR `TLId` = ".$userId." OR `uId` = ".$userId.")");
        // print_r($this->db->last_query());
        return $query->result();
    }
    
    function totalCoursePriceGivenAjax($sd, $ed, $id, $batchId, $userId = 0) {
        $query = $this->db->query("SELECT SUM(couesePriceGiven) as coursePriceGiven, SUM(courseIncentive) as CI FROM `sales` WHERE (`transactionDate` BETWEEN '".date('m/d/Y', strtotime($sd))."' AND '".date('m/d/Y', strtotime($ed))."') and `studentId` = ".$id." AND `batchId` = ".$batchId);
        // print_r($this->db->last_query());
        return $query->result();
    }
    
    function courseName($batchId) {
        $query = $this->db->query("SELECT `courseId` FROM batches WHERE batchId = ".$batchId);
        $result = $query->row();
        foreach($result as $row) {
            $query1 = $this->db->query("SELECT * FROM `courses` WHERE courseId = ".$row);
            return $query1->row();
        }
    }
    
    function fullStudentList() {
        $query = $this->db->query("SELECT * FROM sales  GROUP BY studentId, batchId");
        // print_r($this->db->last_query());
        return $query->result();
    }
    function getAllUsers3()
    { 
        $query = $this->db->get('users');
        $query = $this->db->query('SELECT * FROM users where roleId=2');
        return $query->result();
    }
     function getAllUsers_1()
    { 
        $query = $this->db->get('users');
        $query = $this->db->query('SELECT * FROM users where roleId=3');
        return $query->result();
    }
     function getAllUsers2()
    { 
        $query = $this->db->get('users');
        $query = $this->db->query('SELECT * FROM users where roleId=4');
        return $query->result();
    }

     /* Update batch data into the database */
    public function update($data, $id) {
        if(!empty($data) && !empty($id)){
            // Add modified date if not included
            if(array_key_exists("updatedDate", $data)){
                date_default_timezone_set("Asia/Kolkata");
                $data['updatedDate'] = date("Y-m-d H:i:s");
            }
            
            // Update batch data
            $update = $this->db->update($this->table, $data, array('incentiveId' => $id));
            
            // Return the status
            return $update?true:false;
        }
        return false;
    }
    
    //Setting Related Model Codes
    public function updateSetting($data, $id) {
        if(!empty($data) && !empty($id)) {
            if(array_key_exists("updatedAt", $data)){
                date_default_timezone_set("Asia/Kolkata");
                $data['updatedAt'] = date("Y-m-d H:i:s");
            }
            
            $update = $this->db->update('gstSetting', $data, array('settingId' => $id));
            
            return $update?true:false;
        }
        return false;
    }
    
    public function getGstData() {
        $query = $this->db->query('SELECT * FROM gstSetting');
        $result = $query->row_array();
        return $result;
    }
    
    public function getSalesData() {
        $query = $this->db->query('SELECT * FROM sales');
        $result = $query->result();
        // print_r($result);
        return $result;
    }
    
    public function getCourseName($batchId) {
        $query = $this->db->query('SELECT * FROM `batches` WHERE batchId = '.$batchId);
        $result = $query->row_array();
        $queryCourse = $this->db->query('SELECT * FROM `courses` WHERE courseId = '.$result['courseId']);
        $resultCourse = $queryCourse->row_array();
        return $resultCourse;
    }
    //End Setting Related Model Codes
    
     /* Delete batch data from the database*/
    public function delete($id){
        // Delete batch data
        $delete = $this->db->delete($this->table, array('incentiveId' => $id));
        // Return the status
        return $delete?true:false;
    }

}


