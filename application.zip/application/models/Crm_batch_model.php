<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Crm_batch_model extends CI_Model{

    function __construct() {
        $this->table = 'leads';
    }
    
    //Insert Function For Email Content
    public function insert($data = array()) {
        if(!empty($data)){
            // Add created and modified date if not included
            if(array_key_exists("createdAt", $data)){
                date_default_timezone_set("Asia/Kolkata");
                $data['createdAt'] = date("Y-m-d H:i:s");
                $data['ipAddress'] = $ip = $_SERVER['REMOTE_ADDR'];
                
                $ipdat = file_get_contents(
                        "http://www.geoplugin.net/json.gp?ip=" . $ip);
                $jsondata = json_decode($ipdat);
                $countryfromip = $jsondata->geoplugin_countryName;
                $cityfromip = $jsondata->geoplugin_city;
                $data['location'] = $cityfromip;
                $data['latitude'] = $jsondata->geoplugin_latitude;
                $data['longitude'] = $jsondata->geoplugin_longitude;
            }
            // print_r($data);
            // Insert course data
            $insert = $this->db->insert($this->table, $data);
            
            // Return the status
            return $insert?$this->db->insert_id():false;
        }
        return false;
    }
    
    public function batchData() {
        $batchLeads = $this->db->query("SELECT * FROM `leadsBatches`");
        return $batchLeads->result();
    }
    
    public function courseName($courseId) {
        $courseName = $this->db->query("SELECT * FROM `courses` WHERE `courseId`=".$courseId);
        return $courseName->row_array()['courseName'];
    }
    
    public function studentName($studentId) {
        $studentName = $this->db->query("SELECT * FROM `leads` WHERE `id`=".$studentId);
        return $studentName->row_array()['name'];
    }
    
    public function insertRMMaster($data = array()) {
        if(!empty($data)) {
            $insert = $this->db->insert("RMMaster", $data);
            
            return $insert?$this->db->insert_id():false;
        }
        return false;
    }
    
    public function insertFollowup($data = array()) {
        if(!empty($data)){
            // Add created and modified date if not included
            if(array_key_exists("createdAt", $data)){
                date_default_timezone_set("Asia/Kolkata");
                $data['createdAt'] = date("Y-m-d H:i:s");
                $data['ipAddress'] = $ip = $_SERVER['REMOTE_ADDR'];
                
                $ipdat = file_get_contents(
                        "http://www.geoplugin.net/json.gp?ip=" . $ip);
                $jsondata = json_decode($ipdat);
                $countryfromip = $jsondata->geoplugin_countryName;
                $cityfromip = $jsondata->geoplugin_city;
                $data['location'] = $cityfromip;
                $data['latitude'] = $jsondata->geoplugin_latitude;
                $data['longitude'] = $jsondata->geoplugin_longitude;
            }
            // print_r($data);
            // Insert course data
            $insert = $this->db->insert('followup', $data);
            
            // Return the status
            return $insert?$this->db->insert_id():false;
        }
        return false;
    }
    
    function get_leads() {
        $query = $this->db->get($this->table);
        if($query->num_rows() > 0) {
            return $query->result_array();
        }else{
            return FALSE;
        }
    }
    
    function updateFollowup($data, $leadId) {
        if(!empty($data) && !empty($leadId)){
            $update = $this->db->update('followup', $data, array('leadId' => $leadId));
            return $update?true:false;
        }else{
            return false;
        }
    }
    
    function updateLeads($data, $leadId) {
        if(!empty($data) && !empty($leadId)) {
            $update = $this->db->update('leads', $data, array('id' => $leadId));
            return $update?true:false;
        }else{
            return false;
        }
    }
    
    function getExistingCourses($studentEmail) {
        if(!empty($studentEmail)) {
            $studentDetails = $this->db->query("SELECT * FROM `students` WHERE studentEmail = '".$studentEmail."'");
            $studentId = $studentDetails->row_array()['studentId'];
            if(!empty($studentId)){
                $studentBatch = $this->db->query("SELECT * FROM `sales` WHERE studentId = ".$studentId);
                $studentBatchId = $studentBatch->row_array()['batchId'];
                if(!empty($studentBatchId)){
                    $batchDetails = $this->db->query("SELECT * FROM `batches` WHERE batchId = ".$studentBatchId);
                    $batchName = $batchDetails->row_array()['batchName'];
                    return $batchName;
                }else{
                    return false;
                }
            }else{
                return false;
            }
        }else{
            return false;
        }
    }
    
    function getLeadStatus($studentEmail) {
        if(!empty($studentEmail)) {
            $studentDetails = $this->db->query("SELECT * FROM `students` WHERE studentEmail = '".$studentEmail."'");
            $studentId = $studentDetails->row_array()['studentId'];
            return $studentId;
        }else{
            return false;
        }
    }
    
    function getLatestFollowup($leadId) {
        if(!empty($leadId)) {
            $leadFollowup = $this->db->query("SELECT * FROM `followup` WHERE leadId = ".$leadId);
            return $leadFollowup->row_array();
        }
    }
    
    function fetchRMMaster() {
        $RMQuery = $this->db->query("SELECT * FROM `RMMaster`");
        return $RMQuery->result();
    }
}

?>