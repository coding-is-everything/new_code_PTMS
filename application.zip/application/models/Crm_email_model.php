<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Crm_email_model extends CI_Model{

    function __construct() {
        $this->table = 'emails';
    }
    
    //Insert Function For Email Content
    public function insert($data = array()) {
        if(!empty($data)){
            // Add created and modified date if not included
            if(array_key_exists("createdAt", $data)){
                date_default_timezone_set("Asia/Kolkata");
                $data['createdAt'] = date("Y-m-d H:i:s");
                $data['ipAddress'] = $ip = $_SERVER['REMOTE_ADDR'];
                
                $ipdat = file_get_contents(
                        "http://www.geoplugin.net/json.gp?ip=" . $ip);
                $jsondata = json_decode($ipdat);
                $countryfromip = $jsondata->geoplugin_countryName;
                $cityfromip = $jsondata->geoplugin_city;
                $data['location'] = $cityfromip;
                $data['latitude'] = $jsondata->geoplugin_latitude;
                $data['longitude'] = $jsondata->geoplugin_longitude;
            }
            // print_r($data);
            // Insert course data
            $insert = $this->db->insert($this->table, $data);
            
            // Return the status
            return $insert?$this->db->insert_id():false;
        }
        return false;
    }
    
    function getRows($params = array()){
        $this->db->select('*');
        $this->db->from($this->table);
        if(array_key_exists("returnType",$params) && $params['returnType'] == 'count'){
            $result = $this->db->count_all_results();
        }else{
            if(array_key_exists("id", $params)){
                $this->db->where('id', $params['id']);
                $query = $this->db->get();
                $result = $query->row_array();
            }else{
                $this->db->order_by('id', 'desc');
                $query = $this->db->get();
                $result = ($query->num_rows() > 0)?$query->result_array():FALSE;
            }
        }
        
        // Return fetched data
        return $result;
    }
}

?>