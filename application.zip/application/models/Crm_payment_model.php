<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Crm_payment_model extends CI_Model{

    function __construct() {
        $this->table = 'paymentFollowup';
    }
    
    public function getPaymentData() {
        $paymentQuery = $this->db->query("SELECT * FROM paymentFollowup");
        return $paymentQuery->result_array();
    }
    
    //Insert Function For Email Content
    public function insert($data = array()) {
        if(!empty($data)){
            // Add created and modified date if not included
            if(array_key_exists("createdAt", $data)){
                date_default_timezone_set("Asia/Kolkata");
                $data['createdAt'] = date("Y-m-d H:i:s");
                $data['ipAddress'] = $ip = $_SERVER['REMOTE_ADDR'];
                
                $ipdat = file_get_contents(
                        "http://www.geoplugin.net/json.gp?ip=" . $ip);
                $jsondata = json_decode($ipdat);
                $countryfromip = $jsondata->geoplugin_countryName;
                $cityfromip = $jsondata->geoplugin_city;
                $data['location'] = $cityfromip;
                $data['latitude'] = $jsondata->geoplugin_latitude;
                $data['longitude'] = $jsondata->geoplugin_longitude;
            }
            // print_r($data);
            // Insert course data
            $insert = $this->db->insert($this->table, $data);
            
            // Return the status
            return $insert?$this->db->insert_id():false;
        }
        return false;
    }
    
    public function insertRMMaster($data = array()) {
        if(!empty($data)) {
            $insert = $this->db->insert("RMMaster", $data);
            
            return $insert?$this->db->insert_id():false;
        }
        return false;
    }
    
    public function insertFollowup($data = array()) {
        if(!empty($data)){
            // Add created and modified date if not included
            if(array_key_exists("createdAt", $data)){
                date_default_timezone_set("Asia/Kolkata");
                $data['createdAt'] = date("Y-m-d H:i:s");
                $data['ipAddress'] = $ip = $_SERVER['REMOTE_ADDR'];
                
                $ipdat = file_get_contents(
                        "http://www.geoplugin.net/json.gp?ip=" . $ip);
                $jsondata = json_decode($ipdat);
                $countryfromip = $jsondata->geoplugin_countryName;
                $cityfromip = $jsondata->geoplugin_city;
                $data['location'] = $cityfromip;
                $data['latitude'] = $jsondata->geoplugin_latitude;
                $data['longitude'] = $jsondata->geoplugin_longitude;
            }
            // print_r($data);
            // Insert course data
            $insert = $this->db->insert('followup', $data);
            
            // Return the status
            return $insert?$this->db->insert_id():false;
        }
        return false;
    }
    
    public function insertActivityLogs($data = array()) {
        if(!empty($data)) {
            if(array_key_exists("createdAt", $data)) {
                date_default_timezone_set("Asia/Kolkata");
                $data['createdAt'] = date("Y-m-d H:i:s");
                $data['ipAddress'] = $id = $_SERVER['REMOTE_ADDR'];
                $ipdat = file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip);
                $jsondata = json_decode($ipdat);
                $countryfromip = $jsondata->geoplugin_countryName;
                $cityfromip = $jsondata->geoplugin_city;
                $data['location'] = $cityfromip;
                $data['latitude'] = $jsondata->geoplugin_latitude;
                $data['longitude'] = $jsondata->geoplugin_longitude;
            }
            $insert = $this->db->insert("activityLogs", $data);
            echo $this->db->last_query();
            return $insert?$this->db->insert_id():false;
        }
        return false;
    }
    
    function get_leads($id = null) {
        if(!empty($id)){
            $query = $this->db->query("SELECT * FROM `leads` WHERE `RMId` = ".$id);
            if($query->num_rows() > 0) {
                return $query->result_array();
            }else{
                return FALSE;
            }
        }else{
            $query = $this->db->get($this->table);
            if($query->num_rows() > 0) {
                return $query->result_array();
            }else{
                return FALSE;
            }
        }
    }
    
    function getOldRMDetails($RMId) {
        if(!empty($RMId)) {
            echo $RMId;
        }
    }
    
    function getUsers() {
        $query = $this->db->query("SELECT * FROM users");
        if($query->num_rows() > 0) {
            return $query->result();
        }else{
            return FALSE;
        }
    }
    
    function getRMMasterView() {
        $query = $this->db->query("SELECT * FROM RMMaster");
        if($query->num_rows() > 0) {
            return $query->result();
        }else{
            return FALSE;
        }
    }
    
    function get_leads_student($id) {
        if(!empty($id)) {
            $query = $this->db->query("SELECT * FROM leads WHERE RMAutoAssignId = (SELECT userId FROM RMMaster WHERE userMasterId = ".$id.")");
            if($query->num_rows() > 0) {
                return $query->result_array();
            }else{
                return FALSE;
            }
        }else{
            return FALSE;
        }
    }
    
    function getLeadsByAjax($sd, $ed, $RMId = 0) {
        // echo $sd." ".$ed." ".$roleId;
        $roleId = $this->session->userdata('userId');
        if(!empty($sd) && !empty($sd) && empty($RMId)) {
            $query = $this->db->query("SELECT * FROM leads WHERE `transactionDate` BETWEEN '".date('Y-m-d', strtotime($sd))."' AND '".date('Y-m-d', strtotime($ed))."'");
        }else{
            $query = $this->db->query("SELECT * FROM leads WHERE `transactionDate` BETWEEN '".date('Y-m-d', strtotime($sd))."' AND '".date('Y-m-d', strtotime($ed))."' AND `RMAutoAssignId` = ".$RMId);
        }
        print_r($this->db->last_query());
        return $query->result_array();
    }
    
    function getRMLeadsByAjax($rmId) {
        if(!empty($rmId)) {
            $query = $this->db->query("SELECT * FROM leads WHERE `RMAutoAssignId` = ".$rmId);
        }
        return $query->result_array();
    }
    
    function getLeadsByAjaxRM($sd, $ed, $roleId, $id) {
        // echo $sd." ".$ed." ".$roleId;
        $roleId = $this->session->userdata('userId');
        $RMIdQuery = $this->db->query("SELECT * FROM RMMaster WHERE userMasterId = ".$id);
        $resultRMId = $RMIdQuery->row_array()['userId'];
        if(!empty($sd) && !empty($sd)) {
            $query = $this->db->query("SELECT * FROM leads WHERE `transactionDate` BETWEEN '".date('Y-m-d', strtotime($sd))."' AND '".date('Y-m-d', strtotime($ed))."' AND (`RMAutoAssignId` = ".$id." OR `RMAutoAssignId` =".$resultRMId." )");
        }else{
            $query = $this->db->query("SELECT * FROM leads WHERE `transactionDate` BETWEEN '".date('Y-m-d', strtotime($sd))."' AND '".date('Y-m-d', strtotime($ed))."' AND `RMId = ".$roleId." AND `RMAutoAssignId = ".$id);
        }
        // print_r($this->db->last_query());
        return $query->result_array();
    }
    
    function getContactedLeadsDetails($id, $SD = 0, $ED = 0) {
        if(!empty($id) && empty($SD) && empty($ED)) {
            $query = $this->db->query("SELECT count(*) as cCount FROM followup WHERE (RMId = ".$id." OR RMId2 = ".$id." OR RMId3 = ".$id." OR RMId4 = ".$id." OR RMId5 = ".$id.")");
        }else{
            $query = $this->db->query("SELECT count(*) as cCount FROM followup WHERE (RMId = ".$id." OR RMId2 = ".$id." OR RMId3 = ".$id." OR RMId4 = ".$id." OR RMId5 = ".$id.") AND ((`followupDate1` BETWEEN '".date('Y-m-d', strtotime($SD))."' AND '".date('Y-m-d', strtotime($ED))."') OR (`followupDate2` BETWEEN '".date('Y-m-d', strtotime($SD))."' AND '".date('Y-m-d', strtotime($ED))."') OR (`followupDate3` BETWEEN '".date('Y-m-d', strtotime($SD))."' AND '".date('Y-m-d', strtotime($ED))."') OR (`followupDate4` BETWEEN '".date('Y-m-d', strtotime($SD))."' AND '".date('Y-m-d', strtotime($ED))."') OR (`followupDate5` BETWEEN '".date('Y-m-d', strtotime($SD))."' AND '".date('Y-m-d', strtotime($ED))."'))");
        }
        return $query->row_array();
    }
    
    function getNotContactedLeadsDetails($id, $SD = 0, $ED = 0) {
        if(!empty($id) && empty($SD) && empty($ED)) {
            $query = $this->db->query("SELECT count(*) as ncCount FROM followup WHERE (RMId != ".$id." OR RMId2 != ".$id." OR RMId3 != ".$id." OR RMId4 != ".$id." OR RMId5 != ".$id.")");
        }else{
            $query = $this->db->query("SELECT count(*) as ncCount FROM followup WHERE (RMId != ".$id." OR RMId2 != ".$id." OR RMId3 != ".$id." OR RMId4 != ".$id." OR RMId5 != ".$id.") AND ((`followupDate1` BETWEEN '".date('Y-m-d', strtotime($SD))."' AND '".date('Y-m-d', strtotime($ED))."') OR (`followupDate2` BETWEEN '".date('Y-m-d', strtotime($SD))."' AND '".date('Y-m-d', strtotime($ED))."') OR (`followupDate3` BETWEEN '".date('Y-m-d', strtotime($SD))."' AND '".date('Y-m-d', strtotime($ED))."') OR (`followupDate4` BETWEEN '".date('Y-m-d', strtotime($SD))."' AND '".date('Y-m-d', strtotime($ED))."') OR (`followupDate5` BETWEEN '".date('Y-m-d', strtotime($SD))."' AND '".date('Y-m-d', strtotime($ED))."'))");
        }
        return $query->row_array();
    }
    
    function getLeadCount($id, $SD = 0, $ED = 0) {
        if(!empty($id) && empty($SD) && empty($SD)) {
            $query = $this->db->query("SELECT count(*) as leadCount FROM leads WHERE RMAutoAssignId = (SELECT userId FROM RMMaster WHERE userMasterId = ".$id.") AND status = 0");
        }else{
            $query = $this->db->query("SELECT count(*) as leadCount FROM leads WHERE `transactionDate` BETWEEN '".date('Y-m-d', strtotime($SD))."' AND '".date('Y-m-d', strtotime($ED))."' AND RMAutoAssignId = (SELECT userId FROM RMMaster WHERE userMasterId = ".$id.") AND status = 0");
        }
        // print_r($this->db->last_query());
        return $query->row_array();
    }
    
    function updateLeadStatus($id) {
        if(!empty($id)) {
            $query = $this->db->update('leads', array('status' => 1), array('RMAutoAssignId' => $id));
            if($query > 0){
                return TRUE;
            }else{
                return FALSE;
            }
        }
    }
    
    function updateFollowup($data, $leadId) {
        if(!empty($data) && !empty($leadId)){
            $update = $this->db->update('followup', $data, array('leadId' => $leadId));
            return $update?true:false;
        }else{
            return false;
        }
    }
    
    function update($data, $id) {
        if(!empty($data) && !empty($id)) {
            $update = $this->db->update('RMMaster', $data, array('userId' => $id));
            return $update?true:false;
        }else{
            return false;
        }
    }
    
    function updateLeads($data, $leadId) {
        // print_r('Hello'.$leadId);
        if(!empty($data) && !empty($leadId)) {
            $update = $this->db->update('leads', $data, array('id' => $leadId));
            return $update?true:false;
        }else{
            return false;
        }
    }
    
    function getLeadData($id) {
        if(!empty($id)) {
            $data = $this->db->query("SELECT * FROM `leads` WHERE id = ".$id);
            // print_r($data->row_array());
            return $data->row_array();
        }else{
            return false;
        }
    }
    
    function getRMMaster() {
        $data = $this->db->query("SELECT * FROM `RMMaster`");
        return $data->result();
    }
    
    function getExistingCourses($studentEmail) {
        if(!empty($studentEmail)) {
            $studentDetails = $this->db->query("SELECT * FROM `students` WHERE studentEmail = '".$studentEmail."'");
            $studentId = $studentDetails->row_array()['studentId'];
            if(!empty($studentId)){
                $studentBatch = $this->db->query("SELECT * FROM `sales` WHERE studentId = ".$studentId);
                $studentBatchId = $studentBatch->row_array()['batchId'];
                if(!empty($studentBatchId)){
                    $batchDetails = $this->db->query("SELECT * FROM `batches` WHERE batchId = ".$studentBatchId);
                    $batchName = $batchDetails->row_array()['batchName'];
                    return $batchName;
                }else{
                    return false;
                }
            }else{
                return false;
            }
        }else{
            return false;
        }
    }
    
    function getLeadStatus($studentEmail) {
        if(!empty($studentEmail)) {
            $studentDetails = $this->db->query("SELECT * FROM `students` WHERE studentEmail = '".$studentEmail."'");
            $studentId = $studentDetails->row_array()['studentId'];
            return $studentId;
        }else{
            return false;
        }
    }
    
    function getLatestFollowup($leadId) {
        if(!empty($leadId)) {
            $leadFollowup = $this->db->query("SELECT * FROM `followup` WHERE leadId = ".$leadId);
            return $leadFollowup->row_array();
        }
    }
    
    function getLeadsForToday() {
        $today = date('Y-m-d');
        $query = $this->db->query("SELECT * FROM `followup` WHERE followupDate1 = '".$today."' or followupDate2 = '".$today."' or followupDate3 = '".$today."' or followupDate4 = '".$today."' or followupDate5 = '".$today."'");
        return $query->result();
    }
    
    function getLeadsForTodayByStaff($id) {
        if(!empty($id)) {
            $today = date('Y-m-d');
            $query = $this->db->query("SELECT * FROM `followup` WHERE (followupDate1 = '".$today."' or followupDate2 = '".$today."' or followupDate3 = '".$today."' or followupDate4 = '".$today."' or followupDate5 = '".$today."') AND RMId = ".$id); //(SELECT userId FROM RMMaster WHERE userMasterId = ".$id.")
            // print_r($this->db->last_query());
            return $query->result();
        }
    }
    
    function getLeadsDetails($leadsId) {
        if(!empty($leadsId)) {
            $query = $this->db->query("SELECT * FROM leads WHERE id = ".$leadsId);
            return $query->row_array();
        }
    }
    
    function getTotalFollowup() {
        $today = date('Y-m-d');
        $i = 0;
        $query = $this->db->query("SELECT count(*) as count FROM `followup` WHERE followupDate1 = '".$today."' or followupDate2 = '".$today."' or followupDate3 = '".$today."' or followupDate4 = '".$today."' or followupDate5 = '".$today."'");
        // print_r($this->db->last_query());
        return $query->row_array();
    }
    
    function getTotalFollowupByStaff($userId) {
        $today = date('Y-m-d');
        $query = $this->db->query("SELECT count(*) as count FROM `followup` WHERE (followupDate1 = '".$today."' or followupDate2 = '".$today."' or followupDate3 = '".$today."' or followupDate4 = '".$today."' or followupDate5 = '".$today."') AND RMId = ".$userId); //(SELECT userId FROM RMMaster WHERE userMasterId = ".$userId.")
        // print_r($this->db->last_query());
        return $query->row_array();
    }
    
    function fetchRMMaster() {
        $RMQuery = $this->db->query("SELECT * FROM `RMMaster`");
        // print_r($this->db->last_query());
        return $RMQuery->result();
    }
    
    function fetchSingleRM($id) {
            $query = $this->db->query("SELECT * FROM `RMMaster` WHERE userId = ".$id);
            // print_r($this->db->last_query());
            return $query->row_array();
    }
    
    function getRMRole($id) {
        $query = $this->db->query("SELECT RMRole FROM RMMaster WHERE userMasterId = ". $id);
        return $query->row_array()['RMRole'];
    }
}

?>