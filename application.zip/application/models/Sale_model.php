<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Sale_model extends CI_Model{
function __construct() {
        // Set table name
        $this->table = 'sales';
    }
     /* Fetch  data from the database */
    function getRows($params = array()){
        $this->db->select('*');
        $this->db->from($this->table);
       if(array_key_exists("returnType",$params) && $params['returnType'] == 'count'){
            $result = $this->db->count_all_results();
        }else{
            if(array_key_exists("saleId", $params)){
                $this->db->where('saleId', $params['saleId']);
                $query = $this->db->get();
                $result = $query->row_array();
            }else{
                $this->db->order_by('saleId', 'desc');           
                $query = $this->db->get();
                $result = ($query->num_rows() > 0)?$query->result_array():FALSE;
            }
        }   
        return $result;
    }
    
    function getAjaxRows($sd, $ed, $roleId) {
        if($roleId == 1){
            $query = $this->db->query("SELECT * FROM `sales` WHERE `transactionDate` BETWEEN '".date('m/d/Y', strtotime($sd))."' AND '".date('m/d/Y', strtotime($ed))."'");
           // print_r($this->db->last_query());
        }else{
            $userId = $this->session->userdata('userId');
            $query = $this->db->query("SELECT * FROM `sales` WHERE `transactionDate` BETWEEN '".date('m/d/Y', strtotime($sd))."' AND '".date('m/d/Y', strtotime($ed))."' AND userId = ".$userId);
        }
        return $query->result_array();
        
    }
    
    function selectBalance($id, $batchId) {
        $result = $this->db->query("SELECT * FROM sales WHERE saleId = ".$id." AND batchId = ".$batchId);
        // print_r($this->db->last_query());
        if($result->num_rows() > 0) {
            return $result->row_array();
        }else{
            return 0;
        }
    }
    
    function updateShortClose($id, $batchId, $coursePriceRemain, $newGiven){
        if(!empty($id)){
            $query = $this->db->query('UPDATE `sales` SET coursePriceRemain = '.$coursePriceRemain.', couesePriceGiven = '.$newGiven.', shortClosedFlag = 1 WHERE saleId = '.$id.' AND batchId = '.$batchId);
            // print_r($this->db->last_query());
            // exit();
            return $query?true:false;
        }else{
            return false;
        }
    }
    
    function viewShortClose() {
        $query = $this->db->query("SELECT * FROM `sales` WHERE shortClosedFlag = 1");
        // print_r($this->db->last_query());
        return $query->result();
    }
    
    function getInvoiceId($id) {
        $query = $this->db->query('SELECT * FROM invoices WHERE saleId = '.$id);
        return $query->row_array();
    }

    function getRows1($params = array()){
        $this->db->select('*');
        $this->db->from($this->table);
        $this->db->where('userId',$this->session->userdata('userId')); 
       if(array_key_exists("returnType",$params) && $params['returnType'] == 'count'){
            $result = $this->db->count_all_results();
        }else{
            if(array_key_exists("saleId", $params)){
                $this->db->where('saleId', $params['saleId']);
                $query = $this->db->get();
                $result = $query->row_array();
            }else{
                $this->db->order_by('saleId', 'desc');           
                $query = $this->db->get();
                $result = ($query->num_rows() > 0)?$query->result_array():FALSE;
            }
        }   
        return $result;
    }

    
     /* Insert batch data into the database*/
   
    function insert($data = array()) {
        if(!empty($data)){
            // Add created and modified date if not included
            if($this->session->userdata('roleId') == '1'){
            if(array_key_exists("createdDate", $data)){
                date_default_timezone_set("Asia/Kolkata");
                $data['createdDate'] = date("Y-m-d H:i:s");
            }
            }
            else{
            if(array_key_exists("createdDate", $data)){
                date_default_timezone_set("Asia/Kolkata");
                $data['createdDate'] = date("Y-m-d H:i:s");
                $data['userId'] = $this->session->userdata('userId');
            }
            }
            // Insert batch data
            $insert = $this->db->insert($this->table, $data);
            
            // Return the status
            return $insert?$this->db->insert_id():false;
        }
        return false;
    }
    
     
  
/*select  dropdown */
  function getAllBatches()
    { 
        $query = $this->db->get('batches');
        $query = $this->db->query('SELECT * FROM batches INNER JOIN courses ON batches.courseId=courses.courseId');
        return $query->result();
        //SELECT * FROM batches INNER JOIN courses ON batches.courseId=courses.courseId
    }
    function getAllUsers()
    { 
        $query = $this->db->get('users');
        $query = $this->db->query('SELECT * FROM users where roleId=2');
        return $query->result();
    }
     function getAllUsers1()
    { 
        $query = $this->db->get('users');
        $query = $this->db->query('SELECT * FROM users where roleId=3');
        return $query->result();
    }
     function getAllUsers2()
    { 
        $query = $this->db->get('users');
        $query = $this->db->query('SELECT * FROM users where roleId=4');
        return $query->result();
    }
    function getAllStudents()
    { 
        $query = $this->db->get('students');
        $query = $this->db->query('SELECT * FROM students');
        return $query->result();
    }
    
    function batchDetails($id) {
        $query = $this->db->query('SELECT * FROM batches WHERE batchId = '.$id);
        return $query->row_array();
    }
    
    function getPreviousFee($batchId, $studentId)
    {
        $query = $this->db->get('sales');
        $query = $this->db->query('SELECT SUM(couesePriceGiven) as previousFee, SUM(courseDiscount) as CD FROM `sales` WHERE batchId = '.$batchId.' AND studentId='.$studentId);
        // print_r($query->result());
        if($query->result() !== null) {
            return $query->result();
        }else{
            return 0;
        }
    }
    
    function getMode($batchId, $studentId)
    {
        $query = $this->db->get('sales');
        $query = $this->db->query('SELECT * FROM `sales` WHERE batchId = '.$batchId.' AND studentId='.$studentId.' ORDER by createdDate DESC');
        // print_r($query->result());
        if($query->result() !== null) {
            return $query->result();
        }else{
            return 0;
        }
    }
    
    function getPreviousMode($batchId, $studentId)
    {
        $query = $this->db->get('sales');
        $query = $this->db->query('SELECT * FROM `sales` WHERE batchId = '.$batchId.' AND studentId = '.$studentId.' ORDER BY `createdDate` DESC');
        // print_r($this->db->last_query());
        if($query->result() !== null) {
            return $query->row();
        }else{
            return 0;
        }
    }
    
    function getSRId($SRId) {
        $query = $this->db->query('SELECT * FROM `users` WHERE userId = '.$SRId);
        return $query->result();
    }
    
    function getFeeAmount()
    {
        $result = $this->db->query("SELECT SUM(coursePriceCommited), 
                                    SUM(couesePriceGiven), 
                                    SUM(coursePriceRemain) FROM 
                                    thebatra_incentive.sales")->result_array();
        return $result;
    }

    function getIncentiveAmount()
    {
        $result = $this->db->query("SELECT SUM(courseIncentive), 
                                    SUM(courseIncentiveTeam) FROM 
                                    thebatra_incentive.sales")->result_array();
        return $result;
    }


 public function getLastId()
    {
       $result = $this->db->select("saleId")->limit(1)->order_by('saleId',"DESC")->get("sales")->row();
       $result1 = $result->saleId;
        //print_r($result1); exit();
        return $result1;
    }

/* generate invoice number*/
public function invoice_num($data = array()){
    if(array_key_exists("createdDate", $data)){
                date_default_timezone_set("Asia/Kolkata");
                $data['createdDate'] = date("Y-m-d H:i:s");
            }
    $data = array(
        'invoiceId'=>"TBN-".date("Y")."-".$this->getLastId(),
        'saleId' => $this->getLastId(),
    );

    $this->db->insert('invoices',$data);
  }






    
     /* Update batch data into the database */
    public function update($data, $id) {
    	
        if(!empty($data) && !empty($id)){
            // Add modified date if not included
            if($this->session->userdata('roleId') == '1'){
            if(array_key_exists("updatedDate", $data)){
                date_default_timezone_set("Asia/Kolkata");
                $data['updatedDate'] = date("Y-m-d H:i:s");
            }
            }
            else
            {
             if(array_key_exists("updatedDate", $data)){
                date_default_timezone_set("Asia/Kolkata");
                $data['updatedDate'] = date("Y-m-d H:i:s");
                $data['userId'] = $this->session->userdata('userId');
            }
            }
            // Update batch data
            $update = $this->db->update($this->table, $data, array('saleId' => $id));
            
            // Return the status
            return $update?true:false;
        }
        return false;
    }

   
     /* Delete batch data from the database*/
    public function delete($id){
        // Delete batch data
        $delete = $this->db->delete($this->table, array('saleId' => $id));
        // Return the status
        return $delete?true:false;
    }

}


