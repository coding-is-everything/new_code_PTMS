<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Property_model extends CI_Model{

function __construct() {
        // Set table name
        $this->table = 'property';
    }
    
    function totalProperty() {
        $query = $this->db->query("SELECT count(*) as totalProperty FROM `property` WHERE deleted IS NULL or deleted = 0");
        return $query->result();
    }
    
    function approvedProperty() {
        $query = $this->db->query("SELECT count(*) as approvedProperty FROM `property` WHERE (`ARI_audit_status` = 'Approved' && `ARO_audit_status` = 'Approved' && `ZC_audit_status` = 'Approved')");
        return $query->result();
    }
    
    function rejectedProperty() {
        $query = $this->db->query("SELECT count(*) as rejectedProperty FROM `property` WHERE (`ARI_audit_status` = 'Rejected' || `ARO_audit_status` = 'Rejected' || `ZC_audit_status` = 'Rejected')");
        return $query->result();
    }
    
    function totalPropertyARI($wardId) {
        if(!empty($wardId)){
            $query = $this->db->query("SELECT count(*) as totalProperty FROM `property` WHERE ward_no = ".$wardId);
            return $query->result();
        }
    }
    
    function approvedPropertyARI($wardId) {
        $query = $this->db->query("SELECT count(*) as approvedProperty FROM `property` WHERE (`ARI_audit_status` = 'Approved' && `ARO_audit_status` = 'Approved' && `ZC_audit_status` = 'Approved') AND ward_no = ".$wardId);
        return $query->result();
    }
    
    function rejectedPropertyARI($wardId) {
        $query = $this->db->query("SELECT count(*) as rejectedProperty FROM `property` WHERE (`ARI_audit_status` = 'Rejected' || `ARO_audit_status` = 'Rejected' || `ZC_audit_status` = 'Rejected') AND ward_no = ".$wardId);
        return $query->result();
    }
    
    function getPropertyARI($wardId) {
        $query = $this->db->query("SELECT * FROM `property` WHERE (deleted IS NULL or deleted = 0) AND ward_no = ".$wardId);
        return $query->result();
    }
    
    function totalPropertyARO($wardId) {
        if(!empty($wardId)){
            $query = $this->db->query("SELECT count(*) as totalProperty FROM `property` WHERE zone_no = ".$wardId);
            return $query->result();
        }
    }
    
    function approvedPropertyARO($wardId) {
        if(!empty($wardId)){
            $query = $this->db->query("SELECT count(*) as approvedProperty FROM `property` WHERE (`ARI_audit_status` = 'Approved' && `ARO_audit_status` = 'Approved' && `ZC_audit_status` = 'Approved') AND zone_no = ".$wardId);
            return $query->result();
        }else{
            return false;
        }
    }
    
    function rejectedPropertyARO($wardId) {
        if(!empty($wardId)){
            $query = $this->db->query("SELECT count(*) as rejectedProperty FROM `property` WHERE (`ARI_audit_status` = 'Rejected' || `ARO_audit_status` = 'Rejected' || `ZC_audit_status` = 'Rejected') AND zone_no = ".$wardId);
            return $query->result();
        }else{
            return false;
        }
    }
    
    function getPropertyARO($wardId) {
        if(!empty($wardId)){
            $query = $this->db->query("SELECT * FROM `property` WHERE zone_no = ".$wardId);
            return $query->result();
        }else{
            return false;
        }
    }
    
    function getProperty() {
        $query = $this->db->query("SELECT * FROM `property` WHERE deleted IS NULL OR deleted = 0");
        return $query->result();
    }
    
    function getMDData() {
        /*$query = $this->db->query("SELECT p.zone_no, p.ward_no, w.wardName, p.ARI_audit_status, p.ARO_audit_status, p.ZC_audit_status, a.ARIName, r.AROName, z.ZCName,COUNT(*) as approved_count
                                    FROM property p
                                    INNER JOIN ari_data_table a ON p.ward_no = a.ARIWardNo
                                    INNER JOIN aro_data_table r ON p.zone_no = r.AROZoneNo
                                    INNER JOIN zone_commissioner_table z ON p.zone_no = z.ZCZone
                                    INNER JOIN ward_table w ON p.ward_no = w.id
                                    WHERE p.ARI_audit_status = 'Approved'
                                    AND p.ARO_audit_status = 'Approved'
                                    AND p.ZC_audit_status = 'Approved'
                                    GROUP BY p.ward_no
                                    ORDER BY p.ward_no");*/
        $query = $this->db->query("SELECT p.zone_no, p.ward_no, w.wardName,
                                    COUNT(CASE WHEN p.ARI_audit_status = 'Approved' THEN 1 END) as approved_count,
                                    COUNT(CASE WHEN p.ARI_audit_status = 'Rejected' THEN 1 END) as rejected_count,
                                    COUNT(CASE WHEN p.ARI_audit_status IS NULL THEN 1 END) as ari_null_count,
                                    COUNT(CASE WHEN p.ARO_audit_status = 'Approved' THEN 1 END) as aro_approved_count,
                                    COUNT(CASE WHEN p.ARO_audit_status = 'Rejected' THEN 1 END) as aro_rejected_count,
                                    COUNT(CASE WHEN p.ARO_audit_status IS NULL THEN 1 END) as aro_null_count,
                                    COUNT(CASE WHEN p.ZC_audit_status = 'Approved' THEN 1 END) as zc_approved_count,
                                    COUNT(CASE WHEN p.ZC_audit_status = 'Rejected' THEN 1 END) as zc_rejected_count,
                                    COUNT(CASE WHEN p.ZC_audit_status IS NULL THEN 1 END) as zc_null_count,
                                    a.ARIName, r.AROName, z.ZCName, count(*) as CT
                                    FROM property p
                                    INNER JOIN ari_data_table a ON p.ward_no = a.ARIWardNo
                                    INNER JOIN aro_data_table r ON p.zone_no = r.AROZoneNo
                                    INNER JOIN zone_commissioner_table z ON p.zone_no = z.ZCZone
                                    INNER JOIN ward_table w ON p.ward_no = w.id
                                    GROUP BY p.ward_no
                                    ORDER BY p.ward_no");
        return $query->result();
    }
    
    function getAllWards()
    { 
        $query = $this->db->query('SELECT * FROM `ward_table`');
        return $query->result();
    }
    function getAllZones()
    { 
        $query = $this->db->query('SELECT * FROM `zone_table`');
        return $query->result();
    }
    
    function getAllAri()
    {
        $query = $this->db->query('SELECT * FROM `ari_data_table`');
        return $query->result();
    }
    
    function getAllAro()
    {
        $query = $this->db->query('SELECT * FROM `aro_data_table`');
        return $query->result();
    }
    
    function getAllZC()
    {
        $query = $this->db->query('SELECT * FROM `zone_commissioner_table`');
        return $query->result();
    }
    
    function getWardDetail($id) {
        if(!empty($id)) {
            $query = $this->db->query('SELECT * FROM `ward_table` WHERE `id` = '.$id);
            return $query->result();
        }
    }
    
    function getWardId($id) {
        if(!empty($id)) {
            $query = $this->db->query("SELECT * FROM ari_data_table WHERE `userId` = ".$id);
            return $query->result()[0]->ARIWardNo;
        }
    }
    
    function getZoneId($id) {
        if(!empty($id) && ($this->session->userdata('roleId') == '3')) {
            $query = $this->db->query("SELECT * FROM aro_data_table WHERE `userId` = ".$id);
            if($query->num_rows() > 0){
                return $query->result()[0]->AROZoneNo;
            }else{
                return false;
            }
        }else{
            $query = $this->db->query("SELECT * FROM zone_commissioner_table WHERE `userId` = ".$id);
            return $query->result()[0]->ZCZone;
        }
    }
    
    function getWardDetailWard($id) {
        if(!empty($id)) {
            $query = $this->db->query('SELECT * FROM `ward_table` WHERE `wardId` = "'.$id.'"');
            return $query->result();
        }
    }
    
    function getZoneDetail($id) {
        if(!empty($id)) {
            $query = $this->db->query('SELECT * FROM `zone_table` WHERE `id` = '.$id);
            return $query->result();
        }
    }
    
     //Insert Function For Email Content
    public function insert($data = array()) {
        if(!empty($data)){
            print_r($data);
            // Add created and modified date if not included
            $insert = $this->db->insert('property', $data);
            
            // Return the status
            return $insert?$this->db->insert_id():false;
        }
        return false;
    }
    
    public function getPropertyData($ward = 0)
    {
        if($ward == 0){
            $query = $this->db->query('SELECT * FROM `property`');
            return $query->result();
        }else{
            $query = $this->db->query('SELECT * FROM `property` WHERE `ward_no` = '.$ward);
            return $query->result();
        }
    }
    
    public function getPropData($propId) {
        // print_r($propId);
        if(!empty($propId)) {
            $query = $this->db->query('SELECT * FROM `property` WHERE `id` = '.$propId);
            return $query->result();
        }
    }
    
    public function getPropForApproval($zone) {
        $query = $this->db->query('SELECT * FROM `property` WHERE `zone_no` = '.$zone.' AND `ARI_audit_status` != ""');
        
        return $query->result();
        // print_r($this->db->last_query());
    }
    
    public function getARIData($userId) {
        $query = $this->db->query('SELECT * FROM `ari_data_table` WHERE `userId` = '.$userId);
        return $query->result();
    }
    
    public function getAROData($userId) {
        if(!empty($userId)) {
            $query = $this->db->query('SELECT * FROM `aro_data_table` WHERE `userId` = '.$userId);
            return $query->result();
        }else{
            return false;
        }
    }
    
    public function getZCData($userId) {
        $query = $this->db->query('SELECT * FROM `zone_commissioner_table` WHERE `userId` = '.$userId);
        return $query->result();
    }
    
    public function update($data, $id) {
    	print_r($data);
        if(!empty($data) && !empty($id)){
            // Add modified date if not included
            // Update batch data
            $update = $this->db->update('property', $data, array('id' => $id));
            
            // Return the status
            return $update?true:false;
        }
        return false;
    }
    
    public function ApprovedRecord() {
        $property = $this->db->query("SELECT * FROM `property` WHERE (ARI_audit_status = 'Approved' || ARO_audit_status = 'Approved' || 	ZC_audit_status = 'Approved')");
        return $property->result();
    }
    
    public function RejectedRecord() {
        $property = $this->db->query("SELECT * FROM `property` WHERE (ARI_audit_status = 'Rejected' || ARO_audit_status = 'Rejected' || ZC_audit_status = 'Rejected' || ARI_audit_status IS NULL || ARO_audit_status IS NULL || ZC_audit_status IS NULL)");
        return $property->result();
    }
} 