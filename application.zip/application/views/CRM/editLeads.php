<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Update Leads</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active"><a href="<?php echo site_url() ?>/crm/Crm/getData"><i class="fas fa-folder">&nbsp;Manage Leads</i></a></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- right column -->
          <div class="col-md-12">
            <!-- Form Element sizes -->
                   <!-- general form elements disabled -->
            <div class="card card-warning">
               <?php //print_r($leads); ?>
              <div class="card-header">
                <h3 class="card-title">Update Leads</h3>
              </div>
              <!-- /.card-header -->
              <!-- Display status message -->
    <?php if(!empty($success_msg)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-success"><?php echo $success_msg; ?></div>
    </div>
    <?php }elseif(!empty($error_msg)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-danger"><?php echo $error_msg; ?></div>
    </div>
    <?php } ?>
              <div class="card-body">
                <form method="post" action="<?php echo site_url() ?>crm/Crm/updateLeads/<?php echo $leads['id']; ?>">
                  <!-- input states -->
                  <div class="form-group">
                      <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i>Lead Type</label>
                      <select class="form-control is-valid select2" name="leadType" id="selectoption">
                          <option value="">Select Lead Types</option>
                          <option <?php if($leads['leadType'] == 'lm'){ echo 'selected'; } ?> value="lm">Lead Magnet</option>
                          <option <?php if($leads['leadType'] == 'fl'){ echo 'selected'; } ?> value="fl">Funnel Leads</option>
                          <option <?php if($leads['leadType'] == 'wr'){ echo 'selected'; } ?> value="wr">Webinar Registrants</option>
                          <option <?php if($leads['leadType'] == 'wp'){ echo 'selected'; } ?> value="wp">Webinar Polling Leads</option>
                          <option <?php if($leads['leadType'] == 'pl'){ echo 'selected'; } ?> value="pl">Premium Leads</option>
                      </select>
                  </div>
                 <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i>Name</label>
                    <input type="text" class="form-control is-valid" name="name" id="inputSuccess" placeholder="Enter the batch name" value="<?php echo !empty($leads['name'])?$leads['name']:''; ?>">
                    <?php echo form_error('batchName','<div style="color:red;">','</div>'); ?>
                  </div>
                 <div class="form-group">
                  <label>Email Address</label>
                  <input type="text" class="form-control is-valid" name="emailId" id="inputSuccess" placeholder="Enter the email Id" value="<?php echo !empty($leads['emailId'])?$leads['emailId']:''; ?>"/>
                  <?php echo form_error('courseId','<div style="color:red;">','</div>'); ?>
                 </div>
                <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i>Phone Number</label>
                    <input type="text" class="form-control is-valid" name="phoneNo" id="inputSuccess" placeholder="Enter the Phone Number" value="<?php echo !empty($leads['phoneNo'])?$leads['phoneNo']:'';  ?>" />
                </div>
                <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i>Amount</label>
                    <input type="text" class="form-control is-valid" name="amount" id="inputSuccess" placeholder="Enter Amount" value="<?php echo !empty($leads['amount'])?$leads['amount']:''; ?>" />
                </div>
                <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i>Batch Name</label>
                    <input type="text" class="form-control is-valid" name="batchId" id="inputSuccess" placeholder="Enter Batch Name" value="<?php echo !empty($leads['batchId'])?$leads['batchId']:''; ?>" />
                </div>
                <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i>Leads Status</label>
                    <select class="form-control is-valid select2" name="leadStatus" id="selectoption">
                        <option value="">Select Leads Status</option>
                        <option <?php if($leads['leadStatus'] == 'new'){ echo 'selected'; } ?> value="new">New</option>
                        <option <?php if($leads['leadStatus'] == 'old'){ echo 'selected'; } ?> value="old">Old</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i>Auto Assigned Manager</label>
                    <select class="form-control is-valid select2" name="RMAutoAssigned" id="selectoption">
                        <?php 
                        foreach($RMMaster as $row)
                        { 
                          if($row->userId == $leads['RMAutoAssigned'] ){?>
                         <option selected="true" value="<?php echo $row->userId?>"><?php echo $row->userName?></option>
                       <?php }else { ?><option  value="<?php echo $row->userId?>"><?php echo $row->userName?></option>
                       <?php }}?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i>Problem Area</label>
                    <textarea class="form-control" name="problemArea" id="inputSuccess"><?php echo !empty($leads['problemArea'])?$leads['problemArea']:''; ?></textarea>
                </div>
                <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i>State</label>
                    <input type="text" class="form-control" name="state" id="inputSuccess" value="<?php echo !empty($leads['state'])?$leads['state']:''; ?>">
                </div>
                
                  <!-- radio -->
                    
                 <div class="card-footer">
                  <input type="submit" class="btn btn-primary" name="leadSubmit" value="Submit">
                  <a href="<?php echo site_url('Batch/batch_tab'); ?>" class="btn btn-secondary">Back</a>
                </div>
                </form>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->