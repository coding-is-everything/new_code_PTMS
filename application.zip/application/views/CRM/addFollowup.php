<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Add Followup</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active"><a href="<?php echo site_url() ?>crm/Crm/getData"><i class="fas fa-folder">&nbsp;Manage Leads</i></a></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- right column -->
          <div class="col-md-12">
            <!-- Form Element sizes -->
                   <!-- general form elements disabled -->
            <div class="card card-warning">
              <div class="card-header">
                <h3 class="card-title">Add Followup</h3>
              </div>
              <!-- /.card-header -->
                          <!-- Display status message -->
    <?php if(!empty($success_msg)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-success"><?php echo $success_msg; ?></div>
    </div>
    <?php }elseif(!empty($error_msg)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-danger"><?php echo $error_msg; ?></div>
    </div>
    <?php } ?>
              <div class="card-body">
                <form method="post" action="<?php echo site_url() ?>crm/Crm/followupAddData">
                  <!-- input states -->
                  <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Lead Name</label>
                    <!--<input type="text" readonly class="form-control is-valid" name="batchName" id="inputSuccess" placeholder="Enter the batch name" autocomplete="off" value="<?php echo $leads['name']; ?>">-->
                    <select name="leadName" class="form-control is-valid select2">
                        <option value="">Select Lead Name</option>
                        <?php
                            foreach($leads as $row) {
                                if(!empty($row['name'])){
                            ?>
                            <option value="<?php echo $row['id'] ?>"><?php echo $row['name']."( ".$row['emailId']." )" ?></option>
                            <?php
                            }}
                        ?>
                    </select>
                    <?php echo form_error('batchName','<div style="color:red;">','</div>'); ?>
                  </div>
                  <div class="form-group">
                      
                      <?php if(!empty($followup['followup1'])){
                      ?>
                      <label>Followup Message 1:</label>
                      <label><?php echo $followup['followup1']; ?></label><br/>
                      <label>Next Followup Date : </label>
                      <label><?php echo $followup['followupDate1'] ?></label>
                      <?php
                      }else{
                      ?>
                      <?php 
                      } ?>
                  </div>
                  <div class="form-group">
                      
                      <?php if(!empty($followup['followup2'])){
                      ?>
                      <label>Followup Message 2:</label>
                      <label><?php echo $followup['followup2']; ?></label><br/>
                      <label>Next Followup Date : </label>
                      <label><?php echo $followup['followupDate2'] ?></label>
                      <?php
                      }else{
                      ?>
                      <?php 
                      } ?>
                  </div>
                  <div class="form-group">
                      
                      <?php if(!empty($followup['followup3'])){
                      ?>
                      <label>Followup Message 3:</label>
                      <label><?php echo $followup['followup3']; ?></label><br/>
                      <label>Next Followup Date : </label>
                      <label><?php echo $followup['followupDate3'] ?></label>
                      <?php
                      }else{
                      ?>
                      <?php 
                      } ?>
                  </div>
                  <div class="form-group">
                      
                      <?php if(!empty($followup['followup4'])){
                      ?>
                      <label>Followup Message 4:</label>
                      <label><?php echo $followup['followup4']; ?></label><br/>
                      <label>Next Followup Date : </label>
                      <label><?php echo $followup['followupDate4'] ?></label>
                      <?php
                      }else{
                      ?>
                      <?php 
                      } ?>
                  </div>
                  <div class="form-group">
                      <?php if(!empty($followup['followup5'])){
                      ?>
                      <label>Followup Message 5:</label>
                      <label><?php echo $followup['followup5']; ?></label><br/>
                      <label>Next Followup Date : </label>
                      <label><?php echo $followup['followupDate5'] ?></label>
                      <?php
                      }else{
                      ?>
                      <?php 
                      } ?>
                  </div>
                  <div class="form-group">
                      <label>FLI Team Status</label>
                      <?php 
                        if($followup['fliStatus'] == 'picked'){
                            echo 'Phone Picked Discussion in progress.';
                        }else if($followup['fliStatus'] == 'notPicked'){
                            echo 'Phone Not Picked.';
                        }else if($followup['fliStatus'] == 'notReachable'){
                            echo 'Phone Not Reachable.';
                        }else if($followup['fliStatus'] == 'noNetwork'){
                            echo 'No Network.';
                        }
                      ?>
                  </div>
                 <div class="form-group">
                  <label>Follow Up Message</label>
                  <textarea name="followup1" class="form-control"><?php echo $_POST['followup1'] ?></textarea>

                  <?php echo form_error('courseId','<div style="color:red;">','</div>'); ?>
                </div>
                <div class="form-group">
                      <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i>Follow Up Date</label>
                      <input type="date" class="form-control" name="followupDate1" value="<?php echo date('Y-m-d'); ?>">
                  </div>
                <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i>FLI Team Notes</label>
                    <select class="form-control select2" name="fliTeamStatus">
                        <option value="">Select FLI Team Status</option>
                        <option value="picked">Phone Picked</option>
                        <option value="notPicked">Phone Not Picked</option>
                        <option value="notReachable">Phone Not Reachable</option>
                        <option value="noNetwork">No Network</option>
                    </select>
                </div>
                 <div class="card-footer">
                  <input type="submit" class="btn btn-primary" name="followupSubmit" value="Submit">
                  <a href="<?php echo site_url('crm/Crm/getData'); ?>" class="btn btn-secondary">Back</a>
                </div>
                </form>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->