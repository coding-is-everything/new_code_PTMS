<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Add Daily Task</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active"><a href="<?php echo site_url() ?>/Course/course_tab"><i class="fas fa-folder">&nbsp;Manage Daily Task</i></a></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- right column -->
          <div class="col-md-12">
            <!-- Form Element sizes -->
                   <!-- general form elements disabled -->
            <div class="card card-warning">
               
              <div class="card-header">
                <h3 class="card-title">Add Course</h3>
              </div>
              <!-- /.card-header -->
              <!-- Display status message -->
    <?php if(!empty($success_msg)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-success"><?php echo $success_msg; ?></div>
    </div>
    <?php }elseif(!empty($error_msg)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-danger"><?php echo $error_msg; ?></div>
    </div>
    <?php } ?>
              <div class="card-body">
                <form method="post" action="<?php echo site_url() ?>Course/add">
                  <!-- input states -->
                  <div class="form-group">
                  <label>Sales representatives</label>
                  <select id="selectoption1"  class="form-control select2" style="width: 100%;" name="userId" onchange="show1();" >
                    <option value="" data-price="" data-price1="">--Select Sales Representative--</option>
                    <?php 
                        foreach($users as $row)
                        { if($row->userId == $_POST['userId'] ){?>
                         <option selected="true" data-price="<?php echo $row->incecntivePer?>" data-price1="<?php echo $row->teamLeadPer?>" value="<?php echo $row->userId?>"><?php echo $row->userName?></option>
                       <?php } else {?><option data-price="<?php echo $row->incecntivePer?>" data-price1="<?php echo $row->teamLeadPer?>"  value="<?php echo $row->userId?>"><?php echo $row->userName?></option>
                         <?php }}?>
                  </select>
                  <?php echo form_error('userId','<div style="color:red;">','</div>'); ?>
                </div>
                  <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Task Details</label>
                    <textarea  autocomplete="off" class="form-control is-valid" name="taskDetails" id="inputSuccess" placeholder="Enter the course name"><?php echo !empty($_POST['courseName'])?$_POST['courseName']:''; ?></textarea>
                    <?php echo form_error('courseName','<div style="color:red;">','</div>'); ?>
                  </div>
                 <div class="card-footer">
                  <input type="submit" class="btn btn-primary" name="courseSubmit" value="Submit">
                  <a href="<?php echo site_url('Course/course_tab'); ?>" class="btn btn-secondary">Back</a>
                </div>
                </form>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->