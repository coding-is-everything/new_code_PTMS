<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Manage Students</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>&nbsp;&nbsp;
              <?php if($this->session->userdata('roleId') == '1'){ ?>
              <li class="breadcrumb-item active"><a href="<?php echo site_url() ?>crm/Crm/getLeads"><i class="fa fa-plus">&nbsp;Manage Leads</i></a></li><?php } elseif($this->session->userdata('roleId') == '2'){?> <li class="breadcrumb-item active"><a href="<?php echo site_url() ?>Sale/add_sale_staff"><i class="fa fa-plus">&nbsp;Add Sale</i></a></li><?php } elseif($this->session->userdata('roleId') == '3') {?><a href="<?php echo site_url() ?>Sale/add_sale_team"><i class="fa fa-plus">&nbsp;Add Sale</i></a><?php } else {?><a href="<?php echo site_url() ?>Sale/add_sale_fin"><i class="fa fa-plus">&nbsp;Add Sale</i></a><?php } ?>
            </ol>
          </div>
             <!-- Display status message -->
    <?php if(!empty($success_msg)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-success"><?php echo $success_msg; ?></div>
    </div>
    <?php }elseif(!empty($error_msg)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-danger"><?php echo $error_msg; ?></div>
    </div>
    <?php } ?>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <?php $getData = $this->Incentive_model->getGstData(); ?>
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!--<form method="post" action="<?php echo site_url() ?>crm/Crm/assignBatch">-->
                <div class="card">
              <div class="card-header">
                <h3 class="card-title"></h3>
                    <table border="0" cellspacing="5" cellpadding="5">
                                <tbody>
                                    <tr>
                                        <td>From date:</td>
                                        <td><input type="date" id="min" name="min"></td>
                                        <td>To date:</td>
                                        <td><input type="date" id="max" name="max"></td>
                                        <td><a class="btn btn-success" id="searchBtn">Search</a></td>
                                        <!--<td><a href="<?php echo site_url() ?>crm/Rmmaster/RMAutoAssign" class="btn btn-primary" id="rmAutoAssign" name="rmAutoAssign">RM Auto Assign</a></td>-->
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                 <?php if($this->session->userdata('roleId') == '1'){?>
                 <div class="card-body">
                 <div id="ajaxData">
                     <table border="0" cellspacing="5" cellpadding="5">
                        <tbody>
                            <tr>
                                <td>Status Of New Leads Assigned : </td>
                                <td><b><?php echo $leadsCount['leadCount']; ?></b></td>
                                <td><a href="<?php echo site_url() ?>crm/Crm/checkedStatus/<?php echo $id ?>" class="btn btn-success">Checked</a></td>
                                <td>
                                            <p><h4>Lead Status</h4></p>
                                            <table border="0">
                                                <tr>
                                                    <th>Contacted : <?php echo $this->Crm_leads_model->getContactedLeadsDetails($id)['cCount'] ?></th></tr>
                                                    <tr><th>Not Contacted : <?php echo $leadsCount['leadCount'] - $this->Crm_leads_model->getContactedLeadsDetails($id)['cCount'] ?></th></tr>
                                                    <tr><th>Pending : 0</th></tr>
                                                    <tr><th>In-Progress : 0</th>
                                                </tr>
                                            </table>
                                        </td>
                            </tr>
                        </tbody>
                    </table>
                    <table id="example1" class="table table-bordered table-striped" style="width:100% !important;">
                  <thead>
                  <tr>
                    <th>Sr.No</th>
                    <th>Select Batch</th>
                    <th>Batch</th>
                    <th>Name</th>
                     <th>Email Id</th> 
                     <th>Phone No</th>
                     <th>RM / SR Name</th>
                     <th>Source Of Leads</th>
                     <th>Leads Type (New/Old)</th>
                     <th>Existing Courses</th>
                     <th>Amount</th>
                     <th>Notes</th>
                     <th>Next Followup Date</th>
                     <th>FLI Team Notes</th>
                     <th>Call Status</th>
                     <th>Lead Status</th>
                     <th>Problem Statement</th>
                     <th>State</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php 
                    $sr = 1;
                    if(!empty($leads)){ foreach($leads as $row){ ?>
                  <tr>
                    <td><?php echo $sr++; ?></td>
                    <td><input type="checkbox" id="inputSuccess" name="selectBatch[]" value="<?php echo $row['id'] ?>"/></td>
                    <td><?php echo $row['batchId'] ?>
                      </td>
                      <td><?php echo $row['name'] ?></td>
                       <td><?php echo $row['emailId'] ?>&nbsp;&nbsp;<a href="<?php echo site_url('crm/Crm/followup/'.$row['id']); ?>"><i class="fa fa-eye" style="font-size:20px"></i></a></td>
                       <td><?php echo $row['phoneNo'] ?></td>
                        <td><?php foreach($users as $row3)
                        { 
                          if($row3->userId == $row['RMAutoAssignId'] ){?>
                         <?php echo ucfirst($row3->userName);?>
                       <?php }} ?></td>
                       <td>
                           <?php if($row['leadType'] == 'lm'){ echo 'Lead Magnet'; }else if($row['leadType'] == 'fl'){ echo 'Funnel Leads'; }else if($row['leadType'] == 'wr'){ echo 'Webinar Registrants'; }else if($row['leadType'] == 'wp'){ echo 'Webinar Polling Leads'; }else if($row['leadType'] == 'pl'){ echo 'Premium Leads'; } ?>
                       </td>
                       <td>
                           <?php if($this->Crm_leads_model->getLeadStatus($row['emailId'])){ echo 'Old'; }else{ echo 'New'; } ?>
                       </td>
                       <td><?php echo $this->Crm_leads_model->getExistingCourses($row['emailId']); ?></td>
                       <td><?php echo $row['amount'] ?></td>
                       <td>
                           <?php 
                            if(!empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup1']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup4']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup3']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup4']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup5'])) {
                                echo $this->Crm_leads_model->getLatestFollowup($row['id'])['followup5'];
                            }else if(!empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup1']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup2']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup3']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup4'])) {
                                echo $this->Crm_leads_model->getLatestFollowup($row['id'])['followup4'];
                            }else if(!empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup1']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup2']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup3'])) {
                                echo $this->Crm_leads_model->getLatestFollowup($row['id'])['followup3'];
                            }else if(!empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup1']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup2'])) {
                                echo $this->Crm_leads_model->getLatestFollowup($row['id'])['followup2'];
                            }else{
                                echo $this->Crm_leads_model->getLatestFollowup($row['id'])['followup1'];
                            }
                           ?>
                       </td>
                       <td>
                           <?php 
                            if(!empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup1']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup4']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup3']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup4']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup5'])) {
                                echo $this->Crm_leads_model->getLatestFollowup($row['id'])['followupDate5'];
                            }else if(!empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup1']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup2']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup3']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup4'])) {
                                echo $this->Crm_leads_model->getLatestFollowup($row['id'])['followupDate4'];
                            }else if(!empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup1']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup2']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup3'])) {
                                echo $this->Crm_leads_model->getLatestFollowup($row['id'])['followupDate3'];
                            }else if(!empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup1']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup2'])) {
                                echo $this->Crm_leads_model->getLatestFollowup($row['id'])['followupDate2'];
                            }else{
                                echo $this->Crm_leads_model->getLatestFollowup($row['id'])['followupDate1'];
                            }
                           ?>
                       </td>
                       <td>
                           <?php
                           echo $this->Crm_leads_model->getLatestFollowup($row['id'])['fliStatus'];
                           ?>
                       </td>
                       <td></td>
                       <td></td>
                       <td><?php echo $row['problemArea'] ?></td>
                       <td><?php echo $row['state'];?></td>
                    <td>
                        <a href="<?php echo site_url('crm/Crm/followup/'.$row['id']); ?>"><i class="fa fa-eye" style="font-size:20px"></i></a>
                      &nbsp;<a href="<?php echo site_url('crm/Crm/edit/'.$row['id']); ?>"><i class="fa fa-edit" style="font-size:20px"></i></a>&nbsp;
                        <a href="<?php echo site_url('crm/Crm/delete/'.$row['id']); ?>" onclick="return confirm('Are you sure to delete?')"><i class="fa fa-trash" style="font-size:20px;"></i></a>
                    </td>
                  </tr>
                  <?php } }else{ ?>
                <tr><td colspan="19">No sale(s) found...</td></tr>
                <?php } ?>
                  </tbody>
                </table>
                </div>
               
              <?php } else {?>
              <div id="ajaxData">
                <table border="0" cellspacing="5" cellpadding="5">
                        <tbody>
                            <tr>
                                <td>Status Of New Leads Assigned : </td>
                                <td><b><?php echo $leadsCount['leadCount']; ?></b></td>
                                <td><a href="<?php echo site_url() ?>crm/Crm/checkedStatus/<?php echo $id ?>" class="btn btn-success">Checked</a></td>
                                <td>
                                            <p><h4>Lead Status</h4></p>
                                            <table border="0">
                                                <tr>
                                                    <th>Contacted : <?php echo $this->Crm_leads_model->getContactedLeadsDetails($id)['cCount'] ?></th></tr>
                                                    <tr><th>Not Contacted : <?php echo $leadsCount['leadCount'] - $this->Crm_leads_model->getContactedLeadsDetails($id)['cCount'] ?></th></tr>
                                                    <tr><th>Pending : 0</th></tr>
                                                    <tr><th>In-Progress : 0</th>
                                                </tr>
                                            </table>
                                        </td>
                            </tr>
                        </tbody>
                    </table>
                <table id="example1" class="table table-bordered table-striped" style="width:100% !important;">
                  <thead>
                  <tr>
                    <th>Sr.No</th>
                    <th>Select Batch</th>
                    <th>Batch</th>
                    <th>Name</th>
                     <th>Email Id</th> 
                     <th>Phone No</th>
                     <th>RM / SR Name</th>
                     <th>Source Of Leads</th>
                     <th>Leads Type (New/Old)</th>
                     <th>Existing Courses</th>
                     <th>Amount</th>
                     <th>Notes</th>
                     <th>Next Followup Date</th>
                     <th>FLI Team Notes</th>
                     <th>Call Status</th>
                     <th>Lead Status</th>
                     <th>Problem Statement</th>
                     <th>State</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php 
                    $sr = 1;
                    if(!empty($leads)){ foreach($leads as $row){ ?>
                  <tr>
                    <td><?php echo $sr++; ?></td>
                    <td><input type="checkbox" id="inputSuccess" name="selectBatch[]" value="<?php echo $row['id'] ?>"/></td>
                    <td><?php echo $row['batchId'] ?>
                      </td>
                      <td><?php echo $row['name'] ?></td>
                       <td><?php echo $row['emailId'] ?>&nbsp;&nbsp;<a href="<?php echo site_url('crm/Crm/followup/'.$row['id']); ?>"><i class="fa fa-eye" style="font-size:20px"></i></a></td>
                       <td><?php echo $row['phoneNo'] ?></td>
                        <td><?php foreach($users as $row3)
                        { 
                          if($row3->userId == $row['RMAutoAssignId'] ){?>
                         <?php echo ucfirst($row3->userName);?>
                       <?php }} ?></td>
                       <td>
                           <?php if($row['leadType'] == 'lm'){ echo 'Lead Magnet'; }else if($row['leadType'] == 'fl'){ echo 'Funnel Leads'; }else if($row['leadType'] == 'wr'){ echo 'Webinar Registrants'; }else if($row['leadType'] == 'wp'){ echo 'Webinar Polling Leads'; }else if($row['leadType'] == 'pl'){ echo 'Premium Leads'; } ?>
                       </td>
                       <td>
                           <?php if($this->Crm_leads_model->getLeadStatus($row['emailId'])){ echo 'Old'; }else{ echo 'New'; } ?>
                       </td>
                       <td><?php echo $this->Crm_leads_model->getExistingCourses($row['emailId']); ?></td>
                       <td><?php echo $row['amount'] ?></td>
                       <td>
                           <?php 
                            if(!empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup1']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup4']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup3']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup4']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup5'])) {
                                echo $this->Crm_leads_model->getLatestFollowup($row['id'])['followup5'];
                            }else if(!empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup1']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup2']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup3']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup4'])) {
                                echo $this->Crm_leads_model->getLatestFollowup($row['id'])['followup4'];
                            }else if(!empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup1']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup2']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup3'])) {
                                echo $this->Crm_leads_model->getLatestFollowup($row['id'])['followup3'];
                            }else if(!empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup1']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup2'])) {
                                echo $this->Crm_leads_model->getLatestFollowup($row['id'])['followup2'];
                            }else{
                                echo $this->Crm_leads_model->getLatestFollowup($row['id'])['followup1'];
                            }
                           ?>
                       </td>
                       <td>
                           <?php 
                            if(!empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup1']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup4']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup3']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup4']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup5'])) {
                                echo $this->Crm_leads_model->getLatestFollowup($row['id'])['followupDate5'];
                            }else if(!empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup1']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup2']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup3']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup4'])) {
                                echo $this->Crm_leads_model->getLatestFollowup($row['id'])['followupDate4'];
                            }else if(!empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup1']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup2']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup3'])) {
                                echo $this->Crm_leads_model->getLatestFollowup($row['id'])['followupDate3'];
                            }else if(!empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup1']) && !empty($this->Crm_leads_model->getLatestFollowup($row['id'])['followup2'])) {
                                echo $this->Crm_leads_model->getLatestFollowup($row['id'])['followupDate2'];
                            }else{
                                echo $this->Crm_leads_model->getLatestFollowup($row['id'])['followupDate1'];
                            }
                           ?>
                       </td>
                       <td>
                           <?php
                           echo $this->Crm_leads_model->getLatestFollowup($row['id'])['fliStatus'];
                           ?>
                       </td>
                       <td></td>
                       <td></td>
                       <td><?php echo $row['problemArea'] ?></td>
                       <td><?php echo $row['state'];?></td>
                    <td>
                        <a href="<?php echo site_url('crm/Crm/followup/'.$row['id']); ?>"><i class="fa fa-eye" style="font-size:20px"></i></a>
                      &nbsp;<a href="<?php echo site_url('crm/Crm/edit/'.$row['id']); ?>"><i class="fa fa-edit" style="font-size:20px"></i></a>&nbsp;
                        <a href="<?php echo site_url('crm/Crm/delete/'.$row['id']); ?>" onclick="return confirm('Are you sure to delete?')"><i class="fa fa-trash" style="font-size:20px;"></i></a>
                    </td>
                  </tr>
                  <?php } }else{ ?>
                <tr><td colspan="19">No sale(s) found...</td></tr>
                <?php } ?>
                  </tbody>
                </table>
                </div>

              <?php } ?>  
              </div>
              <!-- /.card-body -->
            </div>
            <!--</form>-->
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>

<script>
    $(document).ready(function() {
       $('#searchBtn').on('click', function(){
        //   alert('hello');
          var startDate = $('#min').val();
          var endDate = $('#max').val();
          var roleId = '<?php echo $this->session->userdata('roleId') ?>';
          var id = '<?php echo $id; ?>';
          if(startDate == '' || endDate == ''){
              alert('Any Of them can not be blank.');
          }else{
            //   alert(startDate+" "+endDate+" "+id);
            //   $('#ajaxData').replaceWith('Hello');
              var formData = "SD="+startDate+"&ED="+endDate+"&roleId="+roleId+"&id="+id;
              $.ajax({
                 url: '<?=base_url()?>crm/Crm/getAjaxDataRM',
                 method: "POST",
                 data: formData,
                 success: function(data) {
                    console.log(data);
                     $('#ajaxData').empty();
                     $('#ajaxData').html(data);
                     //$('#example1').dataTable().fnDestroy();
                     $("#example1").DataTable({
                         "destroy": true,
      "responsive": true, "lengthChange": true, "autoWidth": true,
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
                 $("#example1").DataTable.removeAttr("style");
                     
                 }
                 
              });
          }
       }); 
    });
</script>