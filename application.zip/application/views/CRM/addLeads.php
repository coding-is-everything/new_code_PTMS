<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Add Leads</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active"><a href="<?php echo site_url() ?>"><i class="fas fa-folder">&nbsp;Manage Leads</i></a></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- right column -->
          <div class="col-md-12">
            <!-- Form Element sizes -->
                   <!-- general form elements disabled -->
            <div class="card card-warning">
              <div class="card-header">
                <h3 class="card-title">Add Leads</h3>
              </div>
              <!-- /.card-header -->
                          <!-- Display status message -->
    <?php if(!empty($success_msg)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-success"><?php echo $success_msg; ?></div>
    </div>
    <?php }elseif(!empty($error_msg)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-danger"><?php echo $error_msg; ?></div>
    </div>
    <?php } ?>
              <div class="card-body">
                <form method="post" action="<?php echo site_url() ?>crm/Crm/getJson" enctype="multipart/form-data">
                  <!-- input states -->
                  <div class="form-group">
                      <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i>Lead Types</label>
                      <select class="form-control is-valid select2" name="leadType" id="selectoption">
                          <option value="">Select Lead Types</option>
                          <option value="lm">Lead Magnet</option>
                          <option value="fl">Funnel Leads</option>
                          <option value="wr">Webinar Registrants</option>
                          <option value="wp">Webinar Polling Leads</option>
                          <option value="pl">Premium Leads</option>
                      </select>
                  </div>
                  <!--<div class="form-group">-->
                  <!--  <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Add Leads</label>-->
                  <!--  <input type="file" class="form-control is-valid" name="leads" id="inputSuccess" placeholder="Enter the batch name" autocomplete="off">-->
                  <!--  <?php echo form_error('leads','<div style="color:red;">','</div>'); ?>-->
                  <!--</div>-->
                  <!-- radio -->
                 <div class="card-footer">
                  <input type="submit" class="btn btn-primary" name="batchSubmit" value="Submit">
                  <a href="<?php echo site_url('Batch/batch_tab'); ?>" class="btn btn-secondary">Back</a>
                </div>
                </form>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->