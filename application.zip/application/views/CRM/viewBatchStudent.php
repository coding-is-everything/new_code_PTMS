<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?php echo $title; ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active"><a href="<?php echo site_url() ?>Batch/add"><i class="fa fa-plus">&nbsp;Add Batch</i></a></li>
                    </ol>
                </div>

            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">

                        <div class="card-header">
                            <!-- Display status message -->
                            <?php if (!empty($this->session->userdata('success_msg'))) { ?>
                                <div class="col-xs-12">
                                    <div class="alert alert-success"><?php echo $this->session->userdata('success_msg'); ?></div>
                                </div>
                            <?php } elseif (!empty($error_msg)) { ?>
                                <div class="col-xs-12">
                                    <div class="alert alert-danger"><?php echo $error_msg; ?></div>
                                </div>
                            <?php } ?>
                        </div>
                        <div class="card-body">
                            <table border="0" cellspacing="5" cellpadding="5">
                                <tbody>
                                    <tr>
                                        <td>From date:</td>
                                        <td><input type="date" id="min" name="min"></td>
                                        <td>To date:</td>
                                        <td><input type="date" id="max" name="max"></td>
                                        <td><button class="btn btn-success" id="searchBtn" name="searchBtn">Search</button></td>
                                    </tr>
                                </tbody>
                            </table>
                            <div id="ajaxData">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>Sr.No</th>
                                        <th>Student Name</th>
                                        <th>Course Fees</th>
                                        <th>Batch Name</th>
                                        <th>Email Id</th>
                                        <th>Phone Number</th>
                                        <!--<th>Fees Given</th>-->
                                        <!--<th>Previous Fee Given</th>-->
                                        <!--<th>Fees Remaining</th>-->
                                        <!--<th>Net Incentive Given</th>-->
                                        <!--<th>Mobile Number</th>-->
                                        <!--<th>Sales Repsentative</th>-->
                                        
                                        <!--<th>Next Commited Transaction Date</th>-->
                                        <!--<th>Next Followup Date</th>-->
                                        <!--<th>Payment Remarks</th>-->
                                        <!--<th>Notes</th>-->
                                        
                                        <!--<th>Leads Status</th>-->
                                        <!--<th>Email</th>-->
                                        <!--<th>Balance Courses</th>-->
                                        <!--<th>Courses Enrolled</th>-->
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $sr = 1;
                                    if (!empty($student)) {
                                        foreach ($student as $row) { ?>
                                            <tr>
                                                <td><?php echo $sr++; ?></td>
                                                <td><?php echo ucfirst($row['name']); ?></td>
                                                <td>
                                                    <center><?php echo round($row['amount'], 2) ?></center>
                                                </td>
                                                <td><?php echo $row['batchId'] ?></td>
                                                <td><?php echo $row['emailId'] ?></td>
                                                <td><?php echo $row['phoneNo'] ?></td>
                                            </tr>
                                        <?php }
                                    } else { ?>
                                        <tr>
                                            <td colspan="15">No batches(s) found...</td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                            </div>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<script>
    $(document).ready(function() {
       $('#searchBtn').on('click', function(){
          var id = "<?php echo $id ?>"
          var startDate = $('#min').val();
          var endDate = $('#max').val();
          if(startDate == '' || endDate == ''){
              alert('Any Of them can not be blank.');
          }else{
            //   $('#ajaxData').replaceWith('Hello');
              var formData = "SD="+startDate+"&ED="+endDate;
              $.ajax({
                 url: '<?=base_url()?>Batch/ajaxTableData/'+id,
                 method: "POST",
                 data: formData,
                 success: function(data) {
                     $('#ajaxData').replaceWith(data);
                     $('#example1').dataTable().fnDestroy();
                     $('#example1').dataTable({
                         "responsive": true, "lengthChange": true, "autoWidth": true,
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
                     });
                 }
                 
              });
          }
       }); 
    });
</script>