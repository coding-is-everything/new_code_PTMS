<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>All Rejected Properties</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active"></li>
            </ol>
          </div>

        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              
              <div class="card-header">
                
             <!-- Display status message -->
    <?php if(!empty($success_msg)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-success"><?php echo $success_msg; ?></div>
    </div>
    <?php }elseif(!empty($error_msg)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-danger"><?php echo $error_msg; ?></div>
    </div>
    <?php } ?>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                  <thead class="bg-success">
                  <tr>
                    <th>Sr.No</th>
                    <th>Zone Name</th>
                    <th>Ward Name</th>
                    <th>Parikshetra Number</th>
                    <th>Road Type</th>
                    <th>Floor SBA</th>
                    <th>Construction Type</th>
                    <th>Floor Type</th>
                    <th>Last Tax Amount</th>
                    <th>Year Of Last Tax Payment</th>
                    <th>Owner Name</th>
                    <th>Guardian Name</th>
                    <th>Gender</th>
                    <th>Mobile</th>
                    <th>Address</th>
                    <th>Colony</th>
                    <th>Occupant Type</th>
                    <th>Pin Code</th>
                    <th>Area Of Plot</th>
                    <th>Area Of Building Footprint</th>
                    <th>Total Floor</th>
                    <th>Latitude</th>
                    <th>Longitude</th>
                    <th>Is Property Available In BMC Record</th>
                    <th>Property Image</th>
                    <th>Open Plots</th>
                    <th>Penalty</th>
                    <th>Year Of Construction</th>
                    <th>Property Number</th>
                    <th>DDN</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php
                    $sr = 1;
                    if(!empty($properties)){ foreach($properties as $ward) {
                    ?>
                    <tr>
                        <th><?php echo $sr; ?></th>
                    <th><?php echo $this->Ward_model->getZoneDetail($ward->zone_no)[0]->zoneName; ?></th>
                    <th><?php echo $this->Ward_model->getWardDetail($ward->ward_no)[0]->wardName; ?></th>
                    <th><?php echo $ward->parikshetra_number; ?></th>
                    <th><?php echo $ward->road_type; ?></th>
                    <th><?php echo $ward->floor_SBA; ?></th>
                    <th><?php echo $ward->const_type; ?></th>
                    <th><?php echo $ward->floor_type; ?></th>
                    <th><?php echo $ward->last_tax_pay_amount; ?></th>
                    <th><?php echo $ward->year_of_last_tax_paid; ?></th>
                    <th><?php echo $ward->owner_name; ?></th>
                    <th><?php echo $ward->guardian_name; ?></th>
                    <th><?php echo $ward->gender; ?></th>
                    <th><?php echo $ward->mobile; ?></th>
                    <th><?php echo $ward->address; ?></th>
                    <th><?php echo $ward->colony; ?></th>
                    <th><?php echo $ward->floor_wise_occup_type; ?></th>
                    <th><?php echo $ward->pin_code; ?></th>
                    <th><?php echo $ward->area_of_plot_as_per_gis; ?></th>
                    <th><?php echo $ward->area_of_building_footprint_as_per_gis; ?></th>
                    <th><?php echo $ward->total_floors; ?></th>
                    <th><?php echo $ward->latitude; ?></th>
                    <th><?php echo $ward->longitude; ?></th>
                    <th><?php echo $ward->is_property_available_in_bmc_record; ?></th>
                    <th><?php echo $ward->property_image; ?></th>
                    <th><?php echo $ward->open_plots; ?></th>
                    <th><?php echo $ward->penality; ?></th>
                    <th><?php echo $ward->year_of_construction; ?></th>
                    <th><?php echo $ward->new_pro_no; ?></th>
                    <th><?php echo $ward->DDN; ?></th>
                    </tr>
                    <?php
                    }}else{
                    ?>
                    <tr><td colspan="31">No User(s) found...</td></tr>
                    <?php
                    }
                    ?>
                  </tbody>
                </table>
                 <div class="pagination pull-right">
            <?php echo $this->pagination->create_links(); ?>
        </div>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->