<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1><?php echo $title; ?></h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>
  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title"></h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <div class="row">
                  <div class="col-md-6">
                      <b style="font-size: 20px;">The Batraa Numerology</b><br/>
                      <b style="font-size: 15px;">GST No: 07BHJPR0222E1ZO</b><br/><br/><br/><br/><br/>
                      <b style="font-size: 20px;"><i>The Batraa Numerology</i></b><br/>
                      <b style="font-size: 15px;"><i>D 29, Third Floor,</i></b><br/>
                      <b style="font-size: 15px;"><i>Ashoka Rd, Aadarsh Nagar,</i></b><br/>
                      <b style="font-size: 15px;"><i>Delhi</i></b><br/>
                      <b style="font-size: 15px;"><i>Pin Code : 110033</i></b><br/>
                      <b style="font-size: 15px;"><i>+919999053895</i></b>
                   </div>
                   <div class="col-md-6">
                       <pre style="background-color: #2acfe8; width: 200px;"><b style="font-size: 20px;">Sales Invoice</b></pre>
                       <br/><br/><br/>
                       <b style="font-size: 20px;"><i>To,</i></b><br/>
                       <b style="font-size: 15px;"><i><?php echo $this->Student_model->getStudentDetails($sale['studentId'])['studentName']; ?></i></b><br/>
                       <b style="font-size: 15px;"><i><?php echo $this->Student_model->getStudentDetails($sale['studentId'])['studentEmail']; ?></i></b><br/>
                       <b style="font-size: 15px;"><i><?php echo $this->Student_model->getStudentDetails($sale['studentId'])['studentMobile']; ?></i></b><br/>
                   </div>
              </div>
              <div class="row">
                  <div class="col-md-6">
                      <b style="font-size: 20px;">Date : <?php echo date('d-M-Y', strtotime($sale['createdDate'])) ?></b></br>
                      <b style="font-size: 20px;">Invoice No. : <?php if(isset($this->Sale_model->getInvoiceId($id)['invoiceId'])){echo $this->Sale_model->getInvoiceId($id)['invoiceId'];}else{ echo 'TBN-2022-'.$id; } ?></b>
                  </div>
              </div>
              <br/>
              <div class="row">
                  <div class="col-md-12">
                      <table class="table table-bordered table-striped">
                          <thead>
                              <tr>
                                  <th>Description</th>
                                  <th>Rate</th>
                                  <th>GST %</th>
                                  <th>Total</th>
                              </tr>
                          </thead>
                          <tbody>
                              <tr>
                                  <td><?php echo ucfirst($this->Sale_model->batchDetails($sale['batchId'])['batchName']) ?></td>
                                  <td><?php echo round((float)($sale['coursePriceCommited'] - ((float)$sale['coursePriceCommited'] * 18/100)), 2); ?></td>
                                  <td><?php echo round((((float)$sale['coursePriceCommited'] * 18/100)), 2); ?></td>
                                  <td><?php echo round((float)$sale['coursePriceCommited'], 2) ?></td>
                              </tr>
                              <tr>
                                  <td colspan="2"></td>
                                  <th>Sub Total : </th>
                                  <th><?php echo round(((float)$sale['coursePriceCommited'] - ((float)$sale['coursePriceCommited'] * 18/100)), 2); ?></th>
                                  <!--<th></th>-->
                                  <!--<th></th>-->
                              </tr>
                              <tr>
                                  <td colspan="2"></td>
                                  <th>Tax % : </th>
                                  <th><?php echo round((((float)$sale['coursePriceCommited'] * 18/100)), 2); ?></th>
                              </tr>
                              <tr>
                                  <td colspan="2"></td>
                                  <th>Total : </th>
                                  <th><b><?php echo round((float)$sale['coursePriceCommited'], 2) ?></b></th>
                              </tr>
                              <tr>
                              	<td colspan="2"></td>
                              	<th>Amount Received : </th>
                              	<th><b><?php echo round((float)$sale['couesePriceGiven'] + (float)$sale['coursePricePre'], 2) ?></b></th>
                              </tr>
                              <tr>
                                  <td colspan="2"></td>
                                  <th>Balance : </th>
                                  <th><b><?php echo round((float)$sale['coursePriceCommited'] - ((float)$sale['couesePriceGiven'] + (float)$sale['coursePricePre']), 2) ?></b></th>
                              </tr>
                          </tbody>
                      </table>
                  </div>
              </div>
              <div class="row">
                  <div class="col-md-12">
                      <input type="button" onclick="window.print()" value="Save PDF" class="btn btn-success"/>
                  </div>
              </div>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->