<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Manage Sale</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>&nbsp;&nbsp;
              <?php if($this->session->userdata('roleId') == '1'){ ?>
              <li class="breadcrumb-item active"><a href="<?php echo site_url() ?>Sale/add"><i class="fa fa-plus">&nbsp;Add Sale</i></a></li><?php } elseif($this->session->userdata('roleId') == '2'){?> <li class="breadcrumb-item active"><a href="<?php echo site_url() ?>Sale/add_sale_staff"><i class="fa fa-plus">&nbsp;Add Sale</i></a></li><?php } elseif($this->session->userdata('roleId') == '3') {?><a href="<?php echo site_url() ?>Sale/add_sale_team"><i class="fa fa-plus">&nbsp;Add Sale</i></a><?php } elseif($this->session->userdata('roleId') == '4') {?><a href="<?php echo site_url() ?>Sale/add_sale_fin"><i class="fa fa-plus">&nbsp;Add Sale</i></a><?php } ?>
            </ol>
          </div>
             <!-- Display status message -->
    <?php if(!empty($success_msg)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-success"><?php echo $success_msg; ?></div>
    </div>
    <?php }elseif(!empty($error_msg)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-danger"><?php echo $error_msg; ?></div>
    </div>
    <?php } ?>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <?php $getData = $this->Incentive_model->getGstData(); ?>
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">
                    <table border="0" cellspacing="5" cellpadding="5">
                                <tbody>
                                    <tr>
                                        <td>From date:</td>
                                        <td><input type="date" id="min" name="min"></td>
                                        <td>To date:</td>
                                        <td><input type="date" id="max" name="max"></td>
                                        <td><button class="btn btn-success" id="searchBtn" name="searchBtn">Search</button></td>
                                    </tr>
                                </tbody>
                            </table>
                 <?php if($this->session->userdata('roleId') == '1'){?>
                 <div id="ajaxData">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>Sr.No</th>
                    <th>Batch</th>
                    <th>Name</th>
                     <th>Mobile</th> 
                     <th>Sale Mode</th>
                     <th>RM / SR Name</th>
                     <th>Incentive</th>
                     <th>Gross Amount</th>
                     <th>Net Amount</th>
                     <th>Transaction Date</th>                     
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php 
                    $sr = 1;
                    if(!empty($sales)){ foreach($sales as $row){ ?>
                  <tr>
                    <td><?php echo $sr++; ?></td>
                    <td><?php foreach($batches as $row1)
                        { 
                          if($row1->batchId == $row['batchId'] ){?>
                         <?php echo ucfirst($row1->batchName);?>
                       <?php }} ?>
                      </td>
                      <td><?php foreach($students as $row2)
                        { 
                          if($row2->studentId == $row['studentId'] ){?>
                         <?php echo ucfirst($row2->studentName);?>
                       <?php }} ?></td>
                       <td><?php foreach($students as $row2)
                        { 
                          if($row2->studentId == $row['studentId'] ){?>
                         <?php echo ucfirst($row2->studentMobile);?>
                       <?php }} ?></td>
                       <td><?php echo $row['mode'] ?></td>
                        <td><?php foreach($users as $row3)
                        { 
                          if($row3->userId == $row['userId'] ){?>
                         <?php echo ucfirst($row3->userName);?>
                       <?php }} ?></td>
                       <td><?php if($getData['settingStatus'] == 'on'){ echo (int)$row['courseIncentive'] - ((int)$row['courseIncentive']*($getData['gstPercent'])/100); }else{ echo (int)$row['courseIncentive']; } ?></td>
                       <td><?php echo $row['couesePriceGiven'] ?></td>
                       <td><?php if($getData['settingStatus'] == 'on'){ echo (int)$row['couesePriceGiven'] - ((int)$row['couesePriceGiven']*($getData['gstPercent'])/100); }else{ echo (int)$row['couesePriceGiven']; } ?></td>
                       <td><?php echo $row['transactionDate'];?></td>
                    <td>
                       <?php if($this->session->userdata('roleId') == '1'){?>
                       <a href="<?php echo site_url('sale/invoice/'.$row['saleId']); ?>" placeholder="Generate Invoice"><i class="fa fa-file" style="font-size: 20px;"></i></a>
                      <a href="<?php echo site_url('sale/view/'.$row['saleId']); ?>"><i class="fa fa-eye" style="font-size:20px"></i></a><?php } 
                      elseif($this->session->userdata('roleId') == '2') { ?>
                      <a href="<?php echo site_url('sale/invoice/'.$row['saleId']); ?>" placeholder="Generate Invoice"><i class="fa fa-file" style="font-size: 20px;"></i></a><a href="<?php echo site_url('sale/view_staff/'.$row['saleId']); ?>"><i class="fa fa-eye" style="font-size:20px"></i></a><?php } 
                      elseif($this->session->userdata('roleId') == '3') { ?><a href="<?php echo site_url('sale/invoice/'.$row['saleId']); ?>" placeholder="Generate Invoice"><i class="fa fa-file" style="font-size: 20px;"></i></a><a href="<?php echo site_url('sale/view_team/'.$row['saleId']); ?>"><i class="fa fa-eye" style="font-size:20px"></i></a><?php } else { ?><a href="<?php echo site_url('sale/invoice/'.$row['saleId']); ?>" placeholder="Generate Invoice"><i class="fa fa-file" style="font-size: 20px;"></i></a><a href="<?php echo site_url('sale/view_fin/'.$row['saleId']); ?>"><i class="fa fa-eye" style="font-size:20px"></i></a><?php } ?>

                <?php $check = 0; if($row['checked'] == ''){ $check = $row['checked']; }else{ $check = 0; } if($this->session->userdata('roleId') == '1'){?>
                      &nbsp;<a href="<?php echo site_url('sale/edit/'.$row['saleId'].'/'.$row['mode'].'/'.$check); ?>">
                          <i class="fa fa-edit" style="font-size:20px"></i></a>&nbsp;
                          <?php } elseif($this->session->userdata('roleId') == '2') {?>
                          <a href="<?php echo site_url('sale/edit_staff/'.$row['saleId'].'/'.$row['mode'].'/'.$check); ?>">
                              <i class="fa fa-edit" style="font-size:20px"></i></a>&nbsp;
                        <?php } elseif($this->session->userdata('roleId') == '3') {?>
                        <a href="<?php echo site_url('sale/edit_team/'.$row['saleId'].'/'.$row['mode'].'/'.$check); ?>">
                            <i class="fa fa-edit" style="font-size:20px"></i></a>&nbsp;
                            <?php } ?>
                      <?php if($this->session->userdata('roleId') == '1'){?>
                        <a href="<?php echo site_url('sale/delete/'.$row['saleId']); ?>" onclick="return confirm('Are you sure to delete?')"><i class="fa fa-trash" style="font-size:20px;"></i></a><?php } else {?><a href="<?php echo site_url('sale/delete_staff/'.$row['saleId']); ?>" onclick="return confirm('Are you sure to delete?')"><i class="fa fa-trash" style="font-size:20px;"></i></a><?php } ?></td>
                  </tr>
                  <?php } }else{ ?>
                <tr><td colspan="9">No sale(s) found...</td></tr>
                <?php } ?>
                  </tbody>
                </table>
                </div>
              <?php } else {?>
              <div id="ajaxData">
                <table id="example2" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>Sr.No</th>
                    <th>Batch</th>
                    <th>Name</th>
                     <th>Mobile</th>
                     <th>Sale Mode</th> 
                     <th>RM / SR Name</th>
                     <th>Incentive</th>
                     <th>Gross Amount</th>
                     <th>Net Amount</th>
                     <th>Transaction Date</th>                     
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php 
                    $sr = 1;
                    if(!empty($sales)){ foreach($sales as $row){ ?>
                  <tr>
                    <td><?php echo $sr++; ?></td>
                    <td><?php foreach($batches as $row1)
                        { 
                          if($row1->batchId == $row['batchId'] ){?>
                         <?php echo ucfirst($row1->batchName);?>
                       <?php }} ?>
                      </td>
                      <td><?php foreach($students as $row2)
                        { 
                          if($row2->studentId == $row['studentId'] ){?>
                         <?php echo ucfirst($row2->studentName);?>
                       <?php }} ?></td>
                       <td><?php foreach($students as $row2)
                        { 
                          if($row2->studentId == $row['studentId'] ){?>
                         <?php echo ucfirst($row2->studentMobile);?>
                       <?php }} ?></td>
                       <td><?php echo $row['mode'] ?></td>
                        <td><?php foreach($users as $row3)
                        { 
                          if($row3->userId == $row['userId'] ){?>
                         <?php echo ucfirst($row3->userName);?>
                       <?php }} ?></td>
                       <td><?php if($getData['settingStatus'] == 'on'){ echo (int)$row['courseIncentive'] - ((int)$row['courseIncentive']*($getData['gstPercent'])/100); }else{ echo (int)$row['courseIncentive']; } ?></td>
                       <td><?php echo $row['couesePriceGiven'] ?></td>
                       <td><?php if($getData['settingStatus'] == 'on'){ echo $row['couesePriceGiven'] - ($row['couesePriceGiven']*($getData['gstPercent'])/100); }else{ echo $row['couesePriceGiven']; } ?></td>
                       <td><?php echo $row['transactionDate'];?></td>
                    <td>
                       <?php if($this->session->userdata('roleId') == '1'){?>
                      <a href="<?php echo site_url('sale/view/'.$row['saleId']); ?>"><i class="fa fa-eye" style="font-size:20px"></i></a><?php } elseif($this->session->userdata('roleId') == '2') { ?><a href="<?php echo site_url('sale/view_staff/'.$row['saleId']); ?>"><i class="fa fa-eye" style="font-size:20px"></i></a><?php } elseif($this->session->userdata('roleId') == '3') { ?><a href="<?php echo site_url('sale/view_team/'.$row['saleId']); ?>"><i class="fa fa-eye" style="font-size:20px"></i></a><?php } else { ?><a href="<?php echo site_url('sale/view_fin/'.$row['saleId']); ?>"><i class="fa fa-eye" style="font-size:20px"></i></a><?php } ?>

                       <?php if($this->session->userdata('roleId') == '1'){?>
                      &nbsp;<a href="<?php echo site_url('sale/edit/'.$row['saleId'].'/'.$row['mode'].'/'.$row['checked']); ?>"><i class="fa fa-edit" style="font-size:20px"></i></a>&nbsp;<?php } elseif($this->session->userdata('roleId') == '2') {?><a href="<?php echo site_url('sale/edit_staff/'.$row['saleId'].'/'.$row['mode'].'/'.$row['checked']); ?>"><i class="fa fa-edit" style="font-size:20px"></i></a>&nbsp;<?php } elseif($this->session->userdata('roleId') == '3') {?><a href="<?php echo site_url('sale/edit_team/'.$row['saleId'].'/'.$row['mode'].'/'.$row['checked']); ?>"><i class="fa fa-edit" style="font-size:20px"></i></a>&nbsp;<?php }  ?>
                      
                      <?php if($this->session->userdata('roleId') == '1'){?>
                        <a href="<?php echo site_url('sale/delete/'.$row['saleId']); ?>" onclick="return confirm('Are you sure to delete?')"><i class="fa fa-trash" style="font-size:20px;"></i></a><?php } elseif($this->session->userdata('roleId') == '2') {?><a href="<?php echo site_url('sale/delete_staff/'.$row['saleId']); ?>" onclick="return confirm('Are you sure to delete?')"><i class="fa fa-trash" style="font-size:20px;"></i></a><?php } ?></td>
                  </tr>
                  <?php } }else{ ?>
                <tr><td colspan="10">No sale(s) found...</td></tr>
                <?php } ?>
                  </tbody>
                </table>
                </div>
              <?php } ?>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<script>
    $(document).ready(function() {
       $('#searchBtn').on('click', function(){
        //   alert('hello');
          var startDate = $('#min').val();
          var endDate = $('#max').val();
          var roleId = '<?php echo $this->session->userdata('roleId') ?>';
          if(startDate == '' || endDate == ''){
              alert('Any Of them can not be blank.');
          }else{
            //   alert(startDate+" "+endDate+" "+id);
            //   $('#ajaxData').replaceWith('Hello');
              var formData = "SD="+startDate+"&ED="+endDate+"&roleId="+roleId;
              $.ajax({
                 url: '<?=base_url()?>Sale/ajaxSalesData',
                 method: "POST",
                 data: formData,
                 success: function(data) {
                    console.log(data);
                     $('#ajaxData').empty();
                     $('#ajaxData').html(data);
                     //$('#example1').dataTable().fnDestroy();
                     $("#example1").DataTable({
                         "destroy": true,
      "responsive": true, "lengthChange": true, "autoWidth": true,
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
                 }
                 
              });
          }
       }); 
    });
</script>