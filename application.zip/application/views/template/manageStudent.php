
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Manage Student</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
                <?php if($this->session->userdata('roleId') == '1'){ ?>
              <li class="breadcrumb-item active"><a href="<?php echo site_url() ?>Student/add"><i class="fa fa-plus">&nbsp;Add Student</i></a></li><?php } elseif($this->session->userdata('roleId') == '2'){?><li class="breadcrumb-item active"><a href="<?php echo site_url() ?>Student/add_student_staff"><i class="fa fa-plus">&nbsp;Add Student</i></a></li><?php } ?>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                 <!-- Display status message -->
    <?php if(!empty($success_msg)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-success"><?php echo $success_msg; ?></div>
    </div>
    <?php }elseif(!empty($error_msg)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-danger"><?php echo $error_msg; ?></div>
    </div>
    <?php } ?>
    <div class="col-md-12 head">
            <div class="float-right">
                <a href="javascript:void(0);" class="btn btn-success" onclick="formToggle('importFrm');"><i class="plus"></i> Import</a>
            </div>
        </div>
		
        <!-- File upload form -->
		<div class="col-md-12" id="importFrm" style="display: none;">
			 <form action="<?php echo base_url('Student/import'); ?>" method="post" enctype="multipart/form-data">
                <input type="file" name="file" />
                <input type="submit" class="btn btn-primary" name="importSubmit" value="IMPORT">
            </form>
		</div>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <?php if($this->session->userdata('roleId') == '1'){?>
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>Sr.No</th>
                    <th>Name</th>
                    <th>Sale Representative</th>
                    <th>Mobile</th>
                    <th>Mobile(Other)</th>
                    <th style="width: 60px !important;">Email</th>
                    <th style="width: 60px !important;">Courses Enrolled</th>
                    <th>Balance Courses</th>
                    <th>Balance</th>
                    <th>City</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php 
                    $sr = 1;
                    if(!empty($students)){ foreach($students as $row){ ?>
                  <tr>
                    <td><?php echo $sr++; ?></td>
                    <td><?php echo $row['studentName']; ?></td>
                    <td><?php foreach($users as $row3)
                        { 
                          if($row3->userId == $row['userId'] || $row3->userId == $row['SRId'] ){?>
                         <?php echo ucfirst($row3->userName);?>
                       <?php }} ?></td>
                    <td><?php echo $row['studentMobile']; ?></td>
                     <td><?php echo $row['studentMobile2']; ?></td>
                     <td style="width: 60px !important;"><?php echo $row['studentEmail']; ?></td>
                     <td style="width: 60px !important;"><?php echo $this->Batch_model->courseName($row['studentId']) ?></td>
                     <td></td>
                     <td><?php echo $this->Student_model->getTotalCommited($row['studentId'])->CPC - $this->Student_model->getTotalGiven($row['studentId'])['CPG'] ?></td>
                     <td><?php echo $row['studentCity'] ?></td>
                    <td> <?php if($this->session->userdata('roleId') == '1'){?>
                      <a href="<?php echo site_url('student/viewLedger/'.$row['studentId']); ?>"><i class="fas fa-book" style="font-size:20px"></i></a>&nbsp;<a href="<?php echo site_url('student/view/'.$row['studentId']); ?>"><i class="fa fa-eye" style="font-size:20px"></i></a><?php }else {?><a href="<?php echo site_url('student/viewLedger/'.$row['studentId']); ?>"><i class="fas fa-book" style="font-size:20px"></i></a>&nbsp; <a href="<?php echo site_url('student/view_staff/'.$row['studentId']); ?>"><i class="fa fa-eye" style="font-size:20px"></i></a>
                      <?php }?>
                      <?php if($this->session->userdata('roleId') == '1'){?>
                      &nbsp;<a href="<?php echo site_url('student/edit/'.$row['studentId']); ?>"><i class="fa fa-edit" style="font-size:20px"></i></a>&nbsp;<?php }else {?><a href="<?php echo site_url('student/edit_student_staff/'.$row['studentId']); ?>"><i class="fa fa-edit" style="font-size:20px"></i></a><?php }?>
                       <?php if($this->session->userdata('roleId') == '1'){?>
                        <a href="<?php echo site_url('student/delete/'.$row['studentId']); ?>" onclick="return confirm('Are you sure to delete?')"><i class="fa fa-trash" style="font-size:20px;"></i></a><?php }else {?> <a href="<?php echo site_url('student/delete_student_staff/'.$row['studentId']); ?>" onclick="return confirm('Are you sure to delete?')"><i class="fa fa-trash" style="font-size:20px;"></i></a><?php }?></td>
                  </tr>
                  <?php } }else{ ?>
                <tr><td colspan="7">No student(s) found...</td></tr>
                <?php } ?>
                  </tbody>
                </table>
              <?php } else {?>
              <table id="example2" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>Sr.No</th>
                    <th>Name</th>
                    <th>Sale Representative</th>
                    <th>Mobile</th>
                    <th>Mobile(Other)</th>
                    <th style="width: 60px !important;">Email</th>
                    <th style="width: 60px !important;">Courses Enrolled</th>
                    <th>Balance Courses</th>
                    <th>Balance</th>
                    <th>City</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php 
                    $sr = 1;
                    if(!empty($students)){ foreach($students as $row){ ?>
                  <tr>
                    <td><?php echo $sr++; ?></td>
                    <td><?php echo $row['studentName']; ?></td>
                    <td><?php foreach($users as $row3)
                        { 
                          if($row3->userId == $row['userId'] || $row3->userId == $row['SRId'] ){?>
                         <?php echo ucfirst($row3->userName);?>
                       <?php }} ?></td>
                    <td><?php echo $row['studentMobile']; ?></td>
                     <td><?php echo $row['studentMobile2']; ?></td>
                     <td style="width: 60px !important;"><?php echo $row['studentEmail']; ?></td>
                     <td style="width: 60px !important;"><?php echo $this->Batch_model->courseName($row['studentId']) ?></td>
                     <td></td>
                     <td><?php echo $this->Student_model->getTotalCommited($row['studentId'])->CPC - $this->Student_model->getTotalGiven($row['studentId'])['CPG'] ?></td>
                     <td><?php echo $row['studentCity'] ?></td>
                    <td> <?php if($this->session->userdata('roleId') == '1'){?>
                      <a href="<?php echo site_url('student/viewLedger/'.$row['studentId']); ?>"><i class="fas fa-book" style="font-size:20px"></i></a>&nbsp;<a href="<?php echo site_url('student/view/'.$row['studentId']); ?>"><i class="fa fa-eye" style="font-size:20px"></i></a><?php }else {?><a href="<?php echo site_url('student/viewLedger/'.$row['studentId']); ?>"><i class="fas fa-book" style="font-size:20px"></i></a>&nbsp; <a href="<?php echo site_url('student/view_staff/'.$row['studentId']); ?>"><i class="fa fa-eye" style="font-size:20px"></i></a>
                      <?php }?>
                      <?php if($this->session->userdata('roleId') == '1'){?>
                      &nbsp;<a href="<?php echo site_url('student/edit/'.$row['studentId']); ?>"><i class="fa fa-edit" style="font-size:20px"></i></a>&nbsp;<?php }elseif($this->session->userdata('roleId') == '2') {?><a href="<?php echo site_url('student/edit_student_staff/'.$row['studentId']); ?>"><i class="fa fa-edit" style="font-size:20px"></i></a><?php }?>
                       <?php if($this->session->userdata('roleId') == '1'){?>
                        <a href="<?php echo site_url('student/delete/'.$row['studentId']); ?>" onclick="return confirm('Are you sure to delete?')"><i class="fa fa-trash" style="font-size:20px;"></i></a><?php }elseif($this->session->userdata('roleId') == '2') {?> <a href="<?php echo site_url('student/delete_student_staff/'.$row['studentId']); ?>" onclick="return confirm('Are you sure to delete?')"><i class="fa fa-trash" style="font-size:20px;"></i></a><?php }?></td>
                  </tr>
                  <?php } }else{ ?>
                <tr><td colspan="7">No student(s) found...</td></tr>
                <?php } ?>
                  </tbody>
                </table>
                 <?php } ?> 
              </div>
             
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <script>
function formToggle(ID){
	var element = document.getElementById(ID);
	if(element.style.display === "none"){
		element.style.display = "block";
	}else{
		element.style.display = "none";
	}
}
</script>