<link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
<script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?php echo $title; ?></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active"><a href="<?php echo site_url() ?>Settings/GST_setting"><i class="fas fa-folder">&nbsp;GST Module</i></a></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <?php if (!empty($success_msg)) { ?>
          <div class="col-xs-12">
            <div class="alert alert-success"><?php echo $success_msg; ?></div>
          </div>
        <?php } elseif (!empty($error_msg)) { ?>
          <div class="col-xs-12">
            <div class="alert alert-danger"><?php echo $error_msg; ?></div>
          </div>
        <?php } ?>
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- right column -->
          <div class="col-md-12">
            <!-- Form Element sizes -->
                   <!-- general form elements disabled -->
            <div class="card card-warning">
              <div class="card-header">
                <h3 class="card-title">Add GST Settings</h3>
              </div>
              <!-- /.card-header -->
              <!-- Display status message -->
    <?php if(!empty($success_msg)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-success"><?php echo $success_msg; ?></div>
    </div>
    <?php }elseif(!empty($error_msg)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-danger"><?php echo $error_msg; ?></div>
    </div>
    <?php } ?>
    <?php echo '<div style="color:red;">';
    echo validation_errors();
    echo '</div>'; ?>
              <div class="card-body">
                 <form method="post" action="<?php echo site_url() ?>Settings/addGstSetting" enctype='multipart/form-data'>
                  <!-- input states -->
                  <div class="form-group">
                      <!-- Default switch -->
                    <div class="custom-control custom-switch">
                      <input type="checkbox" class="custom-control-input" <?php if($gstData['settingStatus'] == 'on'){ ?> checked <?php } ?> name="gstOn" id="customSwitches">
                      <label class="custom-control-label" for="customSwitches">GST Module ON / OFF</label>
                    </div>
                  </div>
                  <div class="form-group">
                      <label>Batch</label>
                      <select id="selectoption"  class="form-control select2" style="width: 100%;" name="gstPercent">
                        <option value="" data-price="">--Select Percent--</option>
                        <option <?php if($gstData['gstPercent'] == 5){ ?>selected<?php } ?> value="5">5%</option>
                        <option <?php if($gstData['gstPercent'] == 12){ ?>selected<?php } ?> value="12">12%</option>
                        <option <?php if($gstData['gstPercent'] == 18){ ?>selected<?php } ?> value="18">18%</option>
                        <option <?php if($gstData['gstPercent'] == 28){ ?>selected<?php } ?> value="28">28%</option>
                      </select>
                  <?php echo form_error('gstPercent','<div style="color:red;">','</div>'); ?>
                </div>
                     
                 <div class="card-footer">
                  <input type="submit" class="btn btn-primary" id="settingSubmit" name="settingSubmit" value="Submit">
                  <a href="<?php echo site_url('Sale/sale_tab'); ?>" class="btn btn-secondary">Back</a>
                </div>
                </form>
              </div>
              <!-- /.card-body -->
              <div class="card-body">
                  <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>Sr.No</th>
                    <th>GST Status</th>
                    <th>GST %</th>
                    <th>Created Date</th>
                  </tr>
                  </thead>
                  <tbody>
                      <?php
                      $sr = 1;
                      ?>
                      <?php if(!empty($gstData)){ ?>
                      <td><?php echo $sr++; ?></td>
                      <td><?php echo ucfirst($gstData['settingStatus']) ?></td>
                      <td><?php echo $gstData['gstPercent']."%"; ?></td>
                      <td><?php echo date('d-M-Y H:i:s a', strtotime($gstData['createdAt'])); ?></td>
                      <?php } ?>
                  </tbody>
                  </table>
              </div>
            </div>
            <!-- /.card -->
          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script>
      $(document).ready(function(){
          $('#discount').on('keyup', function(){
              var discount = $(this).val();
              var pdiscount = $('#pDiscount').val();
              var pgiven =$('#pFeeGiven').val();
              var price = $('#priceInput').val();
              var actual = price - discount -pgiven - pdiscount;
              $('#actual').val(actual);
              $('#feeremain').val(actual);
              
          });
          $('#discount').on('keydown', function(){
              display();
          });
      });
      
  </script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){  
$("#doing").hide();
$("#tpe").click(function() {
    if($(this).is(":checked")) {
        $("#doing").show();
        $("#original").hide();
    } else  {
      if($("#radio2").is(":checked")) {
        $("#doing").hide();
        $("#original").hide();
    }
    else{
     $("#doing").hide();
        $("#original").show();
    
    }
    }
});
});
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript">
function checkMode() {
var mode = '<?php echo $mode; ?>';
var checked = '<?php echo $checked; ?>';
if(mode == 'direct' && checked == 0){
$("#doing").hide(); 
$("#original").show(); 
}else if(mode == 'direct' && checked == 1){
$("#original").hide(); 
$("#doing").show(); 
}else if(mode == 'indirect' && checked == 0){
$("#original").hide(); 
$("#doing").hide();
}else{
$("#original").hide(); 
$("#doing").show(); 
}
}

</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){ 
//$("#original").hide(); 
$("#radio2").click(function() {
    if($(this).is(":checked")) {
      //alert("Hi");
      if($("#tpe").is(":checked")){
        $("#original").hide();
        $("#doing").show();
        show2();
    } 
    else{
    //alert("Hello");
    $("#original").hide();
        $("#doing").hide();
    
    }
    }
    
});
$("#radio1").click(function() {
        if($(this).is(":checked")) {
      //alert("Hi");
      if($("#tpe").is(":checked")){
        $("#original").hide();
        $("#doing").show();
        show2();
    } 
    else{
    $("#original").show();
        $("#doing").hide();
    
    }
    }
});
});
</script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<script>
  let show = () => {
    let element = document.getElementById("selectoption");
    let price = element.options[element.selectedIndex].getAttribute("data-price");    
    $('#priceInput').val(price);
    $('#actual').val(price);

  }
</script>
<script>
 function show1()  {
    let element = document.getElementById("selectoption1");
    let percent = element.options[element.selectedIndex].getAttribute("data-price");
    let team = element.options[element.selectedIndex].getAttribute("data-price1");
    //alert("Price: " + price);
    let pce = "";
    let tce ="";

    if($('#radio1').is(":checked"))
    {
      if($('#radio1').is(":checked") && $('#tpe').is(":checked")){
       pce = (percent *100)/2;
      }else{
      pce = percent *100;
      tce = team *100;
      }
      }else if($('#radio2').is(":checked")){
        if($('#radio2').is(":checked") && $('#tpe').is(":checked")){
            pce = ((percent *100)/2)/2;
        }else{
            pce = (percent *100)/2;
        }
      }else{
         if($('#radio3').is(":checked") && $('#tpe').is(":checked")){
             pce = 0;
         }
      }

      /*
     if($('#radio2').is(":checked"))
     {
      pce = (percent *100)/2;
     }
     else
     {
      pce = percent *100;
      tce = team *100;
     }
     if($('#radio1').is(":checked") && $('#tpe').is(":checked"))
     {
      //alert("HI");
      pce = (percent *100)/2;
       //alert(pce);
     }
     else
     {
      alert("Hello");
      pce = percent *100;
      tce = team *100;
     }
     if($('#radio2').is(":checked") && $('#tpe').is(":checked"))
     {
      pce = ((percent *100)/2)/2;
     }
     else
     {
      pce = percent *100;
      tce = team *100;
     }*/
    // let TLId = <?php //echo $this->Incentive_model->checkTL(10) ?>;
    $('#priceInput1').val(pce);
    $('#priceInput2').val(tce);
    // $('#TLId').val(TLId);

  }
  $(document).ready(function(){
      $('#feegiven').keyup(function(){
      
         remain();
         ncd();
         centive();
         centive1();
         centive11();
      });
      $('#feegiven').keydown(function(){
    
         remain();
         ncd();
         centive();
         centive1();
         centive11();
      });
  });
</script>
<script>
 function show2()  {
    let element11 = document.getElementById("selectoption3");
    let percent11 = element11.options[element11.selectedIndex].getAttribute("data-price");
    //alert("Price: " + price);
    let pce11="";
      if($('#tpe').is(":checked"))
      {
     pce11 = (percent11 *100)/2;
       }
        if($('#radio1').is(":checked") && $('#tpe').is(":checked"))
       {
        pce11 = (percent11 *100)/2;
       }
       if($('#radio2').is(":checked") && $('#tpe').is(":checked"))
       {
        pce11 = ((percent11 *100)/2)/2;

       }
    
    // let TLId = <?php //echo $this->Incentive_model->checkTL(10) ?>;
    $('#priceInput11').val(pce11);
    // $('#TLId').val(TLId);

  }
</script>
<script>
    $(document).ready(function(){
       $('#selectoption2').on('change', function(){
          var batchId = $('#selectoption').val();
          var studentId = $(this).val();
          var formData = "batchId="+batchId+"&studentId="+studentId;
          $.ajax({
             url: '<?=base_url()?>/Sale/ajaxCall',
             method: "POST",
             data: formData,
             success: function(data) {
                //  alert(data);
                 var data1 = $.parseJSON(data);
                 $('#pFeeGiven').val(data1.pFee);
                 $('#pDiscount').val(data1.CD);
             }
             
          });
       });
      $('#selectoption2').on('change', function(){
          var batchId = $('#selectoption').val();
          var studentId = $(this).val();
          var formData = "batchId="+batchId+"&studentId="+studentId;
          $.ajax({
             url: '<?=base_url()?>/Sale/ajaxCallDI/'+batchId+'/'+studentId,
             method: "POST",
             data: formData,
             success: function(data) {
                //  alert('This Student Have last mode is : '+data+' kindly select accordingly.');
                 if(data == 'direct') {
                    //  alert(data);
                     $('#radio1').attr('checked', true);
                     $('#radio2').prop("disabled", true);
                 }else if(data == 'indirect') {
                    //  alert(data+'2');
                      $('#radio2').attr('checked', true);
                      $('#radio1').prop("disabled", true);
                 }else{
                    //  alert(data+'1');
                      $('#radio1').attr('checked', true);
                     $('#radio2').prop("disabled", false);
                 }
             }
             
          });
      });
    });
</script>

<script>
  function amount(){
     var f1 =document.getElementById("actual").value;
    var f2 =document.getElementById("feegiven").value;
    //alert(discount)
    var f3 = document.getElementById('pDiscount').value;
    var f4 = document.getElementById("pFeeGiven").value;
    //alert(price);
   var f = f1-f2-f3-f4;
   //const button = document.querySelector("saleButton");
   if(f < 0 ){ 
       alert("Given fees not exceed than total fees"); 
       $('#saleButton').prop('disabled', true);
   }else{
       $('#saleButton').prop('disabled', false);
   }
   //$('#feegiven').val(f);
    //alert(actual);
  }
</script>
<script>
  function display(){
    var discount =document.getElementById("discount").value;
    //alert(discount)
    var price = document.getElementById("priceInput").value;
    //alert(price);
  var actual = price - discount;
  $('#actual').val(actual);
    //alert(actual);
  }
</script>
<script>
  function remain(){
    var feea =document.getElementById("actual").value;
    //alert(discount)
    var feeg = document.getElementById("feegiven").value;
    
    var feeD = document.getElementById("pDiscount").value;
    
    var prePay = document.getElementById("pFeeGiven").value;
    //alert(price);
   var feeremain = feea - feeg - prePay - feeD;
   $('#feeremain').val(feeremain);
    //alert(actual);
  }
</script>

<script>
  function centive(){
    var feeg =document.getElementById("feegiven").value;
    var prec =document.getElementById("priceInput1").value;
    //alert(feeg);
    //var incen = 0.1;
    pce = prec/100;
    var incentive = feeg * pce;
    //alert(incentive);
   $('#incentive').val(incentive.toFixed());
    //alert(actual);
  }
</script>
<script>
  function centive1(){
    var feeg =document.getElementById("feegiven").value;
    var prec1 =document.getElementById("priceInput2").value;
    //alert(feeg);
    //var incen = 0.1;
    tce = prec1/100;
    var incentive1 = feeg * tce;
    //alert(incentive);
   $('#incentive1').val(incentive1.toFixed());
    //alert(actual);
  }
</script>
<script>
  function centive11(){
    var feeg =document.getElementById("feegiven").value;
    var prec11 =document.getElementById("priceInput11").value;
    //alert(feeg);
    //var incen = 0.1;
    tce = prec11/100;
    var incentive2 = feeg * tce;
    //alert(incentive);
   $('#incentive11').val(incentive2.toFixed());
    //alert(actual);
  }
</script>
<script>
  function ncd(){
    var f2 =document.getElementById("feeremain").value;
   if(f2 == 0 ){ document.getElementById("nc").style.display = 'none'; }
   //$('#feegiven').val(f);
    //alert(actual);
  }
</script>
<script type="text/javascript">
function custompopup(){  
let newWindow = window.open('<?php echo site_url() ?>Student/add', 'Add Student','width=600,height=600,target=popup');
window.onunload = refreshParent;
    function refreshParent() {
        window.opener.location.reload();
    }
}
</script>
