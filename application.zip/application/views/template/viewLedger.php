<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?php echo $title; ?></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title"></h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                  <div class="row">
                <div class="col-md-6">
                    <div class="row">
                        <div class="col-md-6"><b>Name: </b></div>
                        <div class="col-md-6"><?php echo $studentDetails['studentName']; ?></div>
                    </div>
                    <div class="row">
                        <div class="col-md-6"><b>Email: </b></div>
                        <div class="col-md-6"><?php echo $studentDetails['studentEmail']; ?></div>
                    </div>
                    <div class="row">
                        <div class="col-md-6"><b>Mobile: </b></div>
                        <div class="col-md-6"><?php echo $studentDetails['studentMobile']; ?></div>
                    </div>
                    <div class="row">
                        <div class="col-md-6"><b>Details: </b></div>
                        <div class="col-md-6"><?php echo $studentDetails['studentDetails']; ?></div>
                    </div>
                    <div class="row">
                        <div class="col-md-6"><b>Status: </b></div>
                        <div class="col-md-6"><?php if($studentDetails['studentStatus'] == '1') echo "Active"; else echo "Inactive"; ?></div>
                    </div>
                    <div class="row">
                        <div class="col-md-6"><b>Sales Representative: </b></div>
                        <div class="col-md-6"></div>
                    </div>
                     <?php //if($this->session->userdata('roleId') == '1'){ ?>
                    <!--<a href="<?php //echo site_url('Student/student_tab'); ?>" class="btn btn-primary">Back To List</a><?php //} else{?>-->
                      <!--<a href="<?php //echo site_url('Student/student_staff_tab'); ?>" class="btn btn-primary">Back To List</a>-->
                    <?php //}?>
                </div>
                <div class="col-md-6">
                    <div class="row">
                        <div class="col-md-12"><b>Account Summary</b></div>
                    </div>
                    <div class="row">
                        <div class="col-md-6"><b>Amount Debited: </b></div>
                        <div class="col-md-6"><b><?php echo $studentCommited->CPC; ?></b></div>
                    </div>
                    <div class="row">
                        <div class="col-md-6"><b>Amount Credited: </b></div>
                        <div class="col-md-6"><b><?php echo $studentGiven['CPG']; ?></b></div>
                    </div>
                    <hr/>
                    <div class="row">
                        <div class="col-md-6"><b>Balance Due: </b></div>
                        <div class="col-md-6"><b><?php echo $studentCommited->CPC - $studentGiven['CPG']; ?></b></div>
                    </div>
                </div>
                </div>
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>S. No.</th>
                            <th>Transaction Date</th>
                            <!--<th>Transaction</th>-->
                            <th>Course</th>
                            <th>Debit</th>
                            <th>Credit</th>
                            <th>Balance</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                    $sr = 1;
                    if(!empty($studentLedger)){ foreach($studentLedger as $row){ ?>
                    <tr>
                        <td><?php echo $sr++; ?></td>
                        <td><?php echo date('d-M-Y', strtotime($row->transactionDate)); ?></td>
                        <!--<td><?php echo 'Sales / Payment'; ?></td>-->
                        <td><?php echo $this->Incentive_model->courseName($row->batchId)->courseName ?></td>
                        <td><?php echo (float)$row->coursePriceCommited - (float)$row->coursePricePre; ?></td>
                        <td><?php echo (float)$row->couesePriceGiven; ?></td>
                        <td><?php echo (float)$row->coursePriceCommited - (float)$row->couesePriceGiven - (float)$row->coursePricePre; ?></td>
                        <td><a href="<?php echo site_url('sale/invoice/'.$row->saleId); ?>" placeholder="Generate Invoice"><i class="fa fa-file" style="font-size: 20px;"></i></a></td>
                    </tr>
                    <?php }}?>
                    
                    </tbody>
                </table>
            </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->