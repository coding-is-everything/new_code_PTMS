<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Manage Property</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active"><a href="<?php echo site_url() ?>Property/add"><i class="fa fa-plus">&nbsp;Add Property</i></a></li>
            </ol>
          </div>

        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              
              <div class="card-header">
                
             <!-- Display status message -->
    <?php if(!empty($success_msg)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-success"><?php echo $success_msg; ?></div>
    </div>
    <?php }elseif(!empty($error_msg)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-danger"><?php echo $error_msg; ?></div>
    </div>
    <?php } ?>
              </div>
              <div class="card-body">
                  <?php if($this->session->userdata('roleType') === 'Admin'){ ?>
                  <form method="post" action="<?php echo site_url() ?>property/importCSV" enctype="multipart/form-data">
                  <div class="form-group">
                      <div class="row">
                          <div class="col-lg-6 col-md-6 col-sm-12">
                              <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Import Property Data</label>
                            <input type="file" class="form-control is-valid" name="importData" id="inputSuccess"/>
                          </div>
                          <div class="col-mg-6 col-md-6 col-sm-12">
                              <label class="col-form-label" for="inputSuccess">Submit</label><br/>
                              <button type="submit" name="importSubmit" class="btn btn-success is-valid">Import Data</button>
                          </div>
                      </div>
                  </div>
                  </form>
                  <?php } ?>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped table-responsive">
                  <thead class="bg-success">
                  <tr>
                    <th>Sr.No</th>
                    <th>Owner Name</th>
                    <th>Guardian Name</th>
                    <th>Zone Name</th>
                    <th>Ward Name</th>
                    <th>Parikshetra Number</th>
                    <th>Main road or internal road</th>
                    <th>Floor(SBA)</th>
                    <th>Type of property( Pucca, kaccha, ard pucca)</th>
                    <th>Property Id</th>
                    <!--<th>Floor(Residential/ commercial)</th>-->
                    <!--<th>Last tax payment amount</th>-->
                    <!--<th>Year of last tax paid </th>-->
                    <!--<th>Gender</th>-->
                    <!--<th>Mobile Number</th>-->
                    <!--<th>Address</th>-->
                    <!--<th>Colony</th>-->
                    <!--<th>Occupant type(self/ rental/mixed)</th>-->
                    <!--<th>Pincode</th>-->
                    <!--<th>Area of plot</th>-->
                    <!--<th>Area of building footprint</th>-->
                    <!--<th>Total floors(G+N)</th>-->
                    <!--<th>Latitude</th>-->
                    <!--<th>Longitude</th>-->
                    <!--<th>Is property available in BMC record(yes/no)</th>-->
                    <!--<th>Property image</th>-->
                    <!--<th>Open plot(sft)</th>-->
                    <!--<th>Penalty</th>-->
                    <th>ARI Audit Status</th>
                    <th>ARO Audit Status</th>
                    <th>Zone Commissioner Audit Status</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php
                    $sr = 1;
                    if(!empty($properties)){ foreach($properties as $prop) {
                    ?>
                    <tr>
                        <td><?php echo $sr++; ?></td>
                        <td><?php echo strtoupper($prop->owner_name); ?></td>
                        <td><?php echo strtoupper($prop->guardian_name); ?></td>
                        <td><?php echo $this->Ward_model->getZoneDetail($prop->zone_no)[0]->zoneName; ?></td>
                        <td><?php echo $this->Ward_model->getWardDetail($prop->ward_no)[0]->wardName; ?>( <?php echo $this->Ward_model->getWardDetail($prop->ward_no)[0]->wardId ?> )</td>
                        <td><?php echo !empty($prop->parikshetra_number)?$prop->parikshetra_number:'No Data'; ?></td>
                        <td><?php echo !empty($prop->road_type)?$prop->road_type:'No Data'; ?></td>
                        <td><?php echo !empty($prop->floor_SBA)?$prop->floor_SBA:'No Data'; ?></td>
                        <td><?php echo $prop->const_type; ?></td>
                        <td><?php echo $prop->new_pro_no ?></td>
                        <!--<td><?php echo !empty($prop->floor_type)?$prop->floor_type:'No Data'; ?></td>-->
                        <!--<td><?php echo !empty($prop->last_tax_pay_amount)?$prop->last_tax_pay_amount:'No Data'; ?></td>-->
                        <!--<td><?php echo !empty($prop->year_of_last_tax_paid)?$prop->year_of_last_tax_paid:'No Data'; ?></td>-->
                        <!--<td><?php echo !empty($prop->gender)?strtoupper($prop->gender):'No Data'; ?></td>-->
                        <!--<td><?php echo substr($prop->mobile,0, 10); ?></td>-->
                        <!--<td><?php echo $prop->address; ?></td>-->
                        <!--<td><?php echo !empty($prop->colony)?$prop->colony:'No Data'; ?></td>-->
                        <!--<td><?php echo !empty($prop->floor_wise_occup_type)?$prop->floor_wise_occup_type:'No Data'; ?></td>-->
                        <!--<td><?php echo !empty($prop->pin_code)?$prop->pin_code:'No Data'; ?></td>-->
                        <!--<td><?php echo !empty($prop->area_of_plot_as_per_gis)?$prop->area_of_plot_as_per_gis:'No Data'; ?></td>-->
                        <!--<td><?php echo !empty($prop->area_of_building_footprint_as_per_gis)?$prop->area_of_building_footprint_as_per_gis:'No Data'; ?></td>-->
                        <!--<td><?php echo !empty($prop->total_floors)?$prop->total_floors:'No Data'; ?></td>-->
                        <!--<td><?php echo !empty($prop->latitude)?$prop->latitude:'No Data'; ?></td>-->
                        <!--<td><?php echo !empty($prop->longitude)?$prop->longitude:'No Data'; ?></td>-->
                        <!--<td><?php echo !empty($prop->is_property_available_bmc)?$prop->is_property_available_bmc:'No Data'; ?></td>-->
                        <!--<td><?php echo !empty($prop->property_image) ? "<img src='".$prop->property_image."' style='width: 80px; height: 80px;' />" : 'No Data' ?></td>-->
                        <!--<td><?php echo !empty($prop->open_plots) ? $prop->open_plots : 'No Data' ?></td>-->
                        <!--<td><?php echo !empty($prop->penality)?$prop->penality:'No Data'; ?></td>-->
                        <td><?php echo !empty($prop->ARI_audit_status)?$prop->ARI_audit_status:'Approval Pending From ARI'; ?></td>
                        <td><?php echo !empty($prop->ARO_audit_status)?$prop->ARO_audit_status:'Approval Pending From ARO'; ?></td>
                        <td><?php echo !empty($prop->ZC_audit_status)?$prop->ZC_audit_status:'Approval Pending From Zone Commissioner'; ?></td>
                        <td>
                      &nbsp;<?php if($this->session->userdata('roleId') == 1){ ?>
                        <a href="<?php echo site_url('Property/edit/'.$prop->id); ?>"><i class="fa fa-edit" style="font-size:20px"></i></a>&nbsp;
                      <?php }elseif($this->session->userdata('roleId') == 2){ ?>
                        <a href="<?php echo site_url('Ari/editProperty/'.$prop->id); ?>"><i class="fa fa-edit" style="font-size:20px"></i></a>&nbsp;
                      <?php }elseif($this->session->userdata('roleId') == 3){ ?>
                        <a href="<?php echo site_url('Aro/editProperty/'.$prop->id); ?>"><i class="fa fa-edit" style="font-size:20px"></i></a>&nbsp;
                      <?php }elseif($this->session->userdata('roleId') == 4){ ?>
                        <a href="<?php echo site_url('Zonecommissioner/editProperty/'.$prop->id); ?>"><i class="fa fa-edit" style="font-size:20px"></i></a>&nbsp;
                      <?php } ?>
                        <a href="<?php echo site_url('Property/delete/'.$prop->id); ?>" onclick="return confirm('Are you sure to delete?')"><i class="fa fa-trash" style="font-size:20px;"></i></a></td>
                    </tr>
                    <?php
                    }}
                    ?>
                  </tbody>
                </table>
                 <div class="pagination pull-right">
            <?php echo $this->pagination->create_links(); ?>
        </div>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->