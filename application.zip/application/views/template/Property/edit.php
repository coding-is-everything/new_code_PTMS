<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Edit Property</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active"><a href="<?php echo site_url() ?>Property/getData"><i class="fas fa-folder">&nbsp;Manage Properties</i></a></li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <!-- right column -->
                <div class="col-md-12">
                    <!-- Form Element sizes -->
                    <!-- general form elements disabled -->
                    <div class="card card-warning">
                        <div class="card-header">
                            <h3 class="card-title">Edit Property</h3>
                        </div>
                        <!-- /.card-header -->
                        <!-- Display status message -->
                        <?php if (!empty($success_msg)) { ?>
                            <div class="col-xs-12">
                                <div class="alert alert-success"><?php echo $success_msg; ?></div>
                            </div>
                        <?php } elseif (!empty($error_msg)) { ?>
                            <div class="col-xs-12">
                                <div class="alert alert-danger"><?php echo $error_msg; ?></div>
                            </div>
                        <?php } ?>
                        <div class="card-body">
                            
                            <form method="post" action="<?php echo site_url() ?>Property/editEntry/<?php echo $id ?>"  enctype='multipart/form-data'>
                                <!-- input states -->
                                <div class="form-group">
                                    <div class="row">
                                        <div id="map"></div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-4 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Household latitude</label>
                                            <input type="text" readonly class="form-control is-valid" name="latitude" id="inputSuccess" autocomplete="off" placeholder="Enter Household latitude" value="<?php echo !empty($_POST['latitude']) ? $_POST['latitude'] : $prop[0]->latitude; ?>">
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> household longitude</label>
                                            <input type="text" readonly class="form-control is-valid" name="longitude" id="inputSuccess" autocomplete="off" placeholder="Enter Household latitude" value="<?php echo !empty($_POST['longitude']) ? $_POST['longitude'] : $prop[0]->longitude; ?>">
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Property Available in BMC Record</label>
                                            <select class="form-control select2" style="width: 100%;" name="is_property_available_in_bmc_record" id="inputSuccess">
                                                <option value="">Select Property Available in BMC</option>
                                                <option <?php if($prop[0]->is_property_available_in_bmc_record == 'Yes'){ ?>selected<?php } ?> value="Yes">Yes</option>
                                                <option <?php if($prop[0]->is_property_available_in_bmc_record == 'No'){ ?>selected<?php } ?> value="No">No</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-4 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> New Property Number</label>
                                            <input type="text" class="form-control is-valid" readonly name="new_pro_no" id="inputSuccess" autocomplete="off" placeholder="Enter Property Id" value="<?php echo $prop[0]->new_pro_no; ?>">
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Owner Name</label>
                                            <input type="text" class="form-control is-valid" name="owner_name" id="inputSuccess" autocomplete="off" placeholder="Enter Owner Name" value="<?php echo !empty($_POST['owner_name']) ? $_POST['owner_name'] : $prop[0]->owner_name; ?>">
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Gender</label>
                                            <select class="form-control select2" style="width: 100%;" name="gender" id="inputSuccess">
                                                <option value="">Select Gender</option>
                                                <option <?php if($prop[0]->gender == 'MALE'){ ?>selected<?php } ?> value="MALE">Male</option>
                                                <option <?php if($prop[0]->gender == 'FEMALE'){ ?>selected<?php } ?> value="FEMALE">Female</option>
                                                <option <?php if($prop[0]->gender == 'OTHER'){ ?>selected<?php } ?> value="OTHER">Other</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <!-- Mobile/Guardian/Occupant Type -->
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-4 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Mobile Number</label>
                                            <input type="text" class="form-control is-valid" name="mobile" id="inputSuccess" autocomplete="off" placeholder="Enter Mobile Number" value="<?php echo !empty($_POST['mobile']) ? $_POST['mobile'] : $prop[0]->mobile; ?>">
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Guardian Name</label>
                                            <input type="text" class="form-control is-valid" name="guardian_name" id="inputSuccess" autocomplete="off" placeholder="Enter Guardian Name" value="<?php echo !empty($_POST['guardian_name']) ? $_POST['guardian_name'] : $prop[0]->guardian_name; ?>">
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Road Location Type</label>
                                            <select class="form-control select2" style="width: 100%;" name="road_type" id="inputSuccess">
                                                <option value="">Select Road Location Type</option>
                                                <option <?php if($prop[0]->road_type == 'mainRoad'){ ?>selected<?php } ?> value="mainRoad">Main Road</option>
                                                <option <?php if($prop[0]->road_type == 'internalRoad'){ ?>selected<?php } ?> value="internalRoad">Internal Road</option>
                                            </select>
                                        </div>
                                        
                                    </div>
                                </div>
                                <!--Colony / Address-->
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-4 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Colony</label>
                                            <input type="text" class="form-control is-valid" name="colony" id="inputSuccess" autocomplete="off" placeholder="Enter Colony" value="<?php echo !empty($_POST['colony']) ? $_POST['colony'] : $prop[0]->colony; ?>">
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Address</label>
                                            <input type="text" class="form-control is-valid" name="address" id="inputSuccess" autocomplete="off" placeholder="Enter Address" value="<?php echo !empty($_POST['address']) ? $_POST['address'] : $prop[0]->address; ?>">
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> DDN</label>
                                            <input type="text" readonly class="form-control is-valid" name="DDN" id="inputSuccess" autocomplete="off" placeholder="Enter DDN" value="<?php echo !empty($_POST['DDN']) ? $_POST['DDN'] : $prop[0]->DDN ?>" />
                                        </div>
                                    </div>
                                </div>
                                <!--PinCode / Property Usage / Property Type-->
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-4 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Pin Code</label>
                                            <input type="text" class="form-control is-valid" name="pin_code" id="inputSuccess" autocomplete="off" placeholder="Enter PinCode" value="<?php echo !empty($_POST['pin_code']) ? $_POST['pin_code'] : $prop[0]->pin_code; ?>">
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Parikshetra (number)</label>
                                            <input type="text" class="form-control is-valid" name="parikshetra_number" id="inputSuccess" autocomplete="off" placeholder="Enter Parikshetra (number)" value="<?php echo !empty($_POST['parikshetra_number']) ? $_POST['parikshetra_number'] : $prop[0]->parikshetra_number; ?>">
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Construction type</label>
                                            <select class="form-control select2" style="width: 100%;" name="const_type" id="inputSuccess">
                                                <option value="">Select Construction type</option>
                                                <option <?php if($prop[0]->const_type == 'PUCCA'){ ?>selected<?php } ?> value="PUCCA">PUCCA</option>
                                                <option <?php if($prop[0]->const_type == 'KUCCA'){ ?>selected<?php } ?> value="KUCCHA">KUCCHA</option>
                                                <option <?php if($prop[0]->const_type == 'ARD PUCCA'){ ?>selected<?php } ?> value="ARD PUCCA">ARD PUCCA</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                
                                <!--Parikshetra (number)/Construction type/Area of GIS as per Drone-->
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Area of Plot / Parcel As per GIS Survey</label>
                                            <input type="text" readonly name="area_of_plot_as_per_gis" id="area_of_plot_as_per_gis" placeholder="Enter Area Of GIS" value="<?php echo !empty($_POST['area_of_plot_as_per_gis']) ? $_POST['area_of_plot_as_per_gis'] : $prop[0]->area_of_plot_as_per_gis ?>" class="form-control" />
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Area of Building Footprint as Per GIS Survey</label>
                                            <input type="text" readonly name="area_of_building_footprint_as_per_gis" placeholder="Enter Building Footprint" value="<?php echo !empty($_POST['area_of_building_footprint_as_per_gis']) ? $_POST['area_of_building_footprint_as_per_gis'] : $prop[0]->area_of_building_footprint_as_per_gis ?>" class="form-control" />
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Last tax paid amount</label>
                                            <input class="form-control" name="last_tax_pay_amount" id="last_tax_pay_amount" placeholder="Enter Last Tax Paid Amount" value="<?php echo !empty($_POST['last_tax_pay_amount']) ? $_POST['last_tax_pay_amount'] : $prop[0]->last_tax_pay_amount ?>" />
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Year Of Last Tax Payment (FY)</label>
                                            <!--<input type="text" class="form-control is-valid" name="year_of_last_tax_paid" id="inputSuccess" autocomplete="off" placeholder="Enter Year Of Last Tax Payment" value="<?php echo !empty($_POST['year_of_last_tax_paid']) ? $_POST['year_of_last_tax_paid'] : $prop[0]->year_of_last_tax_paid; ?>">-->
                                            <select name="year_of_last_tax_paid" id="year_of_last_tax_paid" class="form-control select2">
                                    			<?php
                                    			// Define the starting and ending years for the dropdown menu
                                    			$start_year = 1970;
                                    			$end_year = date('Y') + 1;
                                    
                                    			// Create a list of financial year options
                                    			$financial_years = array();
                                    			for ($year = $start_year; $year < $end_year; $year++) {
                                    				$financial_year = $year . '-' . ($year + 1);
                                    				$financial_years[] = $financial_year;
                                    			?>
                                    				<option <?php if($prop[0]->year_of_last_tax_paid == $financial_year){ ?>selected <?php } ?>value="<?php echo $financial_year ?>"><?php echo $financial_year; ?></option>
                                    			<?php
                                    			}
                                    			?>
                                    		</select>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Open Plot Area (Sqft)</label>
                                            <input type="text" class="form-control is-valid" name="open_plots" id="open_plots" autocomplete="off" placeholder="Enter Open Plots Area (Sqft)" value="<?php echo !empty($_POST['open_plots'])?$_POST['open_plots']: $prop[0]->open_plots ?>" />
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"> <h6 style="font-size: 12px;">Penality Under Section 138/2a for non submission of assessment form</h6></label>
                                            <input type="text" class="form-control is-valid" name="penality" id="penality" autocomplete="off" placeholder="Enter Penality Under Section 138/2a" value="<?php echo !empty($_POST['penality'])?$_POST['penality']: $prop[0]->penality ?>" />
                                        </div>
                                        
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6 col-md-12 col-sm-12">
                                            <img src="<?php echo $prop[0]->property_image ?>" style="width: 200px; height: 200px;">
                                        </div>
                                        <div class="col-lg-6 col-md-12 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Property Image</label>
                                            <input type="file" class="form-control is-valid" name="property_image" id="inputSuccess"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6 col-md-12 col-sm-12">
                                            <img src="<?php echo $prop[0]->tildImage ?>" style="width: 200px; height: 200px;">
                                        </div>
                                        <div class="col-lg-6 col-md-12 col-sm-12">
                                            <label class="col-form-label" for="tildImage"><i class="fas fa-check"></i> Tilt Image</label>
                                            <input type="file" class="form-control is-valid" name="tildImage" id="tildImage"/>
                                        </div>
                                    </div>
                                </div>
                                <!--Floors / Yrs of Construction / Last tax paid amount-->
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Yrs of Construction (FY)</label>
                                            <!--<input class="form-control" name="year_of_construction" id="year_of_construction" placeholder="Enter Construction Years" value="<?php echo !empty($_POST['year_of_construction']) ? $_POST['year_of_construction'] : $prop[0]->year_of_construction ?>" />-->
                                            <select name="year_of_construction" id="year_of_construction" class="form-control select2">
                                    			<?php
                                    			// Define the starting and ending years for the dropdown menu
                                    			$start_year = 1970;
                                    			$end_year = date('Y') + 1;
                                    
                                    			// Create a list of financial year options
                                    			$financial_years = array();
                                    			for ($year = $start_year; $year < $end_year; $year++) {
                                    				$financial_year = $year . '-' . ($year + 1);
                                    				$financial_years[] = $financial_year;
                                    			?>
                                    				<option <?php if($prop[0]->year_of_construction == $financial_year){ ?>selected <?php } ?>value="<?php echo $financial_year ?>"><?php echo $financial_year; ?></option>
                                    			<?php
                                    			}
                                    			?>
                                    		</select>
                                        </div>
                                        <div class="col-lg-3">
                                            <label class="col-form-label" for="inputSuccess">Create Floor Data</label><br/>
                                            <button type="button" id="add-btn" class="btn btn-primary form-control" onclick="addTextbox()"  style="width: 45px !important; height: 45px !important;"><i class="fa fa-plus"></i></button>
                                            </div>
                                    </div>
                                </div>
                                
                                <!--Household latitude / household longitude / Property Available in BMC Record-->
                                
                                
                                <!--Property Image-->
                                
                                <!--Year Of Last Tax Payment / Solid Waste Charges-->
                                <div class="form-group">
                                    
                                    <?php if($prop[0]->floor_SBA != NULL){ 
                                        $properties = json_decode($prop[0]->floor_SBA); 
                                        $totalFloor = json_decode($prop[0]->total_floors); 
                                        $floor_type = json_decode($prop[0]->floor_type); 
                                        $occup_type = json_decode($prop[0]->floor_wise_occup_type); 
                                        $floor_remarks = json_decode($prop[0]->floor_remarks);
                                        for($i = 0; $i < count($properties); $i++){ ?>
                                    <div class="form-group">
                                        <?php if(($prop[0]->floor_SBA != NULL) && ($prop[0]->floor_type != NULL) && ($prop[0]->floor_wise_occup_type != NULL) && ($prop[0]->total_floors != NULL) ){?>
                                        <div class="row">
                                            <div class="col-lg-3 col-md-6 col-sm-12">
                                                <label class="col-form-label" for="inputSuccess">Floors</label>
                                                <select class="form-control select2 is-valid" id="inputSuccess" name="total_floor[]">
                                                    <option <?php if($totalFloor[$i] == 0){ ?>selected<?php } ?> value="0">Basement</option>
                                                    <option <?php if($totalFloor[$i] == 1){ ?>selected<?php } ?> value="1">Ground Floor Only</option>
                                                    <option <?php if($totalFloor[$i] == 2){ ?>selected<?php } ?> value="2">G+1</option>
                                                    <option <?php if($totalFloor[$i] == 3){ ?>selected<?php } ?> value="3">G+2</option>
                                                    <option <?php if($totalFloor[$i] == 4){ ?>selected<?php } ?> value="4">G+3</option>
                                                    <option <?php if($totalFloor[$i] == 5){ ?>selected<?php } ?> value="5">G+4</option>
                                                    <option <?php if($totalFloor[$i] == 6){ ?>selected<?php } ?> value="6">G+5</option>
                                                </select>
                                            </div>
                                            <div class="col-lg-3 col-md-6 col-sm-12">
                                                <label class="col-form-label" for="inputSuccess">Floor Usage Type</label>
                                                <select class="form-control select2 is-valid" id="inputSuccess" name="floor_type[]">
                                                    <option <?php if($floor_type[$i] == 'residential'){ ?>selected<?php } ?> value="residential">Residential</option>
                                                    <option <?php if($floor_type[$i] == 'commercial'){ ?>selected<?php } ?> value="commercial">Commercial</option>
                                                </select>
                                            </div>
                                            <div class="col-lg-3 col-md-6 col-sm-12">
                                                <label class="col-form-label" for="inputSuccess">Floor SBA (Sqft)</label>
                                                <input type="text" class="form-control is-valid" name="floor_SBA[]" id="inputSuccess" value="<?php echo !empty($_POST['floor_SBA']) ? $_POST['floor_SBA'] : $properties[$i] ?>" />
                                            </div>
                                            <div class="col-lg-3 col-md-6 col-sm-12">
                                                <label class="col-form-label" for="inputSuccess">Occupant Type</label>
                                                <select class="form-control select2 is-valid" id="inputSuccess" name="occup_type[]">
                                                    <option <?php if($occup_type[$i] == 'self'){ ?>selected<?php } ?> value="self">Self</option>
                                                    <option <?php if($occup_type[$i] == 'otherThanSelf'){ ?>selected<?php } ?> value="otherThanSelf">Other Than Self</option>
                                                </select>
                                            </div>
                                        </div>
                                        
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12 col-sm-12">
                                                <label class="col-form-label" for="remarks">Remarks For Floor</label>
                                                <input type="text" class="form-control is-valid" name="floor_remarks[]" id="remarks" value="<?php echo !empty($_POST['floor_remarks']) ? $_POST['floor_remarks'] : $floor_remarks[$i] ?>" />
                                            </div>
                                        </div>
                                        <?php }} ?>
                                    </div>
                                    <?php } ?>
                                    <div class="form-group" id="containerFloor">
                                    
                                    </div>
                                    <!--Road Location Type / Floor / Floor Usage Type-->
                                
                                </div>
                                
                                <div class="card-footer">
                                    <?php if($prop[0]->ARI_audit_status == NULL || $prop[0]->ARO_audit_status == NULL || $prop[0]->ZC_audit_status == NULL){ ?>
                                        <input type="submit" class="btn btn-primary" name="userSubmit" value="Submit">
                                    <?php }else{ ?>
                                        <input type="button" class="btn btn-primary" name="userSubmit" value="Submit" onclick="alert('You cant edit as it is in zone commissioner approval pending status.');">
                                    <?php } ?>
                                    <a href="<?php echo site_url('Property/getData'); ?>" class="btn btn-secondary">Back</a>
                                </div>
                            </form>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!--/.col (right) -->
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<script>
		var count = 0;
        var total_floor = [];
        var floor_type = [];
        var floor_sba = [];
        var occup_type = [];
		function addTextbox() {
			// Create a new row div with class "row"
              var rowDiv = document.createElement("div");
              rowDiv.classList.add("row");
              
              var rowDiv1 = document.createElement("div");
              var colDivRemark = document.createElement("div");
              colDivRemark.classList.add("col-lg-12");
              colDivRemark.classList.add("col-md-12");
              colDivRemark.classList.add("col-sm-12");
            
              // Create a new label for the select box
              var labelRemark = document.createElement("label");
              labelRemark.innerHTML = "Remarks For Floor";
              colDivRemark.appendChild(labelRemark);
              
              rowDiv1.classList.add("row");
              var remarkBox = document.createElement('input');
              remarkBox.classList.add("form-control");
              remarkBox.classList.add("is-valid");
			  remarkBox.type = "text";
			  remarkBox.setAttribute('id', 'floor_remarks[]');
              remarkBox.setAttribute('name', 'floor_remarks[]');
		      colDivRemark.appendChild(remarkBox);
              var colDiv4 = document.createElement("div");
              colDiv4.classList.add("col-lg-3");
              colDiv4.classList.add("col-md-6");
              colDiv4.classList.add("col-sm-12");
              // Create a new label for the select box
              var label4 = document.createElement("label");
              label4.innerHTML = "Floors";
              colDiv4.appendChild(label4);
              // Add the select box to the column div
              var selectBox4 = document.createElement("select");
              selectBox4.classList.add("form-control");
              selectBox4.innerHTML = '<option value="0">Basement</option><option value="1">Ground Floor Only</option><option value="2">G+1</option><option value="3">G+2</option><option value="4">G+3</option><option value="5">G+4</option><option value="6">G+5</option>';
              selectBox4.setAttribute('id', 'total_floor[]');
              selectBox4.setAttribute('name', 'total_floor[]');
              colDiv4.appendChild(selectBox4);
              total_floor.push(selectBox4.id);
              total_floor.push(selectBox4.name);
              
              // Create a new column div with classes "col-lg-3 col-md-6 col-sm-12"
              var colDiv1 = document.createElement("div");
              colDiv1.classList.add("col-lg-3");
              colDiv1.classList.add("col-md-6");
              colDiv1.classList.add("col-sm-12");
            
              // Create a new label for the select box
              var label1 = document.createElement("label");
              label1.innerHTML = "Floor Usage Type";
              colDiv1.appendChild(label1);
              // Add the select box to the column div
              var selectBox1 = document.createElement("select");
              selectBox1.classList.add("form-control");
              selectBox1.innerHTML = '<option value="residential">Residential</option><option value="commercial">Commercial</option>';
              selectBox1.setAttribute('id', 'floor_type[]');
              selectBox1.setAttribute('name', 'floor_type[]');
              colDiv1.appendChild(selectBox1);
              
              var colDiv2 = document.createElement("div");
              colDiv2.classList.add("col-lg-3");
              colDiv2.classList.add("col-md-6");
              colDiv2.classList.add("col-sm-12");
              // Create a new label for the select box
              var label2 = document.createElement("label");
              label2.innerHTML = "Floor Area Sqft";
              colDiv2.appendChild(label2);
              // Add the select box to the column div
              var textbox = document.createElement("input");
              textbox.classList.add("form-control");
              textbox.classList.add("is-valid");
			  textbox.type = "text";
			  textbox.setAttribute('id', 'floor_SBA[]');
              textbox.setAttribute('name', 'floor_SBA[]');
		      colDiv2.appendChild(textbox);
              
              var colDiv3 = document.createElement("div");
              colDiv3.classList.add("col-lg-3");
              colDiv3.classList.add("col-md-6");
              colDiv3.classList.add("col-sm-12");
              // Create a new label for the select box
              var label3 = document.createElement("label");
              label3.innerHTML = "Occupant Type";
              colDiv3.appendChild(label3);
              // Add the select box to the column div
              var selectBox3 = document.createElement("select");
              selectBox3.classList.add("form-control");
              selectBox3.innerHTML = '<option value="self">Self</option><option value="otherThanSelf">Other Than Self</option>';
              selectBox3.setAttribute('id', 'occup_type[]');
              selectBox3.setAttribute('name', 'occup_type[]');
              colDiv3.appendChild(selectBox3);
              
              
              // Add the column div to the row div
              rowDiv.appendChild(colDiv4);
              rowDiv.appendChild(colDiv1);
              rowDiv.appendChild(colDiv2);
              rowDiv.appendChild(colDiv3);
              rowDiv1.appendChild(colDivRemark);
              // Add the row div to the container div
              var containerDiv = document.getElementById("containerFloor");
              containerDiv.appendChild(rowDiv);
              containerDiv.appendChild(rowDiv1);
              // Assign ID and name attributes to the column div
              var numCols = containerDiv.querySelectorAll(".col-lg-3").length;
              colDiv1.setAttribute("id", "col-" + numCols);
              colDiv1.setAttribute("name", "col-" + numCols);
              colDiv2.setAttribute("id", "col-" + numCols);
              colDiv2.setAttribute("name", "col-" + numCols);
              colDiv3.setAttribute("id", "col-" + numCols);
              colDiv3.setAttribute("name", "col-" + numCols);
              colDiv4.setAttribute("id", "col-" + numCols);
              colDiv4.setAttribute("name", "col-" + numCols);
              count++;
		}
	</script>
<script>
    
</script>

<!--Google Map Development Show-->
<script src="https://maps.googleapis.com/maps/api/js"></script>
<script>
    function initMap() {
	var myLatLng = {lat: <?php echo $prop[0]->latitude; ?>, lng: <?php echo $prop[0]->longitude; ?>};

	var map = new google.maps.Map(document.getElementById('map'), {
		zoom: 17.5,
		center: myLatLng
	});

	var marker = new google.maps.Marker({
		position: myLatLng,
		map: map,
		title: 'Coordinates'
	});
}

window.onload = function() {
	initMap();
};
</script>
<!--End Google Map-->

<script async defer src="https://maps.googleapis.com/maps/api/js?callback=initMap">

</script>
<link rel="stylesheet" href="https://openlayers.org/en/v6.5.0/css/ol.css" type="text/css">
<script src="https://openlayers.org/en/v6.5.0/build/ol.js"></script>
<script src="https://maps.googleapis.com/maps/api/js"></script>
<style>
    #map {
        height: 500px;
        width: 100%;
    }
</style>
<script>
    // var lat = "<?php echo $prop[0]->latitude ?>";
    // var long = "<?php echo $prop[0]->longitude ?>";
    //   var map = new ol.Map({
    //     target: 'map',
    //     layers: [
    //       new ol.layer.Tile({
    //         source: new ol.source.OSM()
    //       })
    //     ],
    //     view: new ol.View({
    //       center: ol.proj.fromLonLat([long, lat]),
    //       zoom: 17.5
    //     })
    //   });
      
    //   // Create a marker at a specific location
    //   var marker = new ol.Feature({
    //     geometry: new ol.geom.Point(ol.proj.fromLonLat([long, lat]))
    //   });
    //   var markerStyle = new ol.style.Style({
    //     image: new ol.style.Icon({
    //       anchor: [0.5, 1],
    //       src: 'https://openlayers.org/en/v6.5.0/examples/data/icon.png'
    //     })
    //   });
    //   marker.setStyle(markerStyle);
      
    //   // Add the marker to a vector layer
    //   var vectorLayer = new ol.layer.Vector({
    //     source: new ol.source.Vector({
    //       features: [marker]
    //     })
    //   });
    //   map.addLayer(vectorLayer);
    </script>