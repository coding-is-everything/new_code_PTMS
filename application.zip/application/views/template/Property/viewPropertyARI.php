<link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" integrity="sha384-....">
  <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js" integrity="sha384-...."></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/togeojson/0.15.0/togeojson.min.js"></script>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>View Property</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active"><a href="<?php echo site_url() ?>Property/getData"><i class="fas fa-folder">&nbsp;Manage Properties</i></a></li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <!-- right column -->
                <div class="col-md-12">
                    <!-- Form Element sizes -->
                    <!-- general form elements disabled -->
                    <div class="card card-warning">
                        <div class="card-header">
                            <h3 class="card-title">View Property</h3>
                        </div>
                        <!-- /.card-header -->
                        <!-- Display status message -->
                        <?php if (!empty($success_msg)) { ?>
                            <div class="col-xs-12">
                                <div class="alert alert-success"><?php echo $success_msg; ?></div>
                            </div>
                        <?php } elseif (!empty($error_msg)) { ?>
                            <div class="col-xs-12">
                                <div class="alert alert-danger"><?php echo $error_msg; ?></div>
                            </div>
                        <?php } ?>
                        <div class="card-body">
                            <form method="post" action="<?php echo site_url() ?>Property/addEntry"  enctype='multipart/form-data'>
                                <!--<div class="form-group">-->
                                <!--    <div class="row">-->
                                <!--        <div id="mapid"></div>-->
                                <!--    </div>-->
                                <!--</div>-->
                                <!--<div class="form-group">-->
                                <!--    <div class="row">-->
                                <!--        <div class="col-lg-12 col-md-12 col-sm-12">-->
                                <!--            <button type="button" id="getGPSCoordinates" class="btn btn-primary"><i class='fa fa-map-marker'></i> GET LOCATION</button>-->
                                        
                                <!--            <button type="button" id="lockGPSCoordinates" class="btn btn-primary"><i class='fa fa-solid fa-lock'></i> GPS LOCK</button>-->
                                            <!--<input type="button" id="lockGPSCoordinates" class="btn btn-success" value="Lock GPS"/>-->
                                <!--        </div>-->
                                <!--    </div>-->
                                <!--</div>-->
                                <!--<div class="form-group">-->
                                <!--    <div class="row">-->
                                <!--        <div class="col-lg-4 col-md-6 col-sm-12">-->
                                <!--            <label class="col-form-label" for="latitudeCurrent"><i class="fas fa-check"></i>Current Latitude:</label>-->
                                <!--            <input type="text" class="form-control is-valid" id="latitudeCurrent" readonly value="22.XXXXXX">-->
                                <!--        </div>-->
                                <!--        <div class="col-lg-4 col-md-6 col-sm-12">-->
                                <!--            <label class="col-form-label" for="longitudeCurrent"><i class="fas fa-check"></i>Current Longitude:</label>-->
                                <!--            <input type="text" class="form-control is-valid" id="longitudeCurrent" readonly value="82.XXXXXX">-->
                                <!--        </div>-->
                                <!--        <div class="col-lg-4 col-md-6 col-sm-12">-->
                                <!--            <label class="col-form-label" for="accuracyCurrent"><i class="fas fa-check"></i>Current accuracy:</label>-->
                                <!--            <input type="text" class="form-control is-valid" id="accuracyCurrent" readonly value="">-->
                                <!--        </div>-->
                                <!--    </div>-->
                                <!--</div>-->
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-4 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Household latitude</label>
                                            <input type="text" class="form-control is-valid" name="latitude" readonly id="latitude" autocomplete="off" placeholder="Enter Household latitude" value="<?php echo $property[0]->latitude; ?>">
                                            <label style="display: none;" id="centerLat"></label>
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> household longitude</label>
                                            <input type="text" class="form-control is-valid" name="longitude" readonly id="longitude" autocomplete="off" placeholder="Enter Household latitude" value="<?php echo $property[0]->longitude; ?>">
                                            <label style="display:none;" id="centerLng"></label>
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Property Available in BMC Record</label>
                                            <select class="form-control select2" style="width: 100%;" name="is_property_available_in_bmc_record" id="inputSuccess">
                                                <option value="">Select Property Available in BMC</option>
                                                <option <?php if($property[0]->is_property_available_in_bmc_record == 'Yes'){ ?>selected<?php } ?> value="Yes">Yes</option>
                                                <option <?php if($property[0]->is_property_available_in_bmc_record == 'No'){ ?>selected<?php } ?> value="No">No</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-4 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> New Property Number</label>
                                            <input type="text" class="form-control is-valid" name="new_pro_no" id="new_pro_no" readonly autocomplete="off" placeholder="Enter Property Id" value="<?php echo !empty($_POST['new_pro_no']) ? $_POST['new_pro_no'] : $property[0]->new_pro_no; ?>">
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Owner Name</label>
                                            <input type="text" class="form-control is-valid" name="owner_name" id="inputSuccess" autocomplete="off" placeholder="Enter Owner Name" value="<?php echo !empty($_POST['prop_owner']) ? $_POST['prop_owner'] : $property[0]->owner_name; ?>">
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Gender</label>
                                            <select class="form-control select2" style="width: 100%;" name="gender" required id="inputSuccess">
                                                <option value="">Select Gender</option>
                                                <option <?php if($property[0]->gender == "MALE"){ ?>selected<?php } ?> value="MALE">Male</option>
                                                <option <?php if($property[0]->gender == "FEMALE"){ ?>selected<?php } ?> value="FEMALE">Female</option>
                                                <option <?php if($property[0]->gender == "OTHER"){ ?>selected<?php } ?> value="OTHER">Other</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <!-- Mobile/Guardian/Occupant Type -->
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-4 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Mobile Number</label>
                                            <input type="text" class="form-control is-valid" name="mobile" id="inputSuccess" autocomplete="off" placeholder="Enter Mobile Number" value="<?php echo !empty($_POST['ph_mob_no']) ? $_POST['ph_mob_no'] : $property[0]->mobile; ?>">
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Guardian Name</label>
                                            <input type="text" class="form-control is-valid" name="guardian_name" id="inputSuccess" autocomplete="off" placeholder="Enter Guardian Name" value="<?php echo !empty($_POST['fathr_name']) ? $_POST['fathr_name'] : $property[0]->guardian_name; ?>">
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Road Location Type</label>
                                            <select class="form-control select2" style="width: 100%;" name="road_type" id="inputSuccess">
                                                <option value="">Select Road Location Type</option>
                                                <option <?php if($property[0]->road_type == 'mainRoad'){ ?>selected<?php } ?> value="mainRoad">Main Road</option>
                                                <option <?php if($property[0]->road_type == 'internalRoad'){ ?>selected<?php } ?> value="internalRoad">Internal Road</option>
                                            </select>
                                        </div>
                                        
                                    </div>
                                </div>
                                <!--Colony / Address-->
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-4 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Colony</label>
                                            <input type="text" class="form-control is-valid" name="colony" id="inputSuccess" autocomplete="off" placeholder="Enter Colony" value="<?php echo !empty($_POST['moh_colony']) ? $_POST['moh_colony'] : $property[0]->colony; ?>">
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Address</label>
                                            <input type="text" class="form-control is-valid" name="address" id="inputSuccess" autocomplete="off" placeholder="Enter Address" value="<?php echo !empty($_POST['stret_name']) ? $_POST['stret_name'] : $property[0]->address; ?>">
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> DDN</label>
                                            <input type="text" class="form-control is-valid" name="DDN" id="inputSuccess" autocomplete="off" placeholder="Enter DDN" readonly value="<?php echo !empty($_POST['DDN']) ? $_POST['DDN'] : $property[0]->DDN ?>" />
                                        </div>
                                    </div>
                                </div>
                                <!--PinCode / Property Usage / Property Type-->
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-4 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Pin Code</label>
                                            <input type="text" class="form-control is-valid" name="pin_code" id="inputSuccess" autocomplete="off" placeholder="Enter PinCode" value="<?php echo !empty($_POST['pin_code']) ? $_POST['pin_code'] : $property[0]->pin_code; ?>">
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Parikshetra (number)</label>
                                            <input type="text" class="form-control is-valid" name="parikshetra_number" id="inputSuccess" autocomplete="off" placeholder="Enter Parikshetra (number)" value="<?php echo !empty($_POST['parikshetra_no']) ? $_POST['parikshetra_no'] : $property[0]->parikshetra_number; ?>">
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Construction type</label>
                                            <select class="form-control select2" style="width: 100%;" name="const_type" required id="inputSuccess">
                                                <option value="">Select Construction type</option>
                                                <option <?php if($property[0]->const_type == "PUCCA"){ ?>selected<?php } ?> value="PUCCA">PUCCA</option>
                                                <option <?php if($property[0]->const_type == "KUCCHA"){ ?>selected<?php } ?> value="KUCCHA">KUCCHA</option>
                                                <option <?php if($property[0]->const_type == "ARD PUCCA"){ ?>selected<?php } ?> value="ARD PUCCA">ARD PUCCA</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                
                                <!--Parikshetra (number)/Construction type/Area of GIS as per Drone-->
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Area of Plot / Parcel As per GIS Survey</label>
                                            <input type="text" name="area_of_plot_as_per_gis" id="area_of_plot_as_per_gis" readonly placeholder="Enter Area Of GIS" value="<?php echo !empty($_POST['area_of_plot_as_per_gis']) ? $_POST['area_of_plot_as_per_gis'] : $property[0]->area_of_plot_as_per_gis ?>" class="form-control" />
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Area of Building Footprint as Per GIS Survey</label>
                                            <input type="text" name="area_of_building_footprint_as_per_gis" placeholder="Enter Building Footprint" readonly value="<?php echo !empty($_POST['area_of_building_footprint_as_per_gis']) ? $_POST['area_of_building_footprint_as_per_gis'] : $property[0]->area_of_building_footprint_as_per_gis ?>" class="form-control" />
                                        </div>
                                    </div>
                                </div>
                                <!--total floor / Yrs of Construction / Last tax paid amount-->
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Yrs of Construction</label>
                                            <!--<input class="form-control" name="year_of_construction" id="year_of_construction" required placeholder="Enter Construction Years" value="<?php echo !empty($_POST['year_of_construction']) ? $_POST['year_of_construction'] : '' ?>" />-->
                                            <select name="year_of_construction" id="year_of_construction" class="form-control select2">
                                    			<?php
                                    			// Define the starting and ending years for the dropdown menu
                                    			$start_year = 1970;
                                    			$end_year = date('Y') + 1;
                                    
                                    			// Create a list of financial year options
                                    			$financial_years = array();
                                    			for ($year = $start_year; $year < $end_year; $year++) {
                                    				$financial_year = $year . '-' . ($year + 1);
                                    				$financial_years[] = $financial_year;
                                    			?>
                                    				<option <?php if($property[0]->year_of_construction == $financial_year){ ?>selected<?php } ?> value="<?php echo $financial_year ?>"><?php echo $financial_year; ?></option>
                                    			<?php
                                    			}
                                    			?>
                                    		</select>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Last tax paid amount</label>
                                            <input class="form-control" name="last_tax_pay_amount" id="last_tax_pay_amount" placeholder="Enter Last Tax Paid Amount" value="<?php echo !empty($_POST['last_tax_pay_amount']) ? $_POST['last_tax_pay_amount'] : $property[0]->last_tax_pay_amount ?>" />
                                        </div>
                                    </div>
                                </div>
                                
                                <!--Household latitude / household longitude / Property Available in BMC Record-->
                                
                                <!--Road Location Type / Floor / Floor Usage Type-->
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Open Plot Area (Sqft)</label>
                                            <input type="text" class="form-control is-valid" name="open_plots" id="open_plots" autocomplete="off" placeholder="Enter Open Plots Area (Sqft)" value="<?php echo !empty($_POST['open_plots'])?$_POST['open_plots']: $property[0]->open_plots ?>" />
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"> <h6 style="font-size: 12px;">Penality Under Section 138/2a for non submission of assessment form</h6></label>
                                            <input type="text" class="form-control is-valid" name="penality" id="penality" autocomplete="off" placeholder="Enter Penality Under Section 138/2a" value="<?php echo !empty($_POST['penality'])?$_POST['penality']: $property[0]->penality ?>" />
                                        </div>
                                        <!--<div class="col-lg-4 col-md-6 col-sm-12">-->
                                        <!--    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Zone Name</label>-->
                                        <!--    <select class="form-control select2" style="width:100%;" name="zone_no" required id="inputSuccess">-->
                                        <!--        <option selected>Select Zone</option>-->
                                        <!--        <?php foreach($zoneData as $zd){ ?>-->
                                        <!--            <option value="<?php echo $zd->id ?>"><?php echo $zd->zoneName ?></option>-->
                                        <!--        <?php } ?>-->
                                        <!--    </select>-->
                                        <!--</div>-->
                                    </div>
                                </div>
                                <!--Property Image-->
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6 col-md-12 col-sm-12">
                                            <img src="<?php echo $property[0]->property_image ?>" style="width: 200px; height: 200px;">
                                        </div>
                                        <div class="col-lg-6 col-md-12 col-sm-12">
                                            <img src="<?php echo $property[0]->tildImage ?>" style="width: 200px; height: 200px;">
                                        </div>
                                        <!--<div class="col-lg-6 col-md-12 col-sm-12">-->
                                        <!--    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Property Image</label>-->
                                        <!--    <input type="file" class="form-control is-valid" name="property_image" required id="inputSuccess"/>-->
                                        <!--</div>-->
                                    </div>
                                </div>
                                <!--Year Of Last Tax Payment / Solid Waste Charges-->
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-4 col-md-6 col-sm-12">
                                            <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Year Of Last Tax Payment</label>
                                            <!--<input type="text" class="form-control is-valid" name="year_of_last_tax_paid" required id="inputSuccess" autocomplete="off" placeholder="Enter Year Of Last Tax Payment" value="<?php echo !empty($_POST['year_of_last_tax_paid']) ? $_POST['year_of_last_tax_paid'] : ''; ?>">-->
                                            <select name="year_of_last_tax_paid" id="year_of_last_tax_paid" class="form-control select2">
                                    			<?php
                                    			// Define the starting and ending years for the dropdown menu
                                    			$start_year = 1970;
                                    			$end_year = date('Y') + 1;
                                    
                                    			// Create a list of financial year options
                                    			$financial_years = array();
                                    			for ($year = $start_year; $year < $end_year; $year++) {
                                    				$financial_year = $year . '-' . ($year + 1);
                                    				$financial_years[] = $financial_year;
                                    			?>
                                    				<option <?php if($property[0]->year_of_last_tax_paid == $financial_year){ ?>selected<?php } ?> value="<?php echo $financial_year ?>"><?php echo $financial_year; ?></option>
                                    			<?php
                                    			}
                                    			?>
                                    		</select>
                                        </div>
                                        
                                        <!--<div class="col-lg-4 col-md-6 col-sm-12">-->
                                        <!--    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Ward Name</label>-->
                                        <!--    <select class="form-control select2" style="width: 100%;" name="ward_no" required id="inputSuccess">-->
                                        <!--        <option selected>Select Ward</option>-->
                                        <!--        <?php foreach($wardData as $wd){ ?>-->
                                        <!--            <option value="<?php echo $wd->id; ?>"><?php echo $wd->wardName ?>( <?php echo $wd->wardId ?> )</option>-->
                                        <!--        <?php } ?>-->
                                        <!--    </select>-->
                                        <!--</div> -->
                                        <div class="col-lg-3">
                                            <label class="col-form-label" for="inputSuccess">Create Floor Data</label><br/>
                                            <button type="button" id="add-btn" class="btn btn-primary form-control" onclick="addTextbox()"  style="width: 45px !important; height: 45px !important;"><i class="fa fa-plus"></i></button>
                                            </div>
                                    </div>
                                </div>
                                <?php if($property[0]->floor_SBA != NULL){ 
                                        $properties = json_decode($property[0]->floor_SBA); 
                                        $totalFloor = json_decode($property[0]->total_floors); 
                                        $floor_type = json_decode($property[0]->floor_type); 
                                        $occup_type = json_decode($property[0]->floor_wise_occup_type); 
                                        for($i = 0; $i < count($properties); $i++){ ?>
                                    <div class="form-group">
                                        <?php if(($property[0]->floor_SBA != NULL) && ($property[0]->floor_type != NULL) && ($property[0]->floor_wise_occup_type != NULL) && ($property[0]->total_floors != NULL) ){?>
                                        <div class="row">
                                            <div class="col-lg-3 col-md-6 col-sm-12">
                                                <label class="col-form-label" for="inputSuccess">Floors</label>
                                                <select class="form-control select2 is-valid" id="inputSuccess" name="total_floor[]">
                                                    <option <?php if($totalFloor[$i] == 0){ ?>selected<?php } ?> value="0">Basement</option>
                                                    <option <?php if($totalFloor[$i] == 1){ ?>selected<?php } ?> value="1">Ground Floor Only</option>
                                                    <option <?php if($totalFloor[$i] == 2){ ?>selected<?php } ?> value="2">G+1</option>
                                                    <option <?php if($totalFloor[$i] == 3){ ?>selected<?php } ?> value="3">G+2</option>
                                                    <option <?php if($totalFloor[$i] == 4){ ?>selected<?php } ?> value="4">G+3</option>
                                                    <option <?php if($totalFloor[$i] == 5){ ?>selected<?php } ?> value="5">G+4</option>
                                                    <option <?php if($totalFloor[$i] == 6){ ?>selected<?php } ?> value="6">G+5</option>
                                                </select>
                                            </div>
                                            <div class="col-lg-3 col-md-6 col-sm-12">
                                                <label class="col-form-label" for="inputSuccess">Floor Usage Type</label>
                                                <select class="form-control select2 is-valid" id="inputSuccess" name="floor_type[]">
                                                    <option <?php if($floor_type[$i] == 'residential'){ ?>selected<?php } ?> value="residential">Residential</option>
                                                    <option <?php if($floor_type[$i] == 'commercial'){ ?>selected<?php } ?> value="commercial">Commercial</option>
                                                </select>
                                            </div>
                                            <div class="col-lg-3 col-md-6 col-sm-12">
                                                <label class="col-form-label" for="inputSuccess">Floor SBA (Sqft)</label>
                                                <input type="text" class="form-control is-valid" name="floor_SBA[]" id="inputSuccess" value="<?php echo !empty($_POST['floor_SBA']) ? $_POST['floor_SBA'] : $properties[$i] ?>" />
                                            </div>
                                            <div class="col-lg-3 col-md-6 col-sm-12">
                                                <label class="col-form-label" for="inputSuccess">Occupant Type</label>
                                                <select class="form-control select2 is-valid" id="inputSuccess" name="occup_type[]">
                                                    <option <?php if($occup_type[$i] == 'self'){ ?>selected<?php } ?> value="self">Self</option>
                                                    <option <?php if($occup_type[$i] == 'otherThanSelf'){ ?>selected<?php } ?> value="otherThanSelf">Other Than Self</option>
                                                </select>
                                            </div>
                                        </div>
                                    <?php }} ?>
                                    </div>
                                    <?php } ?>
                                    <div class="form-group" id="containerFloor">
                                    
                                    </div>
                                </div>
                                
                                <div class="card-footer">
                                    <?php $url = site_url('Property/getData'); ?>
                                    <input type="button" class="btn btn-primary" onclick="if(confirm('Property Data Submitted Successfully.')) { window.location.href = '<?php echo $url; ?>' }" name="userSubmit" value="Submit">
                                    <a href="<?php echo site_url('Property/getData'); ?>" class="btn btn-secondary">Back</a>
                                </div>
                            </form>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!--/.col (right) -->
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<style>
    #mapid {
        height: 400px;
        width: 100%;
    }
</style>
<script>
    // Generate a random 6-digit number
    // Generate a random 6-digit number
    var randomNumber = Math.floor(Math.random() * 900000) + 100000;
    
    // Get the current date in the format "YYYYMMDD"
    var currentDate = new Date().toISOString().slice(0,10).replace(/-/g,"");
    
    // Construct the new property ID
    var newPropertyID = "BSCL000003000" + currentDate + randomNumber;
    // alert(newPropertyID);
    document.getElementById('new_pro_no').value = newPropertyID; // Outputs something like "BSCL00000320230508123456"



    var wardId = '<?php echo $this->Ward_model->getWardDetail($this->Ward_model->getUserDetailsBasedOnUserId($this->session->userdata("userId"))['ARIWardNo'])[0]->ward_kml ?>';
    // alert(wardId);
    var map = L.map('mapid');
    var marker = null; // initialize marker variable

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: 'Map data © <a href="https://openstreetmap.org">OpenStreetMap</a> contributors',
      maxZoom: 18,
    }).addTo(map);
    
// This code shou
    var url = "https://propertytax.digicardmaker.co.in/ward_kml/ward_"+wardId+".kml";
    // alert(url);
    $.get(url, function(data) {
      var geojson = toGeoJSON.kml(data);
      var selectedLayer = null;
      L.geoJSON(geojson, {
        style: {
          color: "red"
        },
        onEachFeature: function(feature, layer) {
          layer.on('click', function() {
            if (layer instanceof L.Polygon) {
              if (selectedLayer === layer) {
                // Remove the marker and reset the layer style
                map.removeLayer(marker);
                layer.setStyle({
                  color: "red"
                });
                selectedLayer = null;
              } else {
                // Add a marker and change the layer style to green
                var bounds = layer.getBounds();
                var latlng = bounds.getCenter();
                // alert(latlng);
                document.getElementById('centerLat').innerHTML = latlng.lat;
                document.getElementById('centerLng').innerHTML = latlng.lng;
                var currentLatlng = null;
                // Get current location
                if ("geolocation" in navigator) {
                  navigator.geolocation.getCurrentPosition(function(position) {
                    currentLatlng = L.latLng(position.coords.latitude, position.coords.longitude);
                    var distance = currentLatlng.distanceTo(latlng);
                    // alert(distance/10);
                    if (distance/10 <= 5) {
                      // Display green marker and set layer style to green
                      if (selectedLayer !== null) {
                        // Deselect previously selected layer
                        map.removeLayer(marker);
                        selectedLayer.setStyle({
                          color: "red"
                        });
                      }
                      var icon = L.icon({
                        iconUrl: 'https://cdn.rawgit.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-green.png',
                        iconSize: [25, 41],
                        iconAnchor: [12, 41]
                      });
                      marker = L.marker(latlng, {
                        icon: icon
                      }).addTo(map);
                      layer.setStyle({
                        color: "green"
                      });
                      selectedLayer = layer;
                    } else {
                      // Display error message if distance is more than 5 meters
                      alert("You are too far away from this location!");
                    }
                  });
                } else {
                  alert("Geolocation is not supported by this browser.");
                }
              }
            }
          });
        }
      }).addTo(map);
    });
    
        if ("geolocation" in navigator) {
            setInterval(function(){
              navigator.geolocation.getCurrentPosition(function(position) {
                var latlng = L.latLng(position.coords.latitude, position.coords.longitude);
                // var marker;
                // alert(latlng);
                var icon = L.icon({
                  iconUrl: 'https://cdn.rawgit.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-blue.png',
                  iconSize: [25, 41],
                  iconAnchor: [12, 41]
                });
                map.setView(latlng, 17.5);
                if(!marker){
                    console.log('If Cond '+latlng);
                marker = L.marker(latlng, {
                  icon: icon
                }).addTo(map);
                }else{
                    console.log('else Cond '+latlng);
                    marker.setLatLng(latlng);
                }
              });
            }, 500);
    }

  </script>
<script>
		var count = 0;
        var total_floor = [];
        var floor_type = [];
        var floor_sba = [];
        var occup_type = [];
		function addTextbox() {
			// Create a new row div with class "row"
              var rowDiv = document.createElement("div");
              rowDiv.classList.add("row");
              
              var colDiv4 = document.createElement("div");
              colDiv4.classList.add("col-lg-3");
              colDiv4.classList.add("col-md-6");
              colDiv4.classList.add("col-sm-12");
              // Create a new label for the select box
              var label4 = document.createElement("label");
              label4.innerHTML = "Floor";
              colDiv4.appendChild(label4);
              // Add the select box to the column div
              var selectBox4 = document.createElement("select");
              selectBox4.classList.add("form-control");
              selectBox4.innerHTML = '<option value="0">Basement</option><option value="1">Ground Floor Only</option><option value="2">G+1</option><option value="3">G+2</option><option value="4">G+3</option><option value="5">G+4</option><option value="6">G+5</option>';
              selectBox4.setAttribute('id', 'total_floor[]');
              selectBox4.setAttribute('name', 'total_floor[]');
              colDiv4.appendChild(selectBox4);
              total_floor.push(selectBox4.id);
              total_floor.push(selectBox4.name);
              
              // Create a new column div with classes "col-lg-3 col-md-6 col-sm-12"
              var colDiv1 = document.createElement("div");
              colDiv1.classList.add("col-lg-3");
              colDiv1.classList.add("col-md-6");
              colDiv1.classList.add("col-sm-12");
            
              // Create a new label for the select box
              var label1 = document.createElement("label");
              label1.innerHTML = "Floor Usage Type";
              colDiv1.appendChild(label1);
              // Add the select box to the column div
              var selectBox1 = document.createElement("select");
              selectBox1.classList.add("form-control");
              selectBox1.innerHTML = '<option value="residential">Residential</option><option value="commercial">Commercial</option>';
              selectBox1.setAttribute('id', 'floor_type[]');
              selectBox1.setAttribute('name', 'floor_type[]');
              colDiv1.appendChild(selectBox1);
              
              var colDiv2 = document.createElement("div");
              colDiv2.classList.add("col-lg-3");
              colDiv2.classList.add("col-md-6");
              colDiv2.classList.add("col-sm-12");
              // Create a new label for the select box
              var label2 = document.createElement("label");
              label2.innerHTML = "Floor Area Sqft";
              colDiv2.appendChild(label2);
              // Add the select box to the column div
              var textbox = document.createElement("input");
              textbox.classList.add("form-control");
              textbox.classList.add("is-valid");
			  textbox.type = "text";
			  textbox.setAttribute('id', 'floor_SBA[]');
              textbox.setAttribute('name', 'floor_SBA[]');
		      colDiv2.appendChild(textbox);
              
              var colDiv3 = document.createElement("div");
              colDiv3.classList.add("col-lg-3");
              colDiv3.classList.add("col-md-6");
              colDiv3.classList.add("col-sm-12");
              // Create a new label for the select box
              var label3 = document.createElement("label");
              label3.innerHTML = "Occupant Type";
              colDiv3.appendChild(label3);
              // Add the select box to the column div
              var selectBox3 = document.createElement("select");
              selectBox3.classList.add("form-control");
              selectBox3.innerHTML = '<option value="self">Self</option><option value="otherThanSelf">Other Than Self</option>';
              selectBox3.setAttribute('id', 'occup_type[]');
              selectBox3.setAttribute('name', 'occup_type[]');
              colDiv3.appendChild(selectBox3);
              
              
              // Add the column div to the row div
              rowDiv.appendChild(colDiv4);
              rowDiv.appendChild(colDiv1);
              rowDiv.appendChild(colDiv2);
              rowDiv.appendChild(colDiv3);
            
              // Add the row div to the container div
              var containerDiv = document.getElementById("containerFloor");
              containerDiv.appendChild(rowDiv);
            
              // Assign ID and name attributes to the column div
              var numCols = containerDiv.querySelectorAll(".col-lg-3").length;
              colDiv1.setAttribute("id", "col-" + numCols);
              colDiv1.setAttribute("name", "col-" + numCols);
              colDiv2.setAttribute("id", "col-" + numCols);
              colDiv2.setAttribute("name", "col-" + numCols);
              colDiv3.setAttribute("id", "col-" + numCols);
              colDiv3.setAttribute("name", "col-" + numCols);
              colDiv4.setAttribute("id", "col-" + numCols);
              colDiv4.setAttribute("name", "col-" + numCols);
              count++;
		}
	</script>
<script>
    
</script>
<script async defer src="https://maps.googleapis.com/maps/api/js?callback=initMap">

</script>
<script src="https://maps.googleapis.com/maps/api/js"></script>
<script>
    function initMap() {
        var lat = 0;
        var long = 0;
        if ("geolocation" in navigator) {
            navigator.geolocation.getCurrentPosition(function(position) {
                lat = position.coords.latitude;
                long = position.coords.longitude;
            });
        } else {
            alert("Geolocation is not supported by this browser.");
        }
	var myLatLng = {lat: lat, lng: long};

	var map = new google.maps.Map(document.getElementById('map'), {
		zoom: 8,
		center: myLatLng
	});

	var marker = new google.maps.Marker({
		position: myLatLng,
		map: map,
		title: 'Coordinates'
	});
}

window.onload = function() {
	initMap();
};
</script>
<script>
        // Get the button and text input elements
        const getLocationBtn = document.getElementById("getGPSCoordinates");
        const latitudeInput = document.getElementById("latitudeCurrent");
        const longitudeInput = document.getElementById("longitudeCurrent");
        const accuracyInput = document.getElementById("accuracyCurrent");
        
        // Add a click event listener to the button
        getLocationBtn.addEventListener("click", () => {
          // Check if the browser supports Geolocation
          if (navigator.geolocation) {
            // Get the current position
            setInterval(function(){
            navigator.geolocation.getCurrentPosition(
              (position) => {
                // Get the latitude, longitude, and accuracy from the position object
                const latitude = position.coords.latitude;
                const longitude = position.coords.longitude;
                const accuracy = position.coords.accuracy;
        
                // Display the latitude, longitude, and accuracy in the text input elements
                latitudeInput.value = latitude;
                longitudeInput.value = longitude;
                accuracyInput.value = accuracy;
              },
              (error) => {
                // Handle any errors
                console.error(error);
              }
            );
            }, 500);
          } else {
            // Geolocation is not supported by the browser
            console.error("Geolocation is not supported by this browser.");
          }
        });
        if ("geolocation" in navigator) {
            setInterval(function(){
                navigator.geolocation.getCurrentPosition(function(position) {
                    // document.getElementById("latitude").value = position.coords.latitude;
                    // document.getElementById("longitude").value = position.coords.longitude;
                    // document.getElementById("latitudeCurrent").value = position.coords.latitude;
                    // document.getElementById("longitudeCurrent").value = position.coords.longitude;
                    // document.getElementById("accuracyCurrent").value = Math.round(position.coords.accuracy, 6);
                });
            }, 500);
        } else {
            alert("Geolocation is not supported by this browser.");
        }
        
        // Get a reference to the lock GPS button
        const lockGPSButton = document.getElementById('lockGPSCoordinates');
        
        // Get references to the latitude and longitude input boxes
        const latitudeInput1 = document.getElementById('latitude');
        const longitudeInput1 = document.getElementById('longitude');
        
        // Get references to the latitude and longitude label boxes
        const latitudeLabel = document.getElementById('centerLat');
        const longitudeLabel = document.getElementById('centerLng');
        
        // Add a click event listener to the lock GPS button
        lockGPSButton.addEventListener('click', function() {
          // Get the latitude and longitude values from the label boxes
          const latitudeValue = latitudeLabel.innerHTML;
          const longitudeValue = longitudeLabel.innerHTML;
         if(latitudeValue != "" && longitudeValue != ""){
          // Set the latitude and longitude input values to the label values
          latitudeInput1.value = latitudeValue;
          longitudeInput1.value = longitudeValue;
         }else{
             alert("Please select any property.");
         }
        });

    </script>

<script type="text/javascript">
    function ShowHideDiv(chkPassport) {
        var dvPassport = document.getElementById("dvPassport");
        dvPassport.style.display = chkPassport.checked ? "block" : "none";
    }
</script>
<script type="text/javascript">
    document.getElementById('name').value = "<?php echo $_POST['roleType']; ?>";
    document.getElementById('name1').value = "<?php echo $_POST['incecntivePer']; ?>";
    document.getElementById('name2').value = "<?php echo $_POST['teamLeadName']; ?>";
</script>
