<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Add Comment</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <!--<li class="breadcrumb-item active"><a href="<?php echo site_url() ?>Batch/batch_tab"><i class="fas fa-folder">&nbsp;Manage Batch</i></a></li>-->
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- right column -->
          <div class="col-md-12">
            <!-- Form Element sizes -->
                   <!-- general form elements disabled -->
            <div class="card card-warning">
              <div class="card-header">
                <h3 class="card-title">Add Comment</h3>
              </div>
              <!-- /.card-header -->
                          <!-- Display status message -->
    <?php if(!empty($success_msg)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-success"><?php echo $success_msg; ?></div>
    </div>
    <?php }elseif(!empty($error_msg)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-danger"><?php echo $error_msg; ?></div>
    </div>
    <?php } ?>
              <div class="card-body">
                <form method="post" action="<?php echo site_url() ?>Batch/addCommentFunction/<?php echo $id ?>/<?php echo $batchId ?>">
                  <!-- input states -->
                  <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Payment Remarks</label>
                    <textarea class="form-control is-valid" name="paymentRemarks" id="paymentRemarks" autocomplete="on"><?php echo !empty($_POST['paymentRemarks'])?$_POST['paymentRemarks']:''; ?></textarea>
                    <!--<input type="text" class="form-control is-valid" name="batchName" id="inputSuccess" placeholder="Enter the batch name" autocomplete="off" value="<?php echo !empty($_POST['batchName'])?$_POST['batchName']:''; ?>">-->
                    <?php echo form_error('paymentRemarks','<div style="color:red;">','</div>'); ?>
                  </div>
                 <div class="form-group">
                  <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i>Notes</label>
                  <textarea class="form-control is-valid" name="notes" id="notes" autocomplete="on"><?php echo !empty($_POST['notes'])?$_POST['notes']:''; ?></textarea>
                  <?php echo form_error('notes','<div style="color:red;">','</div>'); ?>
                </div>
                <div class="col-md-12 col-sm-12 col-lg-12">
                 <div class="form-group col-md-6">
                  <label>Next Followup Date:</label>
                    <div class="input-group date" id="reservationdate" data-target-input="nearest">
                        <input type="text" name="followupDate" class="form-control datetimepicker-input" data-target="#reservationdate" autocomplete="off" value="<?php echo !empty($_POST['followupDate'])?$_POST['followupDate']:''; ?>" placeholder="Select Folloup date" />
                        <div class="input-group-append" data-target="#reservationdate" data-toggle="datetimepicker">
                            <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                        </div>
                    </div>
                    <?php echo form_error('followupDate','<div style="color:red;">','</div>'); ?>
                </div>
                  <div class="form-group">
                  <label>Leads Status:</label>
                    <div class="input-group date" id="leadsStatus" data-target-input="nearest">
                        <select class="form-control" style="width: 100%;" name="leadStatus" id="leadStatus">
                            <option value="">--Select Status--</option>
                            <option value="In Progress">In Progress</option>
                            <option value="Not Called">Not Called</option>
                            <option value="Called But On Hold">Called But On Hold</option>
                            <option value="Closed">Closed</option>
                            <option value="Not Responded">Not Responded</option>
                          </select>
                    </div>
                </div>
                <?php echo form_error('leadStatus','<div style="color:red;">','</div>'); ?>
              </div>
                  <!-- radio -->
                 <div class="card-footer">
                  <input type="submit" class="btn btn-primary" name="batchSubmit" value="Submit">
                  <a href="<?php echo site_url('Batch/batch_tab'); ?>" class="btn btn-secondary">Back</a>
                </div>
                </form>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->