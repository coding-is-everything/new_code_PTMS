<?php $getData = $this->Incentive_model->getGstData(); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1><?php echo $title; ?></h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <!-- <li class="breadcrumb-item active"><a href="<?php echo site_url() ?>Incentive/add"><i class="fa fa-plus">&nbsp;Add Incentive</i></a></li> -->
          </ol>
        </div>
        <!-- Display status message -->
        <?php if (!empty($success_msg)) { ?>
          <div class="col-xs-12">
            <div class="alert alert-success"><?php echo $success_msg; ?></div>
          </div>
        <?php } elseif (!empty($error_msg)) { ?>
          <div class="col-xs-12">
            <div class="alert alert-danger"><?php echo $error_msg; ?></div>
          </div>
        <?php } ?>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title"></h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table border="0" cellspacing="5" cellpadding="5">
                                <tbody>
                                    <tr>
                                        <td>From date:</td>
                                        <td><input type="date" id="min" name="min"></td>
                                        <td>To date:</td>
                                        <td><input type="date" id="max" name="max"></td>
                                        <td><button class="btn btn-success" id="searchBtn" name="searchBtn">Search</button></td>
                                        <td></td>
                                        <td>Sales Representative: </td>
                                        <td colspan="3">
                                            <select id="selectoption1"  class="form-control select2" style="width: 270px !important;" name="userId">
                                                <option value="">--Select Option--</option>
                                                <option value="1">Fee Remaining</option>
                                                <option value="0">Fee Completed</option>
                                            </select>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <div id="ajaxData">
               <?php if($this->session->userdata('roleId') == '1'){?>
               <table class="table table-bordered table-striped">
                   <thead>
                       <tr>
                           <th>Total Fee Pending With GST</th>
                           <th><?php echo $totalFeePending->CPC - $this->Incentive_model->getFullPaymentGiven()['CPG']; ?></th>
                           <th>Total Fee Pending Without GST</th>
                           <th><?php if($getData['settingStatus'] == 'on'){ echo round(($totalFeePending->CPC - $this->Incentive_model->getFullPaymentGiven()['CPG']) - (($totalFeePending->CPC - $this->Incentive_model->getFullPaymentGiven()['CPG'])*($getData['gstPercent'])/100),0); }else{ echo ($totalFeePending->CPC - $this->Incentive_model->getFullPaymentGiven()['CPG']); } ?></th>
                           <th>Total Fee Given With GST</th>
                           <th><?php echo $this->Incentive_model->getFullPaymentGiven()['CPG']; ?></th>
                           <th>Total Fee Given Without GST</th>
                           <th><?php if($getData['settingStatus'] == 'on'){ echo round(($this->Incentive_model->getFullPaymentGiven()['CPG']) - (($this->Incentive_model->getFullPaymentGiven()['CPG'])*($getData['gstPercent'])/100),0); }else{ echo ($this->Incentive_model->getFullPaymentGiven()['CPG']); } ?></th>
                       </tr>
                   </thead>
               </table>
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>Sr.No</th>
                    <th>Student Name</th>
                    <th>Course Name</th>
                    <th>Mobile Number</th>
                    <!--<th>Email Id</th>-->
                    <th>Sales Representative</th>
                    <th>Last Transaction Date</th>
                    <th>Next Transaction Date</th>
                    <th>Total Fee Committed</th>
                    <th>Total Fee Given</th>
                    <th>Total Fee Given Without GST</th>
                    <th>Total Fee Remaining</th>
                    <th>Notes</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $sr = 1;
                  ?>
                  <?php if(!empty($sales)){ foreach($sales as $row){ ?>
                  <tr>
                    <td><?php echo $sr++; ?></td>
                    <td><?php echo ucfirst($this->Reports_model->getStudentName($row->studentId)[0]->studentName) ?></td>
                    <td><?php echo $this->Incentive_model->courseName($row->batchId)->courseName ?></td>
                    <td><?php echo $this->Reports_model->getStudentName($row->studentId)[0]->studentMobile." / ".$this->Reports_model->getStudentName($row->studentId)[0]->studentMobile2 ?></td>
                    <!--<td><?php echo $this->Reports_model->getStudentName($row->studentId)[0]->studentEmail ?></td>-->
                    <td><?php echo $this->Reports_model->getSRUser($row->userId)[0]->userName ?></td>
                    <td><?php echo date('d-M-Y', strtotime($row->transactionDate)); ?></td>
                    <td><?php echo date('d-M-Y', strtotime($row->nextCommitedDate)); ?></td>
                    <td><?php echo $row->coursePriceCommited; ?></td>
                    <td><?php echo $this->Incentive_model->totalCoursePriceGiven($row->studentId, $row->batchId)[0]->coursePriceGiven ?></td><!--$this->Reports_model->getPriceById($row->studentId, $row->batchId)[0]->CPG-->
                    <td><?php if($getData['settingStatus'] == 'on'){ echo round($this->Incentive_model->totalCoursePriceGiven($row->studentId, $row->batchId)[0]->coursePriceGiven - $this->Incentive_model->totalCoursePriceGiven($row->studentId, $row->batchId)[0]->coursePriceGiven*($getData['gstPercent'])/100,0); }else{ echo $this->Incentive_model->totalCoursePriceGiven($row->studentId, $row->batchId)[0]->coursePriceGiven; } ?></td>
                    <td><?php echo $row->coursePriceCommited - $this->Incentive_model->totalCoursePriceGiven($row->studentId, $row->batchId)[0]->coursePriceGiven ?></td><!-- $this->Reports_model->getPriceById($row->studentId, $row->batchId)[0]->CPR -->
                    <td><?php echo $row->details; ?></td>
                  </tr>
                  <?php } } ?>
                </tbody>
              </table>
              <?php } else {?>
              <table class="table table-bordered table-striped">
                   <thead>
                       <tr>
                           <th>Total Fee Pending</th>
                           <th><?php echo $totalFeePending->CPC - $totalFeePending->CPG ?></th>
                           <th>Total Fee Pending Without GST</th>
                           <th><?php echo round(($totalFeePending->CPC - $totalFeePending->CPG) - (($totalFeePending->CPC - $totalFeePending->CPG)*($getData['gstPercent'])/100), 0) ?></th>
                           <th>Total Fee Given</th>
                           <th><?php echo $totalFeePending->CPG ?></th>
                           <th>Total Fee Given Without GST</th>
                           <th><?php echo round($totalFeePending->CPG - $totalFeePending->CPG*($getData['gstPercent'])/100, 0) ?></th>
                       </tr>
                   </thead>
               </table>
               <table id="example2" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>Sr.No</th>
                    <th>Student Name</th>
                    <th>Course Name</th>
                    <th>Mobile Number</th>
                    <!--<th>Email Id</th>-->
                    <th>Sales Representative</th>
                    <th>Last Transaction Date</th>
                    <th>Next Transaction Date</th>
                    <th>Total Fee Committed</th>
                    <th>Total Fee Given</th>
                    <th>Total Fee Given Without GST</th>
                    <th>Total Fee Remaining</th>
                    <th>Notes</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $sr = 1;
                  ?>
                  <?php if(!empty($sales)){ foreach($sales as $row){ ?>
                  <tr>
                    <td><?php echo $sr++; ?></td>
                    <td><?php echo ucfirst($this->Reports_model->getStudentName($row->studentId)[0]->studentName) ?></td>
                    <td><?php echo $this->Incentive_model->courseName($row->batchId)->courseName ?></td>
                    <td><?php echo $this->Reports_model->getStudentName($row->studentId)[0]->studentMobile." / ".$this->Reports_model->getStudentName($row->studentId)[0]->studentMobile2 ?></td>
                    <!--<td><?php echo $this->Reports_model->getStudentName($row->studentId)[0]->studentEmail ?></td>-->
                    <td><?php echo $this->Reports_model->getSRUser($row->userId)[0]->userName ?></td>
                    <td><?php echo date('d-M-Y', strtotime($row->transactionDate)); ?></td>
                    <td><?php echo date('d-M-Y', strtotime($row->nextCommitedDate)); ?></td>
                    <td><?php echo $row->coursePriceCommited; ?></td>
                    <td><?php echo $this->Incentive_model->totalCoursePriceGiven($row->studentId, $row->batchId)[0]->coursePriceGiven ?></td><!--$this->Reports_model->getPriceById($row->studentId, $row->batchId)[0]->CPG-->
                    <td><?php if($getData['settingStatus'] == 'on'){ echo round($this->Incentive_model->totalCoursePriceGiven($row->studentId, $row->batchId)[0]->coursePriceGiven - $this->Incentive_model->totalCoursePriceGiven($row->studentId, $row->batchId)[0]->coursePriceGiven*($getData['gstPercent'])/100,0); }else{ echo $this->Incentive_model->totalCoursePriceGiven($row->studentId, $row->batchId)[0]->coursePriceGiven; } ?></td>
                    <td><?php echo $row->coursePriceCommited - $this->Incentive_model->totalCoursePriceGiven($row->studentId, $row->batchId)[0]->coursePriceGiven ?></td><!-- $this->Reports_model->getPriceById($row->studentId, $row->batchId)[0]->CPR -->
                    <td><?php echo $row->details; ?></td>
                  </tr>
                  <?php } } ?>
                </tbody>
              </table>
                <?php } ?>
                </div>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<script>
    $(document).ready(function() {
       $('#searchBtn').on('click', function(){
        //   alert('hello');
          var startDate = $('#min').val();
          var endDate = $('#max').val();
          var roleId = '<?php echo $this->session->userdata('roleId') ?>';
          if(startDate == '' || endDate == ''){
              alert('Any Of them can not be blank.');
          }else{
            //   alert(startDate+" "+endDate+" "+id);
            //   $('#ajaxData').replaceWith('Hello');
              var formData = "SD="+startDate+"&ED="+endDate+"&roleId="+roleId;
              $.ajax({
                 url: '<?=base_url()?>Reports/ajaxReportData/'+startDate+'/'+endDate+'/'+roleId,
                 method: "POST",
                 data: formData,
                 success: function(data) {
                    console.log(data);
                     $('#ajaxData').empty();
                     $('#ajaxData').html(data);
                     //$('#example1').dataTable().fnDestroy();
                     $("#example1").DataTable({
                         "destroy": true,
      "responsive": true, "lengthChange": true, "autoWidth": true,
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
                 }
                 
              });
          }
       });
       $('#selectoption1').on('change', function(){
           var data = $(this).val();
        //   alert(data);
           if(data == ''){
               alert('Kindly Select Any one option.');
           }else{
               $.ajax({
                   url: '<?= base_url() ?>Reports/ajaxFeeDetails/'+data,
                   method: "POST",
                   success: function(data) {
                       $('#ajaxData').html(data);
                       $('#example1').dataTable().fnDestroy();
                     $("#example1").DataTable({
      "responsive": true, "lengthChange": true, "autoWidth": true,
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
                   }
               });
           }
       });
    });
</script>