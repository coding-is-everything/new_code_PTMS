   <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
 <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0"><?php if($this->session->userdata('roleType') === 'ARI'){ ?>ARI Dashboard<?php }elseif($this->session->userdata('roleType') === 'ARO'){ ?>ARO Dashboard<?php }elseif($this->session->userdata('roleType') === 'Zone Commissioner'){ ?>Zone Commissioner Dashboard<?php }else{ ?>MD Dashboard<?php } ?></h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Dashboard</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    <!-- /.content-header -->
    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <!--<div class="row">-->
        <!--  <div class="col-lg-3 col-6">-->
            <!-- small card -->
        <!--    <div class="small-box bg-info">-->
        <!--      <div class="inner">-->
        <!--        <h3><?php echo $totalProperty[0]->totalProperty ?></h3>-->

        <!--        <p>Total Property For Audit</p>-->
        <!--      </div>-->
        <!--      <div class="icon">-->
        <!--        <i class="fas fa fa-home"></i>-->
        <!--      </div>-->
        <!--      <a href="<?php echo site_url('Property/getData') ?>" class="small-box-footer">-->
        <!--        More info <i class="fas fa-arrow-circle-right"></i>-->
        <!--      </a>-->
        <!--    </div>-->
        <!--  </div>-->
          <!-- ./col -->
        <!--  <div class="col-lg-3 col-6">-->
            <!-- small card -->
        <!--    <div class="small-box bg-success">-->
        <!--      <div class="inner">-->
        <!--        <h3><?php echo $approvedProperty[0]->approvedProperty ?></h3>-->

        <!--        <p>Total Approved Property</p>-->
        <!--      </div>-->
        <!--      <div class="icon">-->
        <!--        <i class="fas fa fa-home"></i>-->
        <!--      </div>-->
        <!--      <a href="<?php echo site_url('Property/getData') ?>" class="small-box-footer">-->
        <!--        More info <i class="fas fa-arrow-circle-right"></i>-->
        <!--      </a>-->
        <!--    </div>-->
        <!--  </div>-->
          <!-- ./col -->
        <!--  <div class="col-lg-3 col-6">-->
            <!-- small card -->
        <!--    <div class="small-box bg-warning">-->
        <!--      <div class="inner">-->
        <!--        <h3><?php echo $totalProperty[0]->totalProperty - $approvedProperty[0]->approvedProperty - $rejectedProperty[0]->rejectedProperty; ?></h3>-->

        <!--        <p>Total Pending Property</p>-->
        <!--      </div>-->
        <!--      <div class="icon">-->
        <!--        <i class="fa fa-exclamation-triangle"></i>-->
        <!--      </div>-->
        <!--      <a href="<?php echo site_url('Property/getData') ?>" class="small-box-footer">-->
        <!--        More info <i class="fas fa-arrow-circle-right"></i>-->
        <!--      </a>-->
        <!--    </div>-->
        <!--  </div>-->
          <!-- ./col -->
        <!--  <div class="col-lg-3 col-6">-->
            <!-- small card -->
        <!--    <div class="small-box bg-danger">-->
        <!--      <div class="inner">-->
        <!--        <h3><?php echo $rejectedProperty[0]->rejectedProperty ?></h3>-->

        <!--        <p>Total Rejected Property</p>-->
        <!--      </div>-->
        <!--      <div class="icon">-->
        <!--        <i class="fa fa-times"></i>-->
        <!--      </div>-->
        <!--      <a href="<?php echo site_url('Property/getData') ?>" class="small-box-footer">-->
        <!--        More info <i class="fas fa-arrow-circle-right"></i>-->
        <!--      </a>-->
        <!--    </div>-->
        <!--  </div>-->
          <!-- ./col -->
        <!--</div>-->
        <br/><br/>
        <div class="row">
            <h1><b>Ward Wise Validation Summary</b></h1>
        </div>
        <br/><br/>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <table id="example1" class="table table-striped table-bordered table-hover" style="width: 100% !important;">
                    <thead class="bg-success">
                        <tr>
                            <th>S/No.</th>
                            <th>Ward No/ Name</th>
                            <th>ARI Name</th>
                            <th>Total Property To Be Validated</th>
                            <th>Pending With ARI</th>
                            <th>Pending With ARO</th>
                            <th>Pending With Zone Commissioner</th>
                            <th>Approved Properties</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $sr = 1;
                        if(!empty($MDData)){ foreach($MDData as $prop) {
                            // $OldDate = strtotime($prop->created_at);
                            // $NewDate = date('M j, Y', $OldDate);
                            // $ARIDate = date('M j, Y', strtotime($prop->ARI_updated_at));
                            // $ARODate = date('M j, Y', strtotime($prop->ARO_updated_at));
                            // $diff = date_diff(date_create($NewDate),date_create(date("M j, Y")));
                            // $diffARO = date_diff(date_create($ARIDate),date_create(date("M j, Y")));
                            // $diffZC = date_diff(date_create($ARODate),date_create(date("M j, Y")));
                        ?>
                        <tr>
                            <td><?php echo $sr++; ?></td>
                            <td><?php echo $prop->wardName ?></td>
                            <td><?php echo $prop->ARIName ?></td>
                            <td><?php echo $prop->CT; //$prop->approved_count + $prop->rejected_count + $prop->ari_null_count; ?></td>
                            <td><?php echo $prop->ari_null_count; ?></td>
                            <td><?php  echo $prop->aro_null_count - $prop->ari_null_count;  ?></td>
                            <td><?php echo $prop->zc_null_count - $prop->aro_null_count; ?></td>
                            <td><?php $count = 1; if ($prop->approved_count == $prop->aro_approved_count && $prop->aro_approved_count == $prop->zc_approved_count) { echo $count; $count++; }else{ echo 0; }?></td>
                        </tr>
                        <?php }} ?>
                    </tbody>
                </table>
            </div>
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </div>
    <!-- /.content -->
</div>
  <!-- /.content-wrapper -->