   <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
 <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0"><?php if($this->session->userdata('roleType') === 'ARI'){ ?>ARI Dashboard<?php }elseif($this->session->userdata('roleType') === 'ARO'){ ?>ARO Dashboard<?php }elseif($this->session->userdata('roleType') === 'Zone Commissioner'){ ?>Zone Commissioner Dashboard<?php }else{ ?>Home Dashboard<?php } ?></h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Dashboard</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    <!-- /.content-header -->
    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-3 col-6">
            <!-- small card -->
            <div class="small-box bg-info">
              <div class="inner">
                <h3><?php if(!empty($totalProperty[0]->totalProperty)){ echo $totalProperty[0]->totalProperty; }else{ echo "0"; } ?></h3>

                <p>Total Property For Audit</p>
              </div>
              <div class="icon">
                <i class="fas fa fa-home"></i>
              </div>
              <a href="<?php echo site_url('Property/getData') ?>" class="small-box-footer">
                More info <i class="fas fa-arrow-circle-right"></i>
              </a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small card -->
            <div class="small-box bg-success">
              <div class="inner">
                <h3><?php if(!empty($approvedProperty[0]->approvedProperty)){ echo $approvedProperty[0]->approvedProperty; }else{ echo "0"; } ?></h3>

                <p>Total Approved Property</p>
              </div>
              <div class="icon">
                <i class="fas fa fa-home"></i>
              </div>
              <a href="<?php echo site_url('Property/getData') ?>" class="small-box-footer">
                More info <i class="fas fa-arrow-circle-right"></i>
              </a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small card -->
            <div class="small-box bg-warning">
              <div class="inner">
                <h3><?php if(!empty($totalProperty[0]->totalProperty) || !empty($approvedProperty[0]->approvedProperty) || !empty($rejectedProperty[0]->rejectedProperty)){ echo $totalProperty[0]->totalProperty - $approvedProperty[0]->approvedProperty - $rejectedProperty[0]->rejectedProperty; }else{ echo "0"; } ?></h3>

                <p>Total Pending Property</p>
              </div>
              <div class="icon">
                <i class="fa fa-exclamation-triangle"></i>
              </div>
              <a href="<?php echo site_url('Property/getData') ?>" class="small-box-footer">
                More info <i class="fas fa-arrow-circle-right"></i>
              </a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small card -->
            <div class="small-box bg-danger">
              <div class="inner">
                <h3><?php if(!empty($rejectedProperty[0]->rejectedProperty)){ echo $rejectedProperty[0]->rejectedProperty; }else{ echo "0"; } ?></h3>

                <p>Total Rejected Property</p>
              </div>
              <div class="icon">
                <i class="fa fa-times"></i>
              </div>
              <a href="<?php echo site_url('Property/getData') ?>" class="small-box-footer">
                More info <i class="fas fa-arrow-circle-right"></i>
              </a>
            </div>
          </div>
          <!-- ./col -->
        </div>
        <br/><br/>
        <div class="row">
            <h1><b>Active Ward Survey Map - Bilaspur City</b></h1>
        </div>
        <br/><br/>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <table id="example1" class="table table-striped table-bordered table-hover" style="width: 100% !important;">
                    <thead class="bg-success">
                        <tr>
                            <th>S/No.</th>
                            <th>Zone No</th>
                            <th>Ward No</th>
                            <th>Audit Done</th>
                            <th>Reason If Rejected</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $sr = 1;
                        if(!empty($property)){ foreach($property as $prop) {
                            $OldDate = strtotime($prop->created_at);
                            $NewDate = date('M j, Y', $OldDate);
                            $ARIDate = date('M j, Y', strtotime($prop->ARI_updated_at));
                            $ARODate = date('M j, Y', strtotime($prop->ARO_updated_at));
                            $diff = date_diff(date_create($NewDate),date_create(date("M j, Y")));
                            $diffARO = date_diff(date_create($ARIDate),date_create(date("M j, Y")));
                            $diffZC = date_diff(date_create($ARODate),date_create(date("M j, Y")));
                        ?>
                        <tr>
                            <td><?php echo $sr++; ?></td>
                            <td><?php echo $this->Property_model->getZoneDetail($prop->zone_no)[0]->zoneName; ?></td>
                            <td><?php echo $this->Property_model->getWardDetailWard('Ward '.$prop->ward_no)[0]->wardName; ?>( <?php echo $this->Property_model->getWardDetailWard('Ward '.$prop->ward_no)[0]->wardId ?> )</td>
                            <td><?php 
                            if($prop->ARI_audit_status == 'Approved' && $prop->ARO_audit_status == 'Approved' && $prop->ZC_audit_status == 'Approved'){ 
                                echo "Approved"; 
                            }elseif(!isset($prop->ARI_audit_status)){
                                if($this->session->userdata('roleType') !== 'ARI'){ 
                                    echo "Pending At ARI Desk since ".$diff->format('%a days.');
                                }else{
                                    echo "Pending In My Desk since ".$diff->format('%a days.');
                                }
                            }elseif(isset($prop->ARI_audit_status) && (!isset($prop->ARO_audit_status) || $prop->ARO_audit_status === 'Rejected')){
                                echo "Pending Or Rejected At ARO Desk since ".$diffARO->format('%a days.');
                            }elseif(isset($prop->ARI_audit_status) && isset($prop->ARO_audit_status) && (!isset($prop->ZC_audit_status) || $prop->ZC_audit_status == 'Rejected')){
                                if($prop->ZC_audit_status == 'Rejected'){
                                    echo "Rejected At Zone Commissioner Desk since ".$diffZC->format('%a days.');
                                }else{
                                    echo "Pending At Zone Commissioner Desk since ".$diffZC->format('%a days.');
                                }
                            }?></td>
                            <td>
                                <?php 
                            if($prop->ARI_audit_status == 'Approved' && $prop->ARO_audit_status == 'Approved' && $prop->ZC_audit_status == 'Approved'){ 
                                echo "Approved"; 
                            }elseif(!isset($prop->ARI_audit_status)){
                                if($this->session->userdata('roleType') !== 'ARI'){ 
                                    echo "Pending At ARO Desk since ".$diff->format('%a days.');
                                }else{
                                    echo "Pending In My Desk since ".$diff->format('%a days.');
                                }
                            }elseif(isset($prop->ARI_audit_status) && $prop->ARO_audit_status === 'Rejected'){
                                echo $prop->ARO_remark;
                            }elseif(isset($prop->ARI_audit_status) && isset($prop->ARO_audit_status) && (!isset($prop->ZC_audit_status) || $prop->ZC_audit_status == 'Rejected')){
                                echo $prop->ZC_remark;
                            }?>
                            </td>
                            <td>
                                <?php if($this->session->userdata('roleId') === '1'){ ?>
                                    <button type="button" class="btn btn-success">Escalate To Concern Person</button>
                                <?php }elseif($this->session->userdata('roleId') === '3'){ ?>
                                    <button type="button" class="btn btn-success">Escalate To ARI</button>
                                <?php }elseif($this->session->userdata('roleId') === '4'){ ?>
                                    <button type="button" class="btn btn-success">Escalate To ARI</button>
                                <?php }else{ ?>
                                    
                                <?php } ?>
                            </td>
                        </tr>
                        <?php }} ?>
                    </tbody>
                </table>
            </div>
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </div>
    <!-- /.content -->
</div>
  <!-- /.content-wrapper -->