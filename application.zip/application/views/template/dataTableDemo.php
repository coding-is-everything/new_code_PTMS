<!doctype html>
<html>
    <head>
        <title>Date Range Search in DataTable With JQuery Ajax and PHP</title>
        <link herf="<?php echo base_url() ?>public/dataTableDemo/datatables.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url() ?>public/dataTableDemo/jquery-ui.min.css" rel="stylesheet" type="text/css" />
        <script src="<?php echo base_url() ?>public/dataTableDemo/jquery-3.4.1.min.js" ></script>
        <script src="<?php echo base_url() ?>public/dataTableDemo/jquery-ui.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url() ?>public/dataTableDemo/datatables.min.js"></script>
    </head>
    <body>
        <div>
            <table>
                <tr>
                    <td>
                        <input type="text" readonly id="search_fromdate" class="datepicker" placeholder="From Date">
                    </td>
                    <td>
                        <input type="text" readonly id="search_todate" class="datepicker" placeholder="To Date" >
                    </td>
                    <td>
                        <input type="button" id="btn_search" value="Search">
                    </td>
                </tr>
                <table id='empTable' class='display dataTable'>
                <thead>
                <tr>
                    <th>Employee name</th>
                    <th>Email</th>
                    <th>Date of Joining</th>
                    <th>Salary</th>
                    <th>City</th>
                </tr>
                </thead>
                
            </table>
            </table>
        </div>
        <script>
        $(document).ready(function(){

            // Datapicker 
            $( ".datepicker" ).datepicker({
                "dateFormat": "yy-mm-dd",
                changeYear: true,
                changeMonth: true
            });

            // DataTable
            var dataTable = $('#empTable').DataTable({
                'processing': true,
                'serverSide': true,
                'serverMethod': 'post',
                'searching': true, // Set false to remove default Search Control
                'ajax': {
                    'url':'ajaxfile.php',
                    'data': function(data){
                        // Read values
                        var from_date = $('#search_fromdate').val();
                        var to_date = $('#search_todate').val();

                        // Append to data
                        data.searchByFromdate = from_date;
                        data.searchByTodate = to_date;
                    }
                },
                'columns': [
                    { data: 'emp_name' },
                    { data: 'email' },
                    { data: 'date_of_joining' },
                    { data: 'salary' },
                    { data: 'city' },
                ]
            });

            // Search button
            $('#btn_search').click(function(){
                dataTable.draw();
            });
           
        });
        </script>
    </body>
</html>