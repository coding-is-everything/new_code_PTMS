<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>View Zone Details</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active"><a href="<?php echo site_url() ?>zone/index"><i class="fas fa-folder">&nbsp;Manage Zone</i></a></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- right column -->
          <div class="col-md-12">
            <!-- Form Element sizes -->
                   <!-- general form elements disabled -->
            <div class="card card-warning">
              <div class="card-header">
                <h3 class="card-title">View Zone Details</h3>
              </div>
              <!-- /.card-header -->
              <!-- Display status message -->
    <?php if(!empty($success_msg)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-success"><?php echo $success_msg; ?></div>
    </div>
    <?php }elseif(!empty($error_msg)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-danger"><?php echo $error_msg; ?></div>
    </div>
    <?php } ?>
              <div class="card-body">
                <form method="post" action="<?php echo site_url() ?>Ari/add">
                  <!-- input states -->
                 <div class="form-group">
                  <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Zone Name</label>
                  <input type="text" autocomplete="off" class="form-control is-valid" name="zoneName" id='inputSuccess' placeholder="Enter ARO Name" value="<?php echo !empty($_POST['zoneName'])?$_POST['zoneName']:$zone[0]->zoneName; ?>" readonly>
                  <?php echo form_error('zoneName','<div style="color:red;">','</div>'); ?>
                </div>
                     
                <!-- radio -->
                    
                 <div class="card-footer">
                  <!--<input type="submit" class="btn btn-primary" name="userSubmit" value="Submit">-->
                  <a href="<?php echo site_url('zone/index'); ?>" class="btn btn-secondary">Back</a>
                </div>
                </form>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <script type="text/javascript">
    function ShowHideDiv(chkPassport) {
        var dvPassport = document.getElementById("dvPassport");
        dvPassport.style.display = chkPassport.checked ? "block" : "none";
    }
</script>
<script type="text/javascript">
  document.getElementById('name').value = "<?php echo $_POST['roleType'];?>";
  document.getElementById('name1').value = "<?php echo $_POST['incecntivePer'];?>";
  document.getElementById('name2').value = "<?php echo $_POST['teamLeadName'];?>";
</script>