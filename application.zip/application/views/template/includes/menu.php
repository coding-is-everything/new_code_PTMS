

    <div class="flex">
      <nav class="bg-gray-800 h-screen w-64 px-4 py-8">
        <ul>
          <li class="mb-4">
            <a href="#" class="block text-gray-400 hover:text-white">Dashboard</a>
          </li>
          <li class="mb-4">
            <a href="#" class="block text-gray-400 hover:text-white">Analytics</a>
          </li>
          <li class="mb-4">
            <a href="#" class="block text-gray-400 hover:text-white">Users</a>
          </li>
          <li class="mb-4">
            <a href="#" class="block text-gray-400 hover:text-white">Settings</a>
          </li>
        </ul>
      </nav>