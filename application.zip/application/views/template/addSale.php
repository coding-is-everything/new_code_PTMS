<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Add Sale</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active"><a href="<?php echo site_url() ?>Sale/sale_tab"><i class="fas fa-folder">&nbsp;Manage Sales</i></a></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- right column -->
          <div class="col-md-12">
            <!-- Form Element sizes -->
                   <!-- general form elements disabled -->
            <div class="card card-warning">
              <div class="card-header">
                <h3 class="card-title">Add Sale</h3>
              </div>
              <!-- /.card-header -->
              <!-- Display status message -->
    <?php if(!empty($success_msg)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-success"><?php echo $success_msg; ?></div>
    </div>
    <?php }elseif(!empty($error_msg)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-danger"><?php echo $error_msg; ?></div>
    </div>
    <?php } ?>
    <?php echo '<div style="color:red;">';
    echo validation_errors();
    echo '</div>'; ?>
              <div class="card-body">
                 <form method="post" action="<?php echo site_url() ?>Sale/add" enctype='multipart/form-data'>
                  <!-- input states -->
                     <div class="form-group clearfix">
                      <div class="icheck-primary d-inline">
                        <input type="radio" id="radio1" name="mode" value="direct" onclick="show1();" checked>
                        <label for="radio1">Direct Sale
                        </label>
                      </div>
                      <div class="icheck-primary d-inline">
                        <input type="radio" id="radio2" name="mode" value="indirect" onclick="show1();">
                        <label for="radio2">Indirect Sale
                        </label>
                      </div>
                      <div class="icheck-primary d-inline">
                          <input type="radio" id="radio3" name="mode" value="no claim" onclick="show1();">
                          <label for="radio3">No Claim</label>
                      </div>
                       <?php echo form_error('mode','<div style="color:red;">','</div>'); ?>
                    </div>
                  <div class="form-group">
                  <label>Batch</label>
                  <select id="selectoption"  class="form-control select2" style="width: 100%;" name="batchId" onchange="show();">
                    <option value="" data-price="">--Select Batch--</option>
                    <?php 
                        foreach($batches as $row)
                        {  if($row->batchId == $_POST['batchId'] ){  ?>
                         <option selected="true" data-price="<?php echo $row->coursePrice?>"  value="<?php echo $row->batchId?>"><?php echo ucfirst($row->batchName)?></option>
                       <?php } else {?><option data-price="<?php echo $row->coursePrice?>"  value="<?php echo $row->batchId?>"><?php echo ucfirst($row->batchName)?></option>
                        <?php }}?>
                  </select>
                  <?php echo form_error('batchId','<div style="color:red;">','</div>'); ?>
                </div>
                     <div class="form-group">
                          <input class="customCheckbox2"  type="checkbox" name="checked" id="tpe" value="1"  <?php if(!empty($_POST['checked'])) { ?> checked <?php }  ?> onchange="show1();" >
                          <label for="customCheckbox2">Split Sales Between Sales Representatives</label>
                        </div>
                 <div class="form-group">
                  <label>Sales representatives</label>
                  <select id="selectoption1"  class="form-control select2" style="width: 100%;" name="userId" onchange="show1();" >
                    <option value="" data-price="" data-price1="">--Select Sales Representative--</option>
                    <?php 
                        foreach($users as $row)
                        { if($row->userId == $_POST['userId'] ){?>
                         <option selected="true" data-price="<?php echo $row->incecntivePer?>" data-price1="<?php echo $row->teamLeadPer?>" value="<?php echo $row->userId?>"><?php echo $row->userName?></option>
                       <?php } else {?><option data-price="<?php echo $row->incecntivePer?>" data-price1="<?php echo $row->teamLeadPer?>"  value="<?php echo $row->userId?>"><?php echo $row->userName?></option>
                         <?php }}?>
                  </select>
                  <?php echo form_error('userId','<div style="color:red;">','</div>'); ?>
                </div>
              
                  <div class="form-group">
                  <label>Student</label>
                  <select id="selectoption2" class="form-control select2" style="width: 100%;" name="studentId">
                    <option value="">--Select Student--</option>
                    <?php 
                        foreach($students as $row)
                        { if($row->studentId == $_POST['studentId'] ){?>
                         <!--data-price="<?php //echo $this->Sale_model->getPreviousFee($row->studentId)[0]->previousFee ?>"-->
                         <option selected="true" value="<?php echo $row->studentId?>"><?php echo $row->studentName?>&nbsp;(<?php echo $row->studentMobile?>)</option>
                       <?php } else {?><option value="<?php echo $row->studentId?>"><?php echo $row->studentName?>&nbsp;(<?php echo $row->studentMobile?>)</option>
                        <?php }}?>
                  </select>
                  <?php echo form_error('studentId','<div style="color:red;">','</div>'); ?>
                </div>
                     <a href="javascript:javascript:void(0)" onClick="javascript:custompopup();">Click Here to Add Student</a>

                 <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Course Commited</label>
                      <input type="text" class="form-control" name="price" id="priceInput" readonly value="<?php echo !empty($_POST['price'])?$_POST['price']:''; ?>">
                  </div>

                   <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Discount(in amount)</label>
                    <input type="text"  class="form-control is-valid" autocomplete="off"  name="courseDiscount"  id="discount" value="<?php echo !empty($_POST['courseDiscount'])?$_POST['courseDiscount']:''; ?>">
                    <?php //echo form_error('courseDiscount','<div style="color:red;">','</div>'); ?>
                  </div>
                   <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Actual Course Fees</label>
                    <input type="text" class="form-control is-valid" name="coursePriceCommited" id="actual"  readonly value="<?php echo !empty($_POST['coursePriceCommited'])?$_POST['coursePriceCommited']:''; ?>" onmouseleave="display();">
                  </div>              
                <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Course Fees Given</label>
                    <input type="text" class="form-control is-valid" name="couesePriceGiven" id="feegiven" placeholder="Enter Given Course Price" autocomplete="off" value="<?php echo !empty($_POST['couesePriceGiven'])?$_POST['couesePriceGiven']:''; ?>" onkeyup="amount();">
                    <?php echo form_error('couesePriceGiven','<div style="color:red;">','</div>'); ?>
                  </div>
                  <div class="form-group">
                      <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Previous Discount</label>
                      <input type="text" readonly class="form-control is-valid" id="pDiscount" placeholder="Previous Payment Discount" autocomplete="off" value="" />
                  </div>
                      <div class="form-group">
                      <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Previous Course Fee Given</label>
                      <input type="text" readonly class="form-control is-valid" name="coursePricePre" id="pFeeGiven" placeholder="Previous Payment Here" autocomplete="off" value="<?php echo !empty($_POST['coursePricePre'])?$_POST['coursePricePre']:''; ?>">
                  </div>
                  <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Course Fees Remain</label>
                    <input type="text" readonly class="form-control is-valid" name="coursePriceRemain" id="feeremain" onmouseleave="remain();ncd();" value="<?php echo !empty($_POST['coursePriceRemain'])?$_POST['coursePriceRemain']:''; ?>">
                  </div>
                   <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Course Incentive Percentage</label>
                      <input type="text" class="form-control" name="courseIncentivePer" id="priceInput1" readonly value="<?php echo !empty($_POST['courseIncentivePer'])?$_POST['courseIncentivePer']:''; ?>">
                  </div>
                    <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Course Incentive Amount</label>
                      <input type="text" class="form-control" name="courseIncentive" id="incentive" onmouseleave="centive();" readonly value="<?php echo !empty($_POST['courseIncentive'])?$_POST['courseIncentive']:''; ?>">
                  </div>
                  <div id="original" style="display:block">
                  <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Course Incentive Percentage(Team Lead)</label>
                      <input type="text" class="form-control" name="courseIncentivePerTeam" id="priceInput2" readonly value="<?php echo !empty($_POST['courseIncentivePerTeam'])?$_POST['courseIncentivePerTeam']:''; ?>">
                  </div>
                    <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Course Incentive Amount(Team Lead)</label>
                      <input type="text" class="form-control" name="courseIncentiveTeam" id="incentive1" onmouseleave="centive1();" readonly value="<?php echo !empty($_POST['courseIncentiveTeam'])?$_POST['courseIncentiveTeam']:''; ?>">
                  </div>
           </div>
        
            <div id="doing">
               <div class="form-group">
                  <label>Sales representatives</label>
                  <select id="selectoption3"  class="form-control select2" style="width: 100%;" name="uId" onchange="show2();" >
                    <option value="" data-price="">--Select Sales Representative--</option>
                    <?php 
                        foreach($users as $row)
                        { if($row->userId == $_POST['uId'] ){?>
                         <option selected="true" data-price="<?php echo $row->incecntivePer?>" value="<?php echo $row->userId?>"><?php echo $row->userName?></option>
                       <?php } else {?><option data-price="<?php echo $row->incecntivePer?>"  value="<?php echo $row->userId?>"><?php echo $row->userName?></option>
                         <?php }}?>
                  </select>
                  <?php //echo form_error('userId','<div style="color:red;">','</div>'); ?>
                </div>
                  <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Course Incentive Percentage(SR)</label>
                      <input type="text" class="form-control" name="incentivePerSR" id="priceInput11" readonly value="<?php echo !empty($_POST['incentivePerSR'])?$_POST['incentivePerSR']:''; ?>">
                  </div>
                    <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Course Incentive Amount(SR)</label>
                      <input type="text" class="form-control" name="incentiveAmtSR" id="incentive11" onmouseleave="centive11();" readonly value="<?php echo !empty($_POST['incentiveAmtSR'])?$_POST['incentiveAmtSR']:''; ?>">
                  </div>
                </div>
                  <div class="col-md-6">
              <div class="form-group">
                  <label>Transaction Date:</label>
                    <div class="input-group date" id="reservationdate2" data-target-input="nearest">
                        <input type="text" name="transactionDate" class="form-control datetimepicker-input" data-target="#reservationdate2" value="<?php echo !empty($_POST['transactionDate'])?$_POST['transactionDate']:''; ?>" />
                        <div class="input-group-append" data-target="#reservationdate2" data-toggle="datetimepicker">
                            <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                        </div>
                    </div>
                    <?php echo form_error('transactionDate','<div style="color:red;">','</div>'); ?>
                </div>

                <div class="form-group" id="nc">
                  <label>Next Commited Date:</label>
                    <div class="input-group date" id="reservationdate3" data-target-input="nearest">
                        <input type="text" name="nextCommitedDate" class="form-control datetimepicker-input" data-target="#reservationdate3" value="<?php echo !empty($_POST['nextCommitedDate'])?$_POST['nextCommitedDate']:''; ?>" />
                        <div class="input-group-append" data-target="#reservationdate3" data-toggle="datetimepicker">
                            <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                        </div>
                    </div>
                    <?php echo form_error('nextCommitedDate','<div style="color:red;">','</div>'); ?>
                </div>
                </div>
                   <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Screenshot Upload</label>
                    <input type="file" class="form-control is-valid" name="screenShot" id="inputSuccess" placeholder="Enter the batch name">
                  </div>
                  <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Notes</label>
                    <textarea class="form-control is-valid" name="details" id="inputSuccess" placeholder="Enter the Detail"></textarea>
                  </div>
                <!-- radio -->
                      <div class="form-group clearfix">
                      <div class="icheck-primary d-inline">
                        <input type="radio" id="radioPrimary1" name="saleStatus" value="1" checked>
                        <label for="radioPrimary1">Active
                        </label>
                      </div>
                      <div class="icheck-primary d-inline">
                        <input type="radio" id="radioPrimary2" name="saleStatus" value="0">
                        <label for="radioPrimary2">Inactive
                        </label>
                      </div>
                       <?php echo form_error('saleStatus','<div style="color:red;">','</div>'); ?>
                    </div>
                 <div class="card-footer">
                  <input type="submit" class="btn btn-primary" id="saleButton" name="saleSubmit" value="Submit">
                  <a href="<?php echo site_url('Sale/sale_tab'); ?>" class="btn btn-secondary">Back</a>
                </div>
                </form>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script>
      $(document).ready(function(){
          $('#discount').on('keyup', function(){
              var discount = $(this).val();
              var pdiscount = $('#pDiscount').val();
              var pgiven =$('#pFeeGiven').val();
              var price = $('#priceInput').val();
              var actual = price - discount -pgiven - pdiscount;
              $('#actual').val(actual);
              $('#feeremain').val(actual);
              
          });
          $('#discount').on('keydown', function(){
              display();
          });
      });
      
  </script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){  
$("#doing").hide();
$("#tpe").click(function() {
    if($(this).is(":checked")) {
        $("#doing").show();
        $("#original").hide();
        centive();
        centive11();
        centive1();
    } else  {
      if($("#radio2").is(":checked")) {
        $("#doing").hide();
        $("#original").hide();
        centive();
        centive11();
        centive1();
    }
    else{
     $("#doing").hide();
        $("#original").show();
        centive();
        centive11();
        centive1();
    
    }
    }
});
});
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript">
function checkMode() {
var mode = '<?php echo $mode; ?>';
var checked = '<?php echo $checked; ?>';
if(mode == 'direct' && checked == 0){
$("#doing").hide(); 
$("#original").show(); 
}else if(mode == 'direct' && checked == 1){
$("#original").hide(); 
$("#doing").show(); 
}else if(mode == 'indirect' && checked == 0){
$("#original").hide(); 
$("#doing").hide();
}else{
$("#original").hide(); 
$("#doing").show(); 
}
}

</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){ 
//$("#original").hide(); 
$("#radio2").click(function() {
    if($(this).is(":checked")) {
      //alert("Hi");
      if($("#tpe").is(":checked")){
        $("#original").hide();
        $("#doing").show();
        show2();
        centive();
        centive11();
        centive1();
    } 
    else{
    //alert("Hello");
    $("#original").hide();
        $("#doing").hide();
        centive();
        centive11();
        centive1();
    
    }
    }
    
});
$("#radio1").click(function() {
        if($(this).is(":checked")) {
      //alert("Hi");
      if($("#tpe").is(":checked")){
        $("#original").hide();
        $("#doing").show();
        show2();
        centive();
        centive11();
        centive1();
    } 
    else{
    $("#original").show();
        $("#doing").hide();
        centive();
        centive11();
        centive1();
    
    }
    }
});
});
</script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<script>
  let show = () => {
    let element = document.getElementById("selectoption");
    let price = element.options[element.selectedIndex].getAttribute("data-price");    
    $('#priceInput').val(price);
    $('#actual').val(price);

  }
</script>
<script>
 function show1()  {
    let element = document.getElementById("selectoption1");
    let percent = element.options[element.selectedIndex].getAttribute("data-price");
    let team = element.options[element.selectedIndex].getAttribute("data-price1");
    //alert("Price: " + price);
    let pce = "";
    let tce ="";

    if($('#radio1').is(":checked"))
    {
      if($('#radio1').is(":checked") && $('#tpe').is(":checked")){
       pce = (percent *100)/2;
       centive();
        centive11();
        centive1();
      }else{
      pce = percent *100;
      tce = team *100;
      centive();
        centive11();
        centive1();
      }
      }else if($('#radio2').is(":checked")){
        if($('#radio2').is(":checked") && $('#tpe').is(":checked")){
            pce = ((percent *100)/2)/2;
            centive();
        centive11();
        centive1();
        }else{
            pce = (percent *100)/2;
            centive();
        centive11();
        centive1();
        }
      }else{
         if($('#radio3').is(":checked") && $('#tpe').is(":checked")){
             pce = 0;
             centive();
        centive11();
        centive1();
         }
      }

      /*
     if($('#radio2').is(":checked"))
     {
      pce = (percent *100)/2;
     }
     else
     {
      pce = percent *100;
      tce = team *100;
     }
     if($('#radio1').is(":checked") && $('#tpe').is(":checked"))
     {
      //alert("HI");
      pce = (percent *100)/2;
       //alert(pce);
     }
     else
     {
      alert("Hello");
      pce = percent *100;
      tce = team *100;
     }
     if($('#radio2').is(":checked") && $('#tpe').is(":checked"))
     {
      pce = ((percent *100)/2)/2;
     }
     else
     {
      pce = percent *100;
      tce = team *100;
     }*/
    // let TLId = <?php //echo $this->Incentive_model->checkTL(10) ?>;
    $('#priceInput1').val(pce);
    $('#priceInput2').val(tce);
    // $('#TLId').val(TLId);

  }
  $(document).ready(function(){
      $('#feegiven').keyup(function(){
      
         remain();
         ncd();
         centive();
         centive1();
         centive11();
      });
      $('#feegiven').keydown(function(){
    
         remain();
         ncd();
         centive();
         centive1();
         centive11();
      });
  });
</script>
<script>
 function show2()  {
    let element11 = document.getElementById("selectoption3");
    let percent11 = element11.options[element11.selectedIndex].getAttribute("data-price");
    //alert("Price: " + price);
    let pce11="";
      if($('#tpe').is(":checked"))
      {
     pce11 = (percent11 *100)/2;
       }
        if($('#radio1').is(":checked") && $('#tpe').is(":checked"))
       {
        pce11 = (percent11 *100)/2;
       }
       if($('#radio2').is(":checked") && $('#tpe').is(":checked"))
       {
        pce11 = ((percent11 *100)/2)/2;

       }
    
    // let TLId = <?php //echo $this->Incentive_model->checkTL(10) ?>;
    $('#priceInput11').val(pce11);
    // $('#TLId').val(TLId);

  }
</script>
<script>
    $(document).ready(function(){
       $('#selectoption2').on('change', function(){
          var batchId = $('#selectoption').val();
          var studentId = $(this).val();
          var formData = "batchId="+batchId+"&studentId="+studentId;
          $.ajax({
             url: '<?=base_url()?>/Sale/ajaxCall',
             method: "POST",
             data: formData,
             success: function(data) {
                //  alert(data);
                 var data1 = $.parseJSON(data);
                 $('#pFeeGiven').val(data1.pFee);
                 $('#pDiscount').val(data1.CD);
             }
             
          });
       });
      $('#selectoption2').on('change', function(){
          var batchId = $('#selectoption').val();
          var studentId = $(this).val();
          var formData = "batchId="+batchId+"&studentId="+studentId;
          $.ajax({
             url: '<?=base_url()?>/Sale/ajaxCallDI/'+batchId+'/'+studentId,
             method: "POST",
             data: formData,
             success: function(data) {
                //  alert('This Student Have last mode is : '+data+' kindly select accordingly.');
                 if(data == 'direct') {
                    //  alert(data);
                     $('#radio1').attr('checked', true);
                     $('#radio2').prop("disabled", true);
                 }else if(data == 'indirect') {
                    //  alert(data+'2');
                      $('#radio2').attr('checked', true);
                      $('#radio1').prop("disabled", true);
                 }else{
                    //  alert(data+'1');
                      $('#radio1').attr('checked', true);
                     $('#radio2').prop("disabled", false);
                 }
             }
             
          });
      });
    });
</script>

<script>
  function amount(){
     var f1 =document.getElementById("actual").value;
    var f2 =document.getElementById("feegiven").value;
    //alert(discount)
    var f3 = document.getElementById('pDiscount').value;
    var f4 = document.getElementById("pFeeGiven").value;
    //alert(price);
   var f = f1-f2-f3-f4;
   //const button = document.querySelector("saleButton");
   if(f < 0 ){ 
       alert("Given fees not exceed than total fees"); 
       $('#saleButton').prop('disabled', true);
   }else{
       $('#saleButton').prop('disabled', false);
   }
   //$('#feegiven').val(f);
    //alert(actual);
  }
</script>
<script>
  function display(){
    var discount =document.getElementById("discount").value;
    //alert(discount)
    var price = document.getElementById("priceInput").value;
    //alert(price);
  var actual = price - discount;
  $('#actual').val(actual);
    //alert(actual);
  }
</script>
<script>
  function remain(){
    var feea =document.getElementById("actual").value;
    //alert(discount)
    var feeg = document.getElementById("feegiven").value;
    
    var feeD = document.getElementById("pDiscount").value;
    
    var prePay = document.getElementById("pFeeGiven").value;
    //alert(price);
   var feeremain = feea - feeg - prePay - feeD;
   $('#feeremain').val(feeremain);
    //alert(actual);
  }
</script>

<script>
  function centive(){
    var feeg =document.getElementById("feegiven").value;
    var prec =document.getElementById("priceInput1").value;
    //alert(feeg);
    //var incen = 0.1;
    pce = prec/100;
    var incentive = feeg * pce;
    //alert(incentive);
   $('#incentive').val(incentive.toFixed());
    //alert(actual);
  }
</script>
<script>
  function centive1(){
    var feeg =document.getElementById("feegiven").value;
    var prec1 =document.getElementById("priceInput2").value;
    //alert(feeg);
    //var incen = 0.1;
    tce = prec1/100;
    var incentive1 = feeg * tce;
    //alert(incentive);
   $('#incentive1').val(incentive1.toFixed());
    //alert(actual);
  }
</script>
<script>
  function centive11(){
    var feeg =document.getElementById("feegiven").value;
    var prec11 =document.getElementById("priceInput11").value;
    //alert(feeg);
    //var incen = 0.1;
    tce = prec11/100;
    var incentive2 = feeg * tce;
    //alert(incentive);
   $('#incentive11').val(incentive2.toFixed());
    //alert(actual);
  }
</script>
<script>
  function ncd(){
    var f2 =document.getElementById("feeremain").value;
   if(f2 == 0 ){ document.getElementById("nc").style.display = 'none'; }
   //$('#feegiven').val(f);
    //alert(actual);
  }
</script>
<script type="text/javascript">
function custompopup(){  
let newWindow = window.open('<?php echo site_url() ?>Student/add', 'Add Student','width=600,height=600,target=popup');
window.onunload = refreshParent;
    function refreshParent() {
        window.opener.location.reload();
    }
}
</script>
