<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>PTMS</title>
  <!-- Tailwind CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css">
  <link rel="icon" type="image/png" href="https://propertytax.digicardmaker.co.in/public/favicon.ico">
  <!-- Select2 CSS -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.1.0/css/select2.min.css">
</head>
<body class="bg-gray-100">
<div class="min-h-screen flex justify-center items-center">
  <div class="max-w-md w-full mx-auto">
    <div class="bg-white p-8 rounded-lg shadow-lg">
        <img src="https://propertytax.digicardmaker.co.in/public/PTM.png" />
      <h1 class="text-2xl font-bold text-center mb-2"></h1>
      <form action="<?php echo site_url() ?>Login/auth" method="post">
        <div class="mb-4">
          <label for="userEmail" class="block text-gray-700 font-medium mb-2">Email</label>
          <input type="email" class="border border-gray-400 p-2 w-full rounded-lg" required name="userEmail" id="userEmail">
        </div>
        <div class="mb-4">
          <label for="userPassword" class="block text-gray-700 font-medium mb-2">Password</label>
          <input type="password" class="border border-gray-400 p-2 w-full rounded-lg" required name="userPassword" id="userPassword">
        </div>
        <div class="mb-4">
          <label for="userRole" class="block text-gray-700 font-medium mb-2">Select Role</label>
          <select class="border border-gray-400 p-2 w-full rounded-lg select2" required name="userRole" id="userRole">
            <option value="">Select Role</option>
            <option value="admin">Admin</option>
            <option value="mdLogin">MD Login</option>
            <option value="ari_role">ARI Role</option>
            <option value="aro_role">ARO Role</option>
            <option value="zone_commissioner">Zone Commissioner Role</option>
          </select>
        </div>
        <div class="mb-4 flex justify-between">
          <div>
            <input type="submit" class="bg-blue-500 text-white p-2 rounded-lg hover:bg-blue-600 cursor-pointer" name="login" value="Sign In">
          </div>
          
        </div>
        
      </form>
    </div>
  </div>
</div>
<!-- Select2 JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.1.0/js/select2.min.js"></script>
<!-- Initialize Select2 -->
<script>
  $(document).ready(function() {
    $('.select2').select2();
  });
</script>
</body>
</html>