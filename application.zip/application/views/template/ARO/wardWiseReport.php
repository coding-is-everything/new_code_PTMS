<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Ward Wise Report</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
            </ol>
          </div>

        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              
              <div class="card-header">
                
             <!-- Display status message -->
    <?php if(!empty($success_msg)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-success"><?php echo $success_msg; ?></div>
    </div>
    <?php }elseif(!empty($error_msg)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-danger"><?php echo $error_msg; ?></div>
    </div>
    <?php } ?>
              </div>
              <div class="card-body">
                  <?php if($this->session->userdata('roleType') === 'Admin'){ ?>
                  <form method="post" action="<?php echo site_url() ?>property/importCSV" enctype="multipart/form-data">
                  <div class="form-group">
                      <div class="row">
                          <div class="col-lg-6 col-md-6 col-sm-12">
                              <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Import Property Data</label>
                            <input type="file" class="form-control is-valid" name="importData" id="inputSuccess"/>
                          </div>
                          <div class="col-mg-6 col-md-6 col-sm-12">
                              <label class="col-form-label" for="inputSuccess">Submit</label><br/>
                              <button type="submit" name="importSubmit" class="btn btn-success is-valid">Import Data</button>
                          </div>
                      </div>
                  </div>
                  </form>
                  <?php } ?>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                  <table class="table table-bordered table-striped table-responsive" width="100%">
                      <thead>
                          <tr>
                              <th>
                                  Ward Details:
                              </th>
                              <th>
                                  <select name="ward" id="wardSelect" class="select2 form-control">
                                      <option value="">Select Ward</option>
                                      <?php 
                                        foreach($wards as $ward){
                                        ?>
                                        <option value="<?php echo $ward->id; ?>"><?php echo $ward->wardName."( ".$ward->wardId." )"; ?></option>
                                        <?php
                                        }
                                      ?>
                                  </select>
                              </th>
                          </tr>
                      </thead>
                  </table>
                  <div id="ajaxData">
                <table id="example1" class="table table-bordered table-striped table-responsive">
                  <thead class="bg-success">
                  <tr>
                    <th>Sr.No</th>
                    <th>Owner Name</th>
                    <th>Guardian Name</th>
                    <th>Zone Name</th>
                    <th>Ward Name</th>
                    <th>Parikshetra Number</th>
                    <th>Main road or internal road</th>
                    <th>Floor(SBA)</th>
                    <th>Type of property( Pucca, kaccha, ard pucca)</th>
                    <th>Property Id</th>
                    <th>ARI Audit Status</th>
                    <th>ARO Audit Status</th>
                    <th>Zone Commissioner Audit Status</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php
                    $sr = 1;
                    if(!empty($properties)){ foreach($properties as $prop) {
                    ?>
                    <tr>
                        <td><?php echo $sr++; ?></td>
                        <td><?php echo strtoupper($prop->owner_name); ?></td>
                        <td><?php echo strtoupper($prop->guardian_name); ?></td>
                        <td><?php echo $this->Ward_model->getZoneDetail($prop->zone_no)[0]->zoneName; ?></td>
                        <td><?php echo $this->Ward_model->getWardDetail($prop->ward_no)[0]->wardName; ?>( <?php echo $this->Ward_model->getWardDetail($prop->ward_no)[0]->wardId ?> )</td>
                        <td><?php echo !empty($prop->parikshetra_number)?$prop->parikshetra_number:'No Data'; ?></td>
                        <td><?php echo !empty($prop->road_type)?$prop->road_type:'No Data'; ?></td>
                        <td><?php echo !empty($prop->floor_SBA)?$prop->floor_SBA:'No Data'; ?></td>
                        <td><?php echo $prop->const_type; ?></td>
                        <td><?php echo $prop->new_pro_no ?></td>
                        <td><?php echo !empty($prop->ARI_audit_status)?$prop->ARI_audit_status:'Approval Pending From ARI'; ?></td>
                        <td><?php echo !empty($prop->ARO_audit_status)?$prop->ARO_audit_status:'Approval Pending From ARO'; ?></td>
                        <td><?php echo !empty($prop->ZC_audit_status)?$prop->ZC_audit_status:'Approval Pending From Zone Commissioner'; ?></td>
                        <td>
                      &nbsp;<?php if($this->session->userdata('roleId') == 1){ ?>
                        <a href="<?php echo site_url('Property/edit/'.$prop->id); ?>"><i class="fa fa-edit" style="font-size:20px"></i></a>&nbsp;
                      <?php }elseif($this->session->userdata('roleId') == 2){ ?>
                        <a href="<?php echo site_url('Ari/editProperty/'.$prop->id); ?>"><i class="fa fa-edit" style="font-size:20px"></i></a>&nbsp;
                      <?php }elseif($this->session->userdata('roleId') == 3){ ?>
                        <a href="<?php echo site_url('Aro/editProperty/'.$prop->id); ?>"><i class="fa fa-edit" style="font-size:20px"></i></a>&nbsp;
                      <?php }elseif($this->session->userdata('roleId') == 4){ ?>
                        <a href="<?php echo site_url('Zonecommissioner/editProperty/'.$prop->id); ?>"><i class="fa fa-edit" style="font-size:20px"></i></a>&nbsp;
                      <?php } ?>
                        <a href="<?php echo site_url('Property/delete/'.$prop->id); ?>" onclick="return confirm('Are you sure to delete?')"><i class="fa fa-trash" style="font-size:20px;"></i></a></td>
                    </tr>
                    <?php
                    }}
                    ?>
                  </tbody>
                </table>
                </div>
                 <div class="pagination pull-right">
            <?php echo $this->pagination->create_links(); ?>
        </div>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<script>
    $(document).ready(function() {
      $('#wardSelect').on('change', function(){
          var wardId = $('#wardSelect').val();
          var formData = "wardId="+wardId;
          $.ajax({
                 url: '<?=base_url()?>Aro/ajaxPropertyData',
                 method: "POST",
                 data: formData,
                 success: function(data) {
                    console.log(data);
                     $('#ajaxData').empty();
                     $('#ajaxData').html(data);
                     //$('#example1').dataTable().fnDestroy();
                     $("#example1").DataTable({
                         "destroy": true,
      "responsive": false, "lengthChange": true, "autoWidth": true,
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
                 }
                 
              });
      });
    });
</script>