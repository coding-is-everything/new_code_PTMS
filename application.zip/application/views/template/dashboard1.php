<!DOCTYPE html>


      <div class="flex-1 p-8">
        <div class="flex flex-wrap">
            <div class="w-full sm:w-1/2 md:w-1/4 xl:w-1/4 p-3">
                <div class="bg-green-500 hover:bg-green-700 text-white text-center h-full rounded">
                    <div class="text-3xl font-light pt-3"><i class="mdi mdi-home-modern"></i></div>
                    <div class="text-white text-lg pb-3">Total Approved Audit Done</div>
                    <a href="#">
                        <div class="text-white text-lg pb-3">
                            (<span class="count">585</span>)
                        </div>
                    </a>
                </div>
            </div>
            
            <div class="w-full sm:w-1/2 md:w-1/4 xl:w-1/4 p-3">
                <div class="bg-gray-500 hover:bg-gray-700 text-white text-center h-full rounded">
                    <div class="text-3xl font-light pt-3"><i class="mdi mdi-home-modern"></i></div>
                    <div class="text-white text-lg pb-3">ARI Validated</div>
                    <a href="#">
                        <div class="text-white text-lg pb-3">
                            (<span class="count">3</span>)
                        </div>
                    </a>
                </div>
            </div>
            
            <div class="w-full sm:w-1/2 md:w-1/4 xl:w-1/4 p-3">
                <div class="bg-purple-500 hover:bg-purple-700 text-white text-center h-full rounded">
                    <div class="text-3xl font-light pt-3"><i class="mdi mdi-home-modern"></i></div>
                    <div class="text-white text-lg pb-3">Pending ARI validation</div>
                    <a href="#">
                        <div class="text-white text-lg pb-3">
                            (<span class="count">582</span>)
                        </div>
                    </a>
                </div>
            </div>
            
            <div class="w-full sm:w-1/2 md:w-1/4 xl:w-1/4 p-3">
                <div class="bg-red-500 hover:bg-red-700 text-white text-center h-full rounded">
                    <div class="text-3xl font-light pt-3"><i class="mdi mdi-bookmark-remove"></i></div>
                    <div class="text-white text-lg pb-3">ARI Rejected Properties</div>
                    <a href="#">
                        <div class="text-white text-lg pb-3">
                            (<span class="count">0</span>)
                        </div>
                    </a>
                </div>
            </div>
            <br/><br/>
            <div class="row">
                <div class="col-md-12 col-lg-12 col-xlg-12">
                    <h3 class="text-2xl font-bold mb-4">Active Ward Survey Map - Bilaspur City</h3>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 col-lg-12 col-xlg-12">
                    <table id="example1" class="table table-stripped">
                        <thead>
                            <tr>
                                <th>Zone No</th>
                                <th>Ward No</th>
                                <th>Audit Done</th>
                                <th>Details</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Zone : 1</td>
                                <td>Ward no : 1</td>
                                <td>585</td>
                                <td><button class="btn btn-success">View Ward List</button></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
      </div>
    </div>
  </body>
</html>
