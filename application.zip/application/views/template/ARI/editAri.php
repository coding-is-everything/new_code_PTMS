<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Edit ARI</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active"><a href="<?php echo site_url() ?>Ari/manageAri"><i class="fas fa-folder">&nbsp;Manage ARI</i></a></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- right column -->
          <div class="col-md-12">
            <!-- Form Element sizes -->
                   <!-- general form elements disabled -->
            <div class="card card-warning">
              <div class="card-header">
                <h3 class="card-title">Edit ARI</h3>
              </div>
              <!-- /.card-header -->
              <!-- Display status message -->
    <?php if(!empty($success_msg)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-success"><?php echo $success_msg; ?></div>
    </div>
    <?php }elseif(!empty($error_msg)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-danger"><?php echo $error_msg; ?></div>
    </div>
    <?php } ?>
              <div class="card-body">
                <form method="post" action="<?php echo site_url() ?>Ari/edit/<?php echo $id ?>">
                  <!-- input states -->
                 <div class="form-group">
                  <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> ARI Name</label>
                  <input type="text" autocomplete="off" class="form-control is-valid" name="ARIName" id='inputSuccess' placeholder="Enter ARI Name" value="<?php echo !empty($_POST['ARIName'])?$_POST['ARIName']:$ari[0]->ARIName; ?>">
                  <?php echo form_error('ARIName','<div style="color:red;">','</div>'); ?>
                </div>
                 <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> ARI Email</label>
                    <input type="text" autocomplete="off" class="form-control is-valid" name="ARIEmail" id="inputSuccess" placeholder="Enter ARI Email" value="<?php echo !empty($_POST['ARIEmail'])?$_POST['ARIEmail']:$ari[0]->ARIEmail; ?>">
                     <?php echo form_error('ARIEmail','<div style="color:red;">','</div>'); ?>
                  </div>
                     <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> ARI Mobile</label>
                    <input type="number" autocomplete="off" class="form-control is-valid" name="ARIPhone" id="inputSuccess" placeholder="Enter the ARI Phone Number" value="<?php echo !empty($_POST['ARIPhone'])?$_POST['ARIPhone']:$ari[0]->ARIPhone; ?>">
                     <?php echo form_error('ARIPhone','<div style="color:red;">','</div>'); ?>
                  </div>
                     <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> ARI Zone</label>
                    <select  class="form-control select2" style="width: 100%;" name="ARIZoneNo" id="inputSuccess">
                        <option selected>Select Zone Number</option>
                        <?php
                        foreach($zoneDetail as $zone) {
                        ?>
                        <option <?php if($ari[0]->ARIZoneNo == $zone->id){ ?>selected<?php } ?> value="<?php echo $zone->id; ?>"><?php echo $zone->zoneName; ?></option>
                        <?php
                        }
                        ?>
                    </select>
                     <?php echo form_error('ARIZoneNo','<div style="color:red;">','</div>'); ?>
                  </div>
                  <div class="form-group">
                      <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> ARI Ward</label>
                      <select class="form-control select2" style="width: 100%;" name="ARIWardNo" id="inputSuccess">
                          <option selected>Select Ward Name</option>
                          <?php
                          foreach($wardDetail as $ward) {
                            ?>
                            <option <?php if($ari[0]->ARIWardNo == $ward->id){ ?>selected<?php } ?> value="<?php echo $ward->id ?>"><?php echo $ward->wardName; ?>( <?php echo $ward->wardId ?> )</option>
                            <?php
                          }
                          ?>
                      </select>
                  </div>
                <!-- radio -->
                    <div class="form-group clearfix">
                      <div class="icheck-primary d-inline">
                        <input <?php if($ari[0]->status == 1){ ?>checked<?php } ?> type="radio" id="radioPrimary1" name="status" value="1">
                        <label for="radioPrimary1">Active
                        </label>
                      </div>
                      <div class="icheck-primary d-inline">
                        <input <?php if($ari[0]->status == 0){ ?>checked<?php } ?> type="radio" id="radioPrimary2" name="status" value="0">
                        <label for="radioPrimary2">Inactive
                        </label>
                      </div>
                       <?php echo form_error('userStatus','<div style="color:red;">','</div>'); ?>
                    </div>
                 <div class="card-footer">
                  <input type="submit" class="btn btn-primary" name="userSubmit" value="Submit">
                  <a href="<?php echo site_url('User/user_tab'); ?>" class="btn btn-secondary">Back</a>
                </div>
                </form>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <script type="text/javascript">
    function ShowHideDiv(chkPassport) {
        var dvPassport = document.getElementById("dvPassport");
        dvPassport.style.display = chkPassport.checked ? "block" : "none";
    }
</script>
<script type="text/javascript">
  document.getElementById('name').value = "<?php echo $_POST['roleType'];?>";
  document.getElementById('name1').value = "<?php echo $_POST['incecntivePer'];?>";
  document.getElementById('name2').value = "<?php echo $_POST['teamLeadName'];?>";
</script>