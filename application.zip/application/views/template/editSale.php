<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Update Sale</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active"><a href="<?php echo site_url() ?>Sale/sale_tab"><i class="fas fa-folder">&nbsp;Manage Sales</i></a></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- right column -->
          <div class="col-md-12">
            <!-- Form Element sizes -->
                   <!-- general form elements disabled -->
            <div class="card card-warning">
              <div class="card-header">
                <h3 class="card-title">Update Sale</h3>
              </div>
              <!-- /.card-header -->
              <!-- Display status message -->
    <?php if(!empty($success_msg)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-success"><?php echo $success_msg; ?></div>
    </div>
    <?php }elseif(!empty($error_msg)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-danger"><?php echo $error_msg; ?></div>
    </div>
    <?php } ?>
              <div class="card-body">
                <form method="post" action="<?php echo site_url() ?>Sale/edit/<?php echo $sale['saleId']; ?>/<?php echo $sale['mode']; ?>/<?php echo $sale['checked']; ?>" enctype='multipart/form-data'>
                  <?php //echo $sale['saleId']; print_r($sale);//exit(); ?> 
                  <!-- input states -->
                     <div class="form-group clearfix">
                      <div class="icheck-primary d-inline">
                        <input type="radio" id="radio1" name="mode" value="direct" <?php if($sale['mode']=="direct"){ ?> checked <?php }else{ " ";?> <?php } ?> onclick="show1();">
                        <label for="radio1">Direct Sale
                        </label>
                      </div>
                      <div class="icheck-primary d-inline">
                        <input type="radio" id="radio2" name="mode" value="indirect" <?php if($sale['mode']=="indirect"){ ?> checked <?php }else{ " ";?> <?php } ?> onclick="show1();">
                        <label for="radio2">Indirect Sale
                        </label>
                      </div>
                      <div class="icheck-primary d-inline">
                          <input type="radio" id="radio3" name="mode" value="no claim" <?php if($sale['mode'] == "no claim"){ ?> checked <?php }else{ " "; ?><?php } ?> onclick="show1();">
                          <label for="radio3">No Claim</label>
                      </div>
                       <?php echo form_error('mode','<div style="color:red;">','</div>'); ?>
                    </div>
                 <div class="form-group">
                  <label>Batch</label>
                  <select id="selectoption"  class="form-control" style="width: 100%;" name="batchId" onchange="show();">
                     <?php 
                        foreach($batches as $row)
                        { 
                          if($row->batchId == $sale['batchId'] ){?>
                         <option data-price="<?php echo $row->coursePrice?>" selected="true" value="<?php echo $row->batchId?>"><?php echo $row->batchName?></option>
                       <?php }else { ?><option data-price="<?php echo $row->coursePrice?>"  value="<?php echo $row->batchId?>"><?php echo ucfirst($row->batchName)?></option>
                       <?php }}?>
                  </select>
                  <?php echo form_error('batchId','<div style="color:red;">','</div>'); ?>
                </div>
                <div class="form-group">
                          <input class="customCheckbox2" onclick="show1();"  type="checkbox" name="checked" id="tpe" value="1" <?php if($sale['checked']=="1"){ ?> checked <?php }else{ " ";?> <?php } ?>>
                          <label for="customCheckbox2">Split Sales Between Sales Representatives</label>
                        </div>
                 <div class="form-group">
                  <label>Sales representatives</label>
                   <select id="selectoption1"  class="form-control select2" style="width: 100%;" name="userId" onchange="show1();">
                    <?php 
                        foreach($users as $row)
                        { if($row->userId == $sale['userId'] ){?>
                         <option selected="true" data-price="<?php echo $row->incecntivePer?>" data-price1="<?php echo $row->teamLeadPer?>" value="<?php echo $row->userId?>"><?php echo $row->userName?></option>
                       <?php } else {?><option data-price="<?php echo $row->incecntivePer?>" data-price1="<?php echo $row->teamLeadPer?>"  value="<?php echo $row->userId?>"><?php echo $row->userName?></option>
                         <?php }}?>
                  </select>
                  <?php echo form_error('userId','<div style="color:red;">','</div>'); ?>
                </div>
                  <div class="form-group">
                  <label>Student</label>
                  <select id="selectoption2" class="form-control select2" style="width: 100%;" name="studentId">
                    <?php 
                        foreach($students as $row)
                        { 
                          if($row->studentId == $sale['studentId'] ){?>
                         <option selected="true" value="<?php echo $row->studentId?>"><?php echo $row->studentName?></option>
                       <?php }else { ?><option  value="<?php echo $row->studentId?>"><?php echo $row->studentName?></option>
                       <?php }}?>
                  </select>
                  <?php echo form_error('studentId','<div style="color:red;">','</div>'); ?>
                </div>
                  <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Course Commited</label>
                      <input type="text" class="form-control" name="price" id="priceInput" readonly value="<?php echo !empty($sale['price'])?$sale['price']:''; ?>">
                  </div>
                   <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Discount(in amount)</label>
                    <input type="text"  class="form-control is-valid" name="courseDiscount"  id="discount" value="<?php echo !empty($sale['courseDiscount'])?$sale['courseDiscount']:''; ?>">
                  </div>
                   <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Actual Course Fees</label>
                    <input type="text" class="form-control is-valid" name="coursePriceCommited" id="actual" onmouseleave="display();" readonly value="<?php echo !empty($sale['coursePriceCommited'])?$sale['coursePriceCommited']:''; ?>">
                  </div>              
                     <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Course Fees Given</label>
                    <input type="text" class="form-control is-valid" onkeyup="amount();" name="couesePriceGiven" id="feegiven" value="<?php echo !empty($sale['couesePriceGiven'])?$sale['couesePriceGiven']:''; ?>" >
                    <?php echo form_error('couesePriceGiven','<div style="color:red;">','</div>'); ?>
                  </div>
                   <div class="form-group">
                      <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Previous Discount</label>
                      <input type="text" readonly class="form-control is-valid" id="pDiscount" placeholder="Previous Payment Discount" autocomplete="off" value="" />
                  </div>
                   <div class="form-group">
                      <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Previous Course Fee Given</label>
                      <input type="text" readonly class="form-control is-valid" name="coursePricePre" id="pFeeGiven" placeholder="Previous Payment Here" autocomplete="off" value="<?php echo !empty($sale['coursePricePre'])?$sale['coursePricePre']:''; ?>">
                  </div>
                  <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Course Fees Remain</label>
                    <input type="text" class="form-control is-valid" name="coursePriceRemain" id="feeremain" onmouseleave="remain();ncd();" readonly value="<?php echo !empty($sale['coursePriceRemain'])?$sale['coursePriceRemain']:''; ?>">
                  </div>
                <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Course Incentive Percentage</label>
                      <input type="text" class="form-control" name="courseIncentivePer" id="priceInput1" readonly value="<?php echo !empty($sale['courseIncentivePer'])?$sale['courseIncentivePer']:''; ?>">
                  </div>
                    <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Course Incentive</label>
                      <input type="text" class="form-control" name="courseIncentive" id="incentive" onmouseleave="centive();" readonly value="<?php echo !empty($sale['courseIncentive'])?$sale['courseIncentive']:''; ?>">
                  </div>
                 <div id="original" style="display:none;">
                  <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Course Incentive Percentage(Team Lead)</label>
                      <input type="text" class="form-control" name="courseIncentivePerTeam" id="priceInput2" readonly value="<?php echo !empty($_POST['courseIncentivePerTeam'])?$_POST['courseIncentivePerTeam']:''; ?>">
                  </div>
                    <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Course Incentive Amount(Team Lead)</label>
                      <input type="text" class="form-control" name="courseIncentiveTeam" id="incentive1" onmouseleave="centive1();" readonly value="<?php echo !empty($_POST['courseIncentiveTeam'])?$_POST['courseIncentiveTeam']:''; ?>">
                  </div>
           </div>
                
                  <div id="doing" style=<?php if($sale['checked']=='1') { ?> "display: block;" <?php } else { ?> "display: none;" <?php } ?>>
               <div class="form-group">
                  <label>Sales representatives</label>
                  <select id="selectoption3"  class="form-control select2" style="width: 100%;" name="uId" onchange="show2();" >
                    <option value="" data-price="">--Select Sales Representative--</option>
                    <?php 
                        foreach($users as $row)
                        { if($row->userId == $sale['uId'] ){?>
                         <option selected="true" data-price="<?php echo $row->incecntivePer?>" value="<?php echo $row->userId?>"><?php echo $row->userName?></option>
                       <?php } else {?><option data-price="<?php echo $row->incecntivePer?>"  value="<?php echo $row->userId?>"><?php echo $row->userName?></option>
                         <?php }}?>
                  </select>
                  <?php //echo form_error('userId','<div style="color:red;">','</div>'); ?>
                </div>
                  <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Course Incentive Percentage(SR)</label>
                      <input type="text" class="form-control" name="incentivePerSR" id="priceInput11" readonly value="<?php echo !empty($sale['incentivePerSR'])?$sale['incentivePerSR']:''; ?>">
                  </div>
                    <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Course Incentive Amount(SR)</label>
                      <input type="text" class="form-control" name="incentiveAmtSR" id="incentive11" onmouseleave="centive11();" readonly value="<?php echo !empty($sale['incentiveAmtSR'])?$sale['incentiveAmtSR']:''; ?>">
                  </div>
                </div>
                   <div class="col-md-6">
                  <label>Transaction Date:</label>
                    <div class="input-group date" id="reservationdate2" data-target-input="nearest">
                        <input type="text" name="transactionDate" class="form-control datetimepicker-input" data-target="#reservationdate2" value="<?php echo !empty($sale['transactionDate'])?$sale['transactionDate']:''; ?>" />
                        <div class="input-group-append" data-target="#reservationdate2" data-toggle="datetimepicker">
                            <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                        </div>
                    </div>
                    <?php echo form_error('transactionDate','<div style="color:red;">','</div>'); ?>
                <div class="form-group" id="nc">
                  <label>Next Commited Date:</label>
                    <div class="input-group date" id="reservationdate3" data-target-input="nearest">
                        <input type="text" name="nextCommitedDate" class="form-control datetimepicker-input" value="<?php echo !empty($sale['nextCommitedDate'])?$sale['nextCommitedDate']:''; ?>" data-target="#reservationdate3"/>
                        <div class="input-group-append" data-target="#reservationdate3" data-toggle="datetimepicker">
                            <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                        </div>
                    </div>
                    <?php echo form_error('nextCommitedDate','<div style="color:red;">','</div>'); ?>
                </div>
              </div>
                   <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Screenshot Upload</label>
                    <input type="file" class="form-control is-valid" name="screenShot" id="inputSuccess"><img src="<?php echo base_url() ?>public/admin/screenshot/<?php echo $sale['screenShot'] ?>" style="height: 50px; width: 100px;margin-top: 15px;">
                  </div>
                  <div class="form-group">
                    <label class="col-form-label" for="inputSuccess"><i class="fas fa-check"></i> Notes</label>
                    <textarea class="form-control is-valid" name="details" id="inputSuccess" placeholder="Enter the Detail"><?php echo !empty($sale['details'])?$sale['details']:''; ?></textarea>
                  </div>
                <!-- radio -->
                    <div class="form-group clearfix">
                      <div class="icheck-primary d-inline">
                        <input type="radio" id="radioPrimary1" name="saleStatus" value="1" <?php 
    echo set_value('saleStatus', $sale['saleStatus']) == 1 ? "checked" : "";?>>
                        <label for="radioPrimary1">Active
                        </label>
                      </div>
                      <div class="icheck-primary d-inline">
                        <input type="radio" id="radioPrimary2" name="saleStatus" value="0" <?php 
    echo set_value('saleStatus', $sale['saleStatus']) == 0 ? "checked" : ""; 
?>>
                        <label for="radioPrimary2">Inactive
                        </label>
                      </div>
                       <?php echo form_error('saleStatus','<div style="color:red;">','</div>'); ?>
                    </div>
                 <div class="card-footer">
                  <input type="submit" class="btn btn-primary" name="saleSubmit" value="Submit">
                  <a href="<?php echo site_url('Sale/sale_tab'); ?>" class="btn btn-secondary">Back</a>
                </div>
                </form>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
   <script>
       $(document).ready(function(){
      $('#feegiven').keyup(function(){
         remain();
         ncd();
         centive();
         centive1();
         centive11();
      });
      $('#feegiven').keydown(function(){
         remain();
         ncd();
         centive();
         centive1();
         centive11();
      });
  });
   $(document).ready(function(){
            $('#discount').on('keyup', function(){
              var discount = $(this).val();
              var pdiscount = $('#pDiscount').val();
              var pgiven =$('#pFeeGiven').val();
              var price = $('#priceInput').val();
              var actual = price - discount -pgiven - pdiscount;
              $('#actual').val(actual);
              $('#feeremain').val(actual);
              
          });
          $('#discount').on('keydown', function(){
              display();
          });
      });
   </script>
<script type="text/javascript">
$(document).ready(function(){  
$("#doing").hide();
$("#tpe").click(function() {
    if($(this).is(":checked")) {
        $("#doing").show();
        $("#original").hide();
    } else  {
    	if($("#radio2").is(":checked")) {
        $("#doing").hide();
        $("#original").hide();
    }
    else{
     $("#doing").hide();
        $("#original").show();
    
    }
    }
});
});
</script>
<script type="text/javascript">
function checkMode() {
var mode = '<?php echo $mode; ?>';
var checked = '<?php echo $checked; ?>';
if(mode == 'direct' && checked == 0){
$("#doing").hide(); 
$("#original").show(); 
}else if(mode == 'direct' && checked == 1){
$("#original").hide(); 
$("#doing").show(); 
}else if(mode == 'indirect' && checked == 0){
$("#original").hide(); 
$("#doing").hide();
}else{
$("#original").hide(); 
$("#doing").show(); 
}
}

</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){ 
//$("#original").hide(); 
$("#radio2").click(function() {
    if($(this).is(":checked")) {
      //alert("Hi");
      if($("#tpe").is(":checked")){
        $("#original").hide();
        $("#doing").show();
        show2();
        centive();
        centive11();
        centive1();
    } 
    else{
    //alert("Hello");
    $("#original").hide();
        $("#doing").hide();
        centive();
        centive11();
        centive1();
    
    }
    }
    
});
$("#radio1").click(function() {
        if($(this).is(":checked")) {
      //alert("Hi");
      if($("#tpe").is(":checked")){
        $("#original").hide();
        $("#doing").show();
        show2();
        centive();
        centive11();
        centive1();
    } 
    else{
    $("#original").show();
        $("#doing").hide();
        centive();
        centive11();
        centive1();
    
    }
    }
});
});
</script>

   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<script>
  let show = () => {
    let element = document.getElementById("selectoption");
    let price = element.options[element.selectedIndex].getAttribute("data-price");
    //alert("Price: " + price);
    $('#priceInput').val(price);

  }
</script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<script>
  let show = () => {
    let element = document.getElementById("selectoption");
    let price = element.options[element.selectedIndex].getAttribute("data-price");
    //alert("Price: " + price);
    $('#priceInput').val(price);

  }
</script>
<script>
 function show1()  {
    let element = document.getElementById("selectoption1");
    let percent = element.options[element.selectedIndex].getAttribute("data-price");
    let team = element.options[element.selectedIndex].getAttribute("data-price1");
    //alert("Price: " + percent);
    let pce = "";
    let tce ="";

    if($('#radio1').is(":checked"))
    {
      if($('#radio1').is(":checked") && $('#tpe').is(":checked")){
       pce = (percent *100)/2;
      }else{
      pce = percent *100;
      tce = team *100;
      }
      }else if($('#radio2').is(":checked")){
        if($('#radio2').is(":checked") && $('#tpe').is(":checked")){
            pce = ((percent *100)/2)/2;
            // centive();
        }else{
            pce = (percent *100)/2;
            // centive();
        }
      }else{
         if($('#radio3').is(":checked") && $('#tpe').is(":checked")){
             pce = 0;
         }
      }

      /*
     if($('#radio2').is(":checked"))
     {
      pce = (percent *100)/2;
     }
     else
     {
      pce = percent *100;
      tce = team *100;
     }
     if($('#radio1').is(":checked") && $('#tpe').is(":checked"))
     {
      //alert("HI");
      pce = (percent *100)/2;
       //alert(pce);
     }
     else
     {
      alert("Hello");
      pce = percent *100;
      tce = team *100;
     }
     if($('#radio2').is(":checked") && $('#tpe').is(":checked"))
     {
      pce = ((percent *100)/2)/2;
     }
     else
     {
      pce = percent *100;
      tce = team *100;
     }*/
    // let TLId = <?php //echo $this->Incentive_model->checkTL(10) ?>;
    $('#priceInput1').val(pce);
    $('#priceInput2').val(tce);
    // $('#TLId').val(TLId);

  }
//   $(document).ready(function(){
//       $('#feegiven').keyup(function(){
         
//       });
//   });
</script>
<script>
 function show2()  {
    let element11 = document.getElementById("selectoption3");
    let percent11 = element11.options[element11.selectedIndex].getAttribute("data-price");
    //alert("Price: " + price);
    let pce11="";
      if($('#tpe').is(":checked"))
      {
     pce11 = (percent11 *100)/2;
       }
        if($('#radio1').is(":checked") && $('#tpe').is(":checked"))
       {
        pce11 = (percent11 *100)/2;
       }
       if($('#radio2').is(":checked") && $('#tpe').is(":checked"))
       {
        pce11 = ((percent11 *100)/2)/2;

       }
    
    // let TLId = <?php //echo $this->Incentive_model->checkTL(10) ?>;
    $('#priceInput11').val(pce11);
    // $('#TLId').val(TLId);

  }
</script>
<script>
    $(document).ready(function(){
       $('#selectoption2').on('change', function(){
          var batchId = $('#selectoption').val();
          var studentId = $(this).val();
          var formData = "batchId="+batchId+"&studentId="+studentId;
          $.ajax({
             url: '<?=base_url()?>/Sale/ajaxCall',
             method: "POST",
             data: formData,
             success: function(data) {
                 var data1 = $.parseJSON(data);
                 $('#pFeeGiven').val(data1.pFee);
                 $('#pDiscount').val(data1.CD);
             }
             
          });
       });
       $('#selectoption2').on('change', function(){
          var batchId = $('#selectoption').val();
          var studentId = $(this).val();
          var formData = "batchId="+batchId+"&studentId="+studentId;
          $.ajax({
             url: '<?=base_url()?>/Sale/ajaxCallDI/'+batchId+'/'+studentId,
             method: "POST",
             data: formData,
             success: function(data) {
                //  alert('This Student Have last mode is : '+data+' kindly select accordingly.');
                 if(data == 'direct') {
                    //  alert(data);
                     $('#radio1').attr('checked', true);
                     $('#radio2').prop("disabled", true);
                 }else if(data == 'indirect') {
                    //  alert(data+'2');
                      $('#radio2').attr('checked', true);
                      $('#radio1').prop("disabled", true);
                 }else{
                    //  alert(data+'1');
                      $('#radio1').attr('checked', true);
                     $('#radio2').prop("disabled", false);
                 }
             }
             
          });
      });
    });
</script>
<script>
  function amount(){
     var f1 =document.getElementById("actual").value;
    var f2 =document.getElementById("feegiven").value;
    //alert(discount)
    var f3 = document.getElementById('pDiscount').value;
    var f4 = document.getElementById("pFeeGiven").value;
    //alert(price);
   var f = f1-f2-f3-f4;
   if(f < 0 ){ alert("Given fees not exceed than total fees"); }
   //$('#feegiven').val(f);
    //alert(actual);
  }
</script>
<script>
  function display(){
    var discount =document.getElementById("discount").value;
    //alert(discount)
    var price = document.getElementById("priceInput").value;
    //alert(price);
   var actual = price - discount;
   $('#actual').val(actual);
    //alert(actual);
  }
</script>
<script>
  function remain(){
    var feea =document.getElementById("actual").value;
    //alert(discount)
    var feeg = document.getElementById("feegiven").value;
    var feeD = document.getElementById("pDiscount").value;
    var peeg = document.getElementById("pFeeGiven").value;
    //alert(price);
   var feeremain = feea - feeg - peeg - feeD;
   $('#feeremain').val(feeremain);
    //alert(actual);
  }
</script>
<script>
  function centive(){
    var feeg =document.getElementById("feegiven").value;
    var prec =document.getElementById("priceInput1").value;
    pce = prec/100;
    var incentive = feeg * pce;
   $('#incentive').val(incentive.toFixed());
  }
</script>
<script>
  function centive1(){
    var feeg =document.getElementById("feegiven").value;
    var prec1 =document.getElementById("priceInput2").value;
    tce = prec1/100;
    var incentive1 = feeg * tce;
   $('#incentive1').val(incentive1.toFixed());
  }
</script>
<script>
  function centive11(){
    var feeg =document.getElementById("feegiven").value;
    var prec11 =document.getElementById("priceInput11").value;
    tce = prec11/100;
    var incentive2 = feeg * tce;
   $('#incentive11').val(incentive2.toFixed());
  }
</script>
<script>
  function ncd(){
    var f2 =document.getElementById("feeremain").value;
   if(f2 == 0 ){ document.getElementById("nc").style.display = 'none'; }
   //$('#feegiven').val(f);
    //alert(actual);
  }
</script>

