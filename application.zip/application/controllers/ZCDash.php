<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ZCDash extends CI_Controller {

public function __construct(){
		parent::__construct();
		$this->load->model(['Admin_model', 'Incentive_model', 'Batch_model', 'Crm_leads_model', 'Property_model', 'Ward_model']);
		if($this->session->userdata('logged_in')!= TRUE){
			redirect('Login');
		}
	}
	public function index()
	{
		
		if($this->session->userdata('roleId') === '4')
		{	
		    $wardId = $this->Property_model->getZoneId($this->session->userdata('userId'));
		    $data = array();
		    $data['totalProperty'] = $this->Property_model->totalPropertyARO($wardId);
    		$data['approvedProperty'] = $this->Property_model->approvedPropertyARO($wardId);
    		$data['rejectedProperty'] = $this->Property_model->rejectedPropertyARO($wardId);
    		$data['property'] = $this->Property_model->getPropertyARI($wardId);
    		$this->load->view('template/includes/header');	
    		$this->load->view('template/homePage/dashboard', $data);
    		$this->load->view('template/includes/footer');
		}
		else{
			echo "Access Denied!"; 
		}
	}


}