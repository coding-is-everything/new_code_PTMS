<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ward extends CI_Controller {

public function __construct(){
		parent::__construct();
		if($this->session->userdata('logged_in')!= TRUE){
			redirect('Login');
		}
		$this->load->model('Ward_model');
	}
	public function index()
	{
	    $data = array();
	    $data['wardDetails'] = $this->Ward_model->getAllWards();
		$this->load->view('template/includes/header');
		$this->load->view('template/Ward/manageWard', $data);
		$this->load->view('template/includes/footer');
	}
	
	public function view($id){
	    if(!empty($id)){
    	    $data = array();
    	    $data['ward'] = $this->Ward_model->getWardDetail($id);
    	    $this->load->view('template/includes/header');
    	    $this->load->view('template/Ward/viewWard', $data);
    	    $this->load->view('template/includes/footer');
	    }
	}
	
	public function delete($id){
        // Check whether course id is not empty
        if($id){
            // Delete course
            // $this->db->where('id', $id);
            // $this->db->delete('ward_table');
            $ward_table = $this->db->update('ward_table', array('deleteStatus' => 1, 'deletedAt' => date('Y-m-d H:i:s')), array('id' => $id));
            if($ward_table){
                $this->session->set_userdata('success_msg', 'Ward has been removed successfully.');
            }else{
                $this->session->set_userdata('error_msg', 'Some problems occured, please try again.');
            }
        }
        
        // Redirect to the list page
        redirect('Ward/index');
    }


}