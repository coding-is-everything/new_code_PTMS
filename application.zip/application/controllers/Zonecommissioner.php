<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Zonecommissioner extends CI_Controller {
    
function __construct() {
        parent::__construct();
        
        // Load member model
        $this->load->model('User_model');
        $this->load->model('Ward_model');
        // Load form helper and library
        $this->load->helper('form');
        $this->load->library('form_validation');
        
        // Load pagination library
        $this->load->library('pagination');
        
    }

	public function manageZC(){ 

	$data = array();
        
        // Get messages from the session
        if($this->session->userdata('success_msg')){
            $data['success_msg'] = $this->session->userdata('success_msg');
            $this->session->unset_userdata('success_msg');
        }
        if($this->session->userdata('error_msg')){
            $data['error_msg'] = $this->session->userdata('error_msg');
            $this->session->unset_userdata('error_msg');
        }
        $data['ZCDetails'] = $this->Ward_model->getAllZC();
        // Load the list page view
        $this->load->view('template/includes/header');
		$this->load->view('template/ZC/manageZC',$data);
		$this->load->view('template/includes/footer'); 
}

public function view($id){
        $data = array();
        
        // Check whether member id is not empty
        if(!empty($id)){
            $data['ZC'] = $this->Ward_model->getZCDataBasedOnId($id);
            // Load the details page view
            $this->load->view('template/includes/header');
			$this->load->view('template/ZC/viewUser',$data);
			$this->load->view('template/includes/footer');
        }else{
            redirect('User/user_tab');
        }
    }

    public function add(){
        $data = array();
        $userData = array();
        // $data['wardDetail'] = $this->Ward_model->getAllWards();
        $data['zoneDetail'] = $this->Ward_model->getAllZones();
        
        // If add request is submitted
        if($this->input->post('userSubmit')){
            // Form field validation rules
            $this->form_validation->set_rules('ZCName','Zone Commissioner Name','required|trim');
            $this->form_validation->set_rules('ZCPhone', 'Zone Commissioner Phone', 'required|trim');
            $this->form_validation->set_rules('ZCEmail', 'Zone Commissioner Email', 'required|trim');
            $this->form_validation->set_rules('userPassword', 'user password', 'required|trim');
            $this->form_validation->set_rules('ZCZoneNo', 'Zone Commissioner Zone', 'required|trim');
            // $this->form_validation->set_rules('ARIWardNo', 'ARI Ward', 'required|trim');
            $this->form_validation->set_rules('status', 'user status', 'required|trim');
            // Prepare course data
            $userData = array(
                'roleId'=> 4,
                'userName' => $this->input->post('ZCName'),
                'userMobile' => $this->input->post('ZCPhone'),
                'userEmail'=> $this->input->post('ZCEmail'),
                'userPassword' => base64_encode($this->input->post('userPassword')),
                'roleType'=> 'Zone Commissioner',
                'createdDate' => date('Y-m-d H:i:s')
            );
            
            // Validate submitted form data
            if($this->form_validation->run() == true){
                // Insert member data
                $insert = $this->User_model->insert($userData);
                $ARIData = array(
                    'userId' => $this->db->insert_id(),
                    'ZCName' => $this->input->post('ZCName'),
                    'ZCPhone' => $this->input->post('ZCPhone'),
                    'ZCEmail' => $this->input->post('ZCEmail'),
                    // 'ARIWardNo' => $this->input->post('ARIWardNo'),
                    'ZCZone' => $this->input->post('ZCZoneNo'),
                    'status' => 1
                );
                $this->db->insert('zone_commissioner_table', $ARIData);
                if($insert){
                    $this->session->set_userdata('success_msg', 'Zone Commissioner has been added successfully.');
                    redirect('Zonecommissioner/manageZC');
                }else{
                    $data['error_msg'] = 'Some problems occured, please try again.';
                }
            }
        }
        
        $data['user'] = $userData;
        
        // Load the add page view
        	$this->load->view('template/includes/header');
			$this->load->view('template/ZC/addZC',$data);
			$this->load->view('template/includes/footer');
        
    }

public function edit($id){
        $data = array();
        // Get course data
        $userData = $this->User_model->getRows(array('userId' => $id));
        $data['ZC'] = $this->Ward_model->getZCDataBasedOnId($id);
        $data['wardDetail'] = $this->Ward_model->getAllWards();
        $data['zoneDetail'] = $this->Ward_model->getAllZones();
        $data['id'] = $id;
        if($this->input->post('userSubmit')){
            // Form field validation rules
            $this->form_validation->set_rules('ZCName','Zone Commissioner Name','required|trim');
            $this->form_validation->set_rules('ZCPhone', 'Zone Commissioner Phone', 'required|trim');
            $this->form_validation->set_rules('ZCEmail', 'Zone Commissioner Email', 'required|trim');
            // $this->form_validation->set_rules('userPassword', 'user password', 'required|trim');
            $this->form_validation->set_rules('ZCZone', 'Zone Commissioner Zone', 'required|trim');
            // $this->form_validation->set_rules('ARIWardNo', 'ARI Ward', 'required|trim');
            $this->form_validation->set_rules('status', 'user status', 'required|trim');
            // Prepare course data
            $userData = array(
                'roleId'=> 4,
                'userName' => $this->input->post('ZCName'),
                'userMobile' => $this->input->post('ZCPhone'),
                'userEmail'=> $this->input->post('ZCEmail'),
                // 'userPassword' => base64_encode($this->input->post('userPassword')),
                'roleType'=> 'Zone Commissioner',
                'createdDate' => date('Y-m-d H:i:s')
            );
            
            // Validate submitted form data
            if($this->form_validation->run() == true){
                // Insert member data
                $insert = $this->User_model->update($userData, $id);
                $ARIData = array(
                    // 'userId' => $this->db->insert_id(),
                    'ZCName' => $this->input->post('ZCName'),
                    'ZCPhone' => $this->input->post('ZCPhone'),
                    'ZCEmail' => $this->input->post('ZCEmail'),
                    // 'ARIWardNo' => $this->input->post('ARIWardNo'),
                    'ZCZone' => $this->input->post('ZCZone'),
                    'status' => 1
                );
                $this->db->update('zone_commissioner_table', $ARIData, array('userId' => $id));
                if($insert){
                    $this->session->set_userdata('success_msg', 'Zone Commissioner has been Upfated successfully.');
                    redirect('Zonecommissioner/manageZC');
                }else{
                    $data['error_msg'] = 'Some problems occured, please try again.';
                }
            }
        }
        
        $data['user'] = $userData;
        
        // Load the edit page view
        $this->load->view('template/includes/header');
        $this->load->view('template/ZC/editZC', $data);
        $this->load->view('template/includes/footer');
    }

    public function delete($id){
        // Check whether course id is not empty
        if($id){
            // Delete course
            // $delete = $this->User_model->delete($id);
            // $this->db->where('userId', $id);
            // $this->db->delete('zone_commissioner_table');
            // $this->db->where('userId', $id);
            // $this->db->delete('users');
            $user_update = $this->db->update('users', array('deleteStatus' => 1,'deletedAt' => date('Y-m-d H:i:s')), array('userId' => $id));
            $zc_table = $this->db->update('zone_commissioner_table', array('deleteStatus' => 1, 'deletedAt' => date('Y-m-d H:i:s')), array('userId' => $id));
            if($user_update && $zc_table){
                $this->session->set_userdata('success_msg', 'User has been removed successfully.');
            }else{
                $this->session->set_userdata('error_msg', 'Some problems occured, please try again.');
            }
        }
        
        // Redirect to the list page
        redirect('Zonecommissioner/manageZC');
    }
    
    public function editProperty($propId) {
        $data = array();
        if(!empty($propId)) {
            $data['wardData'] = $this->Ward_model->getAllWards();
	        $data['zoneData'] = $this->Ward_model->getAllZones();
	        $data['id'] = $propId;
            $data['prop'] = $this->Ward_model->getPropData($propId);
            // print_r($data);
    	    $this->load->view('template/includes/header');
    	    $this->load->view('template/Property/editPropertyZC', $data);
    	    $this->load->view('template/includes/footer');
        }else{
            redirect('Property/getData');
        }
    }
    
    public function editEntry($id) {
	    if($this->input->post('userSubmit')){
	        if(!empty($_POST['floor_SBA'])){
	            $SBA = json_encode($_POST['floor_SBA']);
	        }else{
	            $SBA = NULL;
	        }
	        if(!empty($_POST['floor_type'])){
	            $floorType = json_encode($_POST['floor_type']);
	        }else{
	            $floorType = NULL;
	        }
	        if(!empty($_POST['occup_type'])) {
	            $occupType = json_encode($_POST['occup_type']);
	        }else{
	            $occupType = NULL;
	        }
	        if(!empty($_POST['total_floor'])) {
	            $totalFloor = json_encode($_POST['total_floor']);
	        }else{
	            $totalFloor = NULL;
	        }
	        if(!empty($_POST['parikshetra_number'])) {
	            $pn = $_POST['parikshetra_number'];
	        }else{
	            $pn = NULL;
	        }
	        if(!empty($_POST['road_type'])) {
	            $rt = $_POST['road_type'];
	        }else{
	            $rt = NULL;
	        }
	        if(!empty($_POST['const_type'])) {
	            $ct = $_POST['const_type'];
	        }else{
	            $ct = NULL;
	        }
	        $picture = array(
                 'upload_path'=>'public/admin/screenshot',
                 'allowed_types'=> 'jpg|png|jpeg',
                 'max_size' => 4000
                );
            $this->load->library("upload",$picture);
            $this->upload->initialize($picture);
            if(!$this->upload->do_upload('property_image')){
                $property = array(
    	            'parikshetra_number' => $pn,
    	            'road_type' => $rt,
    	            'const_type' => $ct,
    	            'last_tax_pay_amount' => $_POST['last_tax_pay_amount'],
    	            'year_of_last_tax_paid' => $_POST['year_of_last_tax_paid'],
    	            'owner_name' => $_POST['owner_name'],
    	            'guardian_name' => $_POST['guardian_name'],
    	            'gender' => $_POST['gender'],
    	            'mobile' => $_POST['mobile'],
    	            'address' => $_POST['address'],
    	            'colony' => $_POST['colony'],
    	            'pin_code' => $_POST['pin_code'],
    	            'area_of_plot_as_per_gis' => $_POST['area_of_plot_as_per_gis'],
    	            'area_of_building_footprint_as_per_gis' => $_POST['area_of_building_footprint_as_per_gis'],
    	            'latitude' => $_POST['latitude'],
    	            'longitude' => $_POST['longitude'],
    	            'is_property_available_in_bmc_record' => $_POST['is_property_available_in_bmc_record'],
    	            'open_plots' => $_POST['open_plots'],
    	            'new_pro_no' => $_POST['new_pro_no'],
    	            'DDN' => $_POST['DDN'],
    	            'ward_no' => $_POST['ward_no'],
    	            'zone_no' => $_POST['zone_no'],
    	            'floor_SBA' => $SBA,
    	            'floor_type' => $floorType,
    	            'floor_wise_occup_type' => $occupType,
    	            'total_floors' => $totalFloor,
    	            'ZC_audit_status' => $_POST['ZC_audit_status'],
    	            'ZC_reason_reject' => $_POST['ZC_reason_reject'],
    	            'ZC_remark' => $_POST['ZC_remark'],
    	            'ZC_updated_at' => date('Y-m-d H:i:s')
    	        );
            }else{
                $fd = $this->upload->data();
                $fn = $fd['file_name'];
                $property = array(
    	            'parikshetra_number' => $pn,
    	            'road_type' => $rt,
    	            'const_type' => $ct,
    	            'last_tax_pay_amount' => $_POST['last_tax_pay_amount'],
    	            'year_of_last_tax_paid' => $_POST['year_of_last_tax_paid'],
    	            'owner_name' => $_POST['owner_name'],
    	            'guardian_name' => $_POST['guardian_name'],
    	            'gender' => $_POST['gender'],
    	            'mobile' => $_POST['mobile'],
    	            'address' => $_POST['address'],
    	            'colony' => $_POST['colony'],
    	            'pin_code' => $_POST['pin_code'],
    	            'area_of_plot_as_per_gis' => $_POST['area_of_plot_as_per_gis'],
    	            'area_of_building_footprint_as_per_gis' => $_POST['area_of_building_footprint_as_per_gis'],
    	            'latitude' => $_POST['latitude'],
    	            'longitude' => $_POST['longitude'],
    	            'is_property_available_in_bmc_record' => $_POST['is_property_available_in_bmc_record'],
    	            'open_plots' => $_POST['open_plots'],
    	            'new_pro_no' => $_POST['new_pro_no'],
    	            'DDN' => $_POST['DDN'],
    	            'ward_no' => $_POST['ward_no'],
    	            'zone_no' => $_POST['zone_no'],
    	            'floor_SBA' => $SBA,
    	            'floor_type' => $floorType,
    	            'floor_wise_occup_type' => $occupType,
    	            'total_floors' => $totalFloor,
    	            'property_image' => $fn,
    	            'ZC_audit_status' => $_POST['ZC_audit_status'],
    	            'ZC_reason_reject' => $_POST['ZC_reason_reject'],
    	            'ZC_remark' => $_POST['ZC_remark'],
    	            'ZC_updated_at' => date('Y-m-d H:i:s')
    	        );
            }
	        
	       // if($this->form_validation->run() == true){
    	        $update = $this->Ward_model->update($property, $id);
    	        if($update) {
    	            $data['success_msg'] =  'Property has been added successfully.';
                    redirect('Property/getData');
    	        }else{
    	            $data['error_msg'] = 'Some problems occured, please try again.';
    	            redirect('Property/getData');
    	        }
	       // }
	        
	    }
	}
    
}