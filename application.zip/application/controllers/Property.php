<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Property extends CI_Controller {

public function __construct(){
		parent::__construct();
		if($this->session->userdata('logged_in')!= TRUE){
			redirect('Login');
		}
		$this->load->helper('form');
        $this->load->library('form_validation');
        $this->load->library('upload');
        $this->load->library('csvimport');
        $this->load->model('Ward_model');
        $this->load->model('Property_model');
        $this->load->model('User_model');
        // $this->output->disable_cache();

        // Load pagination library
        $this->load->library('pagination');
	}
	//Get All Lat Long Data
	public function getLatLong() {
	    $query = $this->db->query("SELECT * FROM `property`");
	    $result = $query->result();
	    if($result->num_rows > 0){
	        $location = array();
	        
	        foreach($result as $row){
	            $location[] = $row;
	        }
	        
	        header('Content-Type: application/json');
	        echo json_encode($location);
	    }else{
	        echo 'No Data Found.';
	    }
	}
	
	public function addPropertyWithoutLocation() {
	    $data = array();
	    $data['wardData'] = $this->Ward_model->getAllWards();
	    $data['zoneData'] = $this->Ward_model->getAllZones();
	    $this->load->view('template/includes/header');
	    $this->load->view('template/Property/addWithoutLocation', $data);
	    $this->load->view('template/includes/footer');
	}
	
	public function viewProperty($propId) {
	    $data = array();
        if(!empty($propId)) {
            $data['wardData'] = $this->Ward_model->getAllWards();
	        $data['zoneData'] = $this->Ward_model->getAllZones();
	        $data['id'] = $propId;
            $data['prop'] = $this->Ward_model->getPropData($propId);
            // print_r($data);
    	    $this->load->view('template/includes/header');
    	    $this->load->view('template/Property/viewPropertyARI', $data);
    	    $this->load->view('template/includes/footer');
        }else{
            redirect('Property/getData');
        }
	}
	
	public function index()
	{
		
		if($this->session->userdata('roleId') === '3')
		{	
		$this->load->view('template/header');	
		$this->load->view('template/dashboard_team');
		$this->load->view('template/footer');
		}
		else{
			echo "Access Denied!"; 
		}
	}
	
	public function add() {
	    $data = array();
	    $data['wardData'] = $this->Ward_model->getAllWards();
	    $data['zoneData'] = $this->Ward_model->getAllZones();
	    $this->load->view('template/includes/header');
	    $this->load->view('template/Property/add', $data);
	    $this->load->view('template/includes/footer');
	}
	
	public function addEntry() {
	    if($this->input->post('submit')){
	       // print_r($_POST);
	       // exit();
	        if(!empty($_POST['floor_SBA'])){
	            $SBA = json_encode($_POST['floor_SBA']);
	        }else{
	            $SBA = NULL;
	        }
	        if(!empty($_POST['floor_type'])){
	            $floorType = json_encode($_POST['floor_type']);
	        }else{
	            $floorType = NULL;
	        }
	        if(!empty($_POST['occup_type'])) {
	            $occupType = json_encode($_POST['occup_type']);
	        }else{
	            $occupType = NULL;
	        }
	        if(!empty($_POST['total_floor'])) {
	            $totalFloor = json_encode($_POST['total_floor']);
	        }else{
	            $totalFloor = NULL;
	        }
	        if(!empty($_POST['floor_remarks'])){
	            $floorRemarks = json_encode($_POST['floor_remarks']);
	        }else{
	            $floorRemarks = NULL;
	        }
	        if(!empty($_POST['parikshetra_number'])) {
	            $pn = $_POST['parikshetra_number'];
	        }else{
	            $pn = NULL;
	        }
	        if(!empty($_POST['road_type'])) {
	            $rt = $_POST['road_type'];
	        }else{
	            $rt = NULL;
	        }
	        if(!empty($_POST['const_type'])) {
	            $ct = $_POST['const_type'];
	        }else{
	            $ct = NULL;
	        }
	        $picture = array(
                 'upload_path'=>'public/admin/screenshot',
                 'allowed_types'=> 'jpg|png|jpeg',
                 'max_size' => 4000
                );
            $wardId = $this->Ward_model->getWardIdByUser($this->session->userdata('userId'))[0]->ARIWardNo;
            $zoneId = $this->Ward_model->getWardDetailWard($wardId)[0]->zoneId;
            $this->load->library("upload",$picture);
            $this->upload->initialize($picture);
            {
                $image1 = $this->uploadImage('property_image');
                $image2 = $this->uploadImage('tildImage');
                $fn = site_url('public/admin/screenshot/'. $image1);
                $fn1 = site_url('public/admin/screenshot/'.$image2);
                $property = array(
    	            'parikshetra_number' => $pn,
    	            'road_type' => $rt,
    	            'const_type' => $ct,
    	            'last_tax_pay_amount' => $_POST['last_tax_pay_amount'],
    	            'year_of_last_tax_paid' => $_POST['year_of_last_tax_paid'],
    	            'owner_name' => $_POST['owner_name'],
    	            'guardian_name' => $_POST['guardian_name'],
    	            'gender' => $_POST['gender'],
    	            'mobile' => $_POST['mobile'],
    	            'address' => $_POST['address'],
    	            'colony' => $_POST['colony'],
    	            'pin_code' => $_POST['pin_code'],
    	            'area_of_plot_as_per_gis' => $_POST['area_of_plot_as_per_gis'],
    	            'area_of_building_footprint_as_per_gis' => $_POST['area_of_building_footprint_as_per_gis'],
    	            'latitude' => $_POST['latitude'],
    	            'longitude' => $_POST['longitude'],
    	            'year_of_construction' => $_POST['year_of_construction'],
    	            'is_property_available_in_bmc_record' => $_POST['is_property_available_in_bmc_record'],
    	            'open_plots' => $_POST['open_plots'],
    	            'new_pro_no' => $_POST['new_pro_no'],
    	            'DDN' => $_POST['DDN'],
    	            'ward_no' => $wardId,
    	            'zone_no' => $this->Ward_model->getWardDetail($wardId)[0]->zoneId,//$_POST['zone_no'],
    	            'floor_SBA' => $SBA,
    	            'floor_type' => $floorType,
    	            'floor_wise_occup_type' => $occupType,
    	            'total_floors' => $totalFloor,
    	            'floor_remarks' => $floorRemarks,
    	            'property_image' => $fn,
    	            'tildImage' => $fn1,
    	            'ARI_audit_status' => 'Approved',
    	            'ARI_updated_at' => date('Y-m-d H:i:s')
    	        );
            }
    	        $insert = $this->Ward_model->insert($property);
    	       $propId = $this->db->insert_id();
    	        if($insert) {
    	            $data['success_msg'] =  'ARI has been added successfully.';
                    redirect('Property/viewEntry/'.$propId);
    	        }else{
    	            $data['error_msg'] = 'Some problems occured, please try again.';
    	            redirect('Property/getData');
    	        }
	       // }
	        
	    }
	}
	
	public function addEntryWithoutLocation() {
	    if($this->input->post('submit')){
	        print_r($_POST);
	        exit();
	        if(!empty($_POST['floor_SBA'])){
	            $SBA = json_encode($_POST['floor_SBA']);
	        }else{
	            $SBA = NULL;
	        }
	        if(!empty($_POST['floor_type'])){
	            $floorType = json_encode($_POST['floor_type']);
	        }else{
	            $floorType = NULL;
	        }
	        if(!empty($_POST['occup_type'])) {
	            $occupType = json_encode($_POST['occup_type']);
	        }else{
	            $occupType = NULL;
	        }
	        if(!empty($_POST['total_floor'])) {
	            $totalFloor = json_encode($_POST['total_floor']);
	        }else{
	            $totalFloor = NULL;
	        }
	        if(!empty($_POST['floor_remarks'])){
	            $floorRemarks = json_encode($_POST['floor_remarks']);
	        }else{
	            $floorRemarks = NULL;
	        }
	        if(!empty($_POST['parikshetra_number'])) {
	            $pn = $_POST['parikshetra_number'];
	        }else{
	            $pn = NULL;
	        }
	        if(!empty($_POST['road_type'])) {
	            $rt = $_POST['road_type'];
	        }else{
	            $rt = NULL;
	        }
	        if(!empty($_POST['const_type'])) {
	            $ct = $_POST['const_type'];
	        }else{
	            $ct = NULL;
	        }
	        $picture = array(
                 'upload_path'=>'public/admin/screenshot',
                 'allowed_types'=> 'jpg|png|jpeg',
                 'max_size' => 4000
                );
            $wardId = $this->Ward_model->getWardIdByUser($this->session->userdata('userId'))[0]->ARIWardNo;
            $zoneId = $this->Ward_model->getWardDetailWard($wardId)[0]->zoneId;
            $this->load->library("upload",$picture);
            $this->upload->initialize($picture);
            {
                $image1 = $this->uploadImage('property_image');
                $image2 = $this->uploadImage('tildImage');
                $fn = site_url('public/admin/screenshot/'. $image1);
                $fn1 = site_url('public/admin/screenshot/'.$image2);
                $property = array(
    	            'parikshetra_number' => $pn,
    	            'road_type' => $rt,
    	            'const_type' => $ct,
    	            'last_tax_pay_amount' => $_POST['last_tax_pay_amount'],
    	            'year_of_last_tax_paid' => $_POST['year_of_last_tax_paid'],
    	            'owner_name' => $_POST['owner_name'],
    	            'guardian_name' => $_POST['guardian_name'],
    	            'gender' => $_POST['gender'],
    	            'mobile' => $_POST['mobile'],
    	            'address' => $_POST['address'],
    	            'colony' => $_POST['colony'],
    	            'pin_code' => $_POST['pin_code'],
    	            'area_of_plot_as_per_gis' => $_POST['area_of_plot_as_per_gis'],
    	            'area_of_building_footprint_as_per_gis' => $_POST['area_of_building_footprint_as_per_gis'],
    	            'latitude' => $_POST['latitude'],
    	            'longitude' => $_POST['longitude'],
    	            'year_of_construction' => $_POST['year_of_construction'],
    	            'is_property_available_in_bmc_record' => $_POST['is_property_available_in_bmc_record'],
    	            'open_plots' => $_POST['open_plots'],
    	            'new_pro_no' => $_POST['new_pro_no'],
    	            'DDN' => $_POST['DDN'],
    	            'ward_no' => $wardId,
    	            'zone_no' => $this->Ward_model->getWardDetail($wardId)[0]->zoneId,//$_POST['zone_no'],
    	            'floor_SBA' => $SBA,
    	            'floor_type' => $floorType,
    	            'floor_wise_occup_type' => $occupType,
    	            'total_floors' => $totalFloor,
    	            'floor_remarks' => $floorRemarks,
    	            'property_image' => $fn,
    	            'tildImage' => $fn1,
    	            'ARI_audit_status' => 'Approved',
    	            'ARI_updated_at' => date('Y-m-d H:i:s')
    	        );
            }
    	        $insert = $this->Ward_model->insert($property);
    	       $propId = $this->db->insert_id();
    	        if($insert) {
    	            $data['success_msg'] =  'ARI has been added successfully.';
                    redirect('Property/viewEntry/'.$propId);
    	        }else{
    	            $data['error_msg'] = 'Some problems occured, please try again.';
    	            redirect('Property/getData');
    	        }
	       // }
	        
	    }
	}
	
	private function uploadImage($fieldName) {
        $picture = array(
                 'upload_path'=>'public/admin/screenshot',
                 'allowed_types'=> 'jpg|png|jpeg|JPG|PNG|JPEG',
                 'max_size' => 4000
                );
      
        $this->load->library("upload",$picture);
      
        if (!$this->upload->do_upload($fieldName)) {
          // Handle upload error
          $error = $this->upload->display_errors();
          // Show error message or log the error
        } else {
          // Upload successful
          $data = $this->upload->data();
          return $data['file_name'];
        }
      }
	
	public function getPropDataMaster($lat, $lng) {
	    if(!empty($lat) && !empty($lng)) {
	        $query = $this->db->query('SELECT * FROM `master_building_footprint` WHERE `latitude` = '.$lat.' AND `longitude` = '.$lng);
	        $result = $query->row_array();
	        $buildingArea = $result['areaInFeet'];
	        echo $buildingArea;
	    }
	}
	
	public function viewEntry($id) {
	    if(!empty($id)) {
	        $data = array();
	        $data['property'] = $this->Ward_model->getPropData($id);
	        $this->load->view('template/includes/header');
	        $this->load->view('template/Property/viewPropertyARI', $data);
	        $this->load->view('template/includes/footer');
	    }
	}
	
	public function edit($propId) {
	    $data = array();
        if(!empty($propId)) {
            $data['wardData'] = $this->Ward_model->getAllWards();
	        $data['zoneData'] = $this->Ward_model->getAllZones();
	        $data['id'] = $propId;
            $data['prop'] = $this->Ward_model->getPropData($propId);
            // print_r($data);
    	    $this->load->view('template/includes/header');
    	    $this->load->view('template/Property/edit', $data);
    	    $this->load->view('template/includes/footer');
        }else{
            redirect('Property/getData');
        }
	}
	
	public function delete($id){
        // Check whether course id is not empty
        if($id){
            // Delete course
            // $delete = $this->User_model->deleteProperty($id);
            $property = $this->db->update('property', array('deleted' => 1, 'deletedAt' => date('Y-m-d H:i:s')), array('id' => $id));
            // $this->db->where('id', $id);
            // $this->db->delete('property');
            
            if($property){
                $this->session->set_userdata('success_msg', 'Property has been removed successfully.');
            }else{
                $this->session->set_userdata('error_msg', 'Some problems occured, please try again.');
            }
        }
        
        // Redirect to the list page
        redirect('Property/getData');
    }
	
	public function editEntry($id) {
	    if($this->input->post('userSubmit')){
	        if(!empty($_POST['floor_SBA'])){
	            $SBA = json_encode($_POST['floor_SBA']);
	        }else{
	            $SBA = NULL;
	        }
	        if(!empty($_POST['floor_type'])){
	            $floorType = json_encode($_POST['floor_type']);
	        }else{
	            $floorType = NULL;
	        }
	        if(!empty($_POST['occup_type'])) {
	            $occupType = json_encode($_POST['occup_type']);
	        }else{
	            $occupType = NULL;
	        }
	        if(!empty($_POST['total_floor'])) {
	            $totalFloor = json_encode($_POST['total_floor']);
	        }else{
	            $totalFloor = NULL;
	        }
	        if(!empty($_POST['parikshetra_number'])) {
	            $pn = $_POST['parikshetra_number'];
	        }else{
	            $pn = NULL;
	        }
	        if(!empty($_POST['road_type'])) {
	            $rt = $_POST['road_type'];
	        }else{
	            $rt = NULL;
	        }
	        if(!empty($_POST['const_type'])) {
	            $ct = $_POST['const_type'];
	        }else{
	            $ct = NULL;
	        }
	        $picture = array(
                 'upload_path'=>'public/admin/screenshot',
                 'allowed_types'=> 'jpg|png|jpeg',
                 'max_size' => 4000
                );
                $wardId = $this->Ward_model->getWardIdByUser($this->session->userdata('userId'))[0]->ARIWardNo;
            $zoneId = $this->Ward_model->getWardDetailWard($wardId)[0]->zoneId;
            // $zoneId = $this->Ward_model->getWardDetailWard('Ward '.$_POST['ward_no'])[0]->zoneId;
            // print_r($this->db->last_query());
            //     exit();
            $this->load->library("upload",$picture);
            $this->upload->initialize($picture);
            if(!$this->upload->do_upload('property_image')){
                $property = array(
    	            'parikshetra_number' => $pn,
    	            'road_type' => $rt,
    	            'const_type' => $ct,
    	            'last_tax_pay_amount' => $_POST['last_tax_pay_amount'],
    	            'year_of_last_tax_paid' => $_POST['year_of_last_tax_paid'],
    	            'owner_name' => $_POST['owner_name'],
    	            'guardian_name' => $_POST['guardian_name'],
    	            'gender' => $_POST['gender'],
    	            'mobile' => $_POST['mobile'],
    	            'address' => $_POST['address'],
    	            'colony' => $_POST['colony'],
    	            'pin_code' => $_POST['pin_code'],
    	            'area_of_plot_as_per_gis' => $_POST['area_of_plot_as_per_gis'],
    	            'area_of_building_footprint_as_per_gis' => $_POST['area_of_building_footprint_as_per_gis'],
    	            'latitude' => $_POST['latitude'],
    	            'longitude' => $_POST['longitude'],
    	            'is_property_available_in_bmc_record' => $_POST['is_property_available_in_bmc_record'],
    	            'open_plots' => $_POST['open_plots'],
    	            'new_pro_no' => $_POST['new_pro_no'],
    	            'DDN' => $_POST['DDN'],
    	            'ward_no' => $wardId,
    	            'zone_no' => $this->Ward_model->getWardDetail($wardId)[0]->zoneId,//$_POST['zone_no'],
    	            'floor_SBA' => $SBA,
    	            'floor_type' => $floorType,
    	            'floor_wise_occup_type' => $occupType,
    	            'total_floors' => $totalFloor,
    	            'year_of_construction' => $_POST['year_of_construction'],
    	            'ARI_audit_status' => 'Approved',
    	            'ARI_updated_at' => date('Y-m-d H:i:s')
    	        );
            }else{
                $fd = $this->upload->data();
                $fn = site_url('public/admin/screenshot/'. $fd['file_name']);
                $property = array(
    	            'parikshetra_number' => $pn,
    	            'road_type' => $rt,
    	            'const_type' => $ct,
    	            'last_tax_pay_amount' => $_POST['last_tax_pay_amount'],
    	            'year_of_last_tax_paid' => $_POST['year_of_last_tax_paid'],
    	            'owner_name' => $_POST['owner_name'],
    	            'guardian_name' => $_POST['guardian_name'],
    	            'gender' => $_POST['gender'],
    	            'mobile' => $_POST['mobile'],
    	            'address' => $_POST['address'],
    	            'colony' => $_POST['colony'],
    	            'pin_code' => $_POST['pin_code'],
    	            'area_of_plot_as_per_gis' => $_POST['area_of_plot_as_per_gis'],
    	            'area_of_building_footprint_as_per_gis' => $_POST['area_of_building_footprint_as_per_gis'],
    	            'latitude' => $_POST['latitude'],
    	            'longitude' => $_POST['longitude'],
    	            'is_property_available_in_bmc_record' => $_POST['is_property_available_in_bmc_record'],
    	            'open_plots' => $_POST['open_plots'],
    	            'new_pro_no' => $_POST['new_pro_no'],
    	            'DDN' => $_POST['DDN'],
    	            'ward_no' => $wardId,
    	            'zone_no' => $this->Ward_model->getWardDetail($wardId)[0]->zoneId,
    	            'floor_SBA' => $SBA,
    	            'year_of_construction' => $_POST['year_of_construction'],
    	            'floor_type' => $floorType,
    	            'floor_wise_occup_type' => $occupType,
    	            'total_floors' => $totalFloor,
    	            'property_image' => $fn,
    	            'ARI_audit_status' => 'Approved',
    	            'ARI_updated_at' => date('Y-m-d H:i:s')
    	        );
            }
	        
	       // if($this->form_validation->run() == true){
    	        $update = $this->Ward_model->update($property, $id);
    	        if($update) {
    	            $data['success_msg'] =  'Property has been added successfully.';
                    redirect('Property/getData');
    	        }else{
    	            $data['error_msg'] = 'Some problems occured, please try again.';
    	            redirect('Property/getData');
    	        }
	       // }
	        
	    }
	}
	
	public function getData() {
	    $data = array();
	    if($this->session->userdata('roleType') == 'ARI'){
	        $ward = $this->Ward_model->getARIData($this->session->userdata('userId'))[0]->ARIWardNo;
	        $data['properties'] = $this->Ward_model->getPropertyData($ward);
	    }elseif($this->session->userdata('roleType') == 'ARO'){
	        $ward = $this->Property_model->getAROData($this->session->userdata('userId'))[0]->AROZoneNo;
	       // echo $this->db->last_query();
	        $data['properties'] = $this->Ward_model->getPropertyZoneData($ward);
	       // echo $this->db->last_query();
	    }elseif($this->session->userdata('roleType') == 'Zone Commissioner'){
	        $ward = $this->Ward_model->getARIData($this->session->userdata('userId'))[0]->ZCWardNo;
	        $data['properties'] = $this->Ward_model->getPropertyData($ward);
	    }else{
	        $data['properties'] = $this->Ward_model->getPropertyData();
	    }
	    $this->load->view('template/includes/header');
	    $this->load->view('template/Property/manageProp', $data);
	    $this->load->view('template/includes/footer');
	}
	
	public function getPropertyForApproval() {
	    $data = array();
	    if($this->session->userdata('roleType') == 'Zone Commissioner'){
	        $zone = $this->Ward_model->getZCData($this->session->userdata('userId'))[0]->ZCZone;
	        $data['properties'] = $this->Ward_model->getPropForApproval($zone);
	    }else{
	        $data['properties'] = $this->Ward_model->getPropertyData();
	    }
	    $this->load->view('template/includes/header');
	    $this->load->view('template/Property/manageProp', $data);
	    $this->load->view('template/includes/footer');
	}
	
	public function importImage($imgUrl) {
	    if(!empty($imgUrl)){
    	    $url = $imgUrl; // URL of the image
            $destination_folder = 'public/admin/screenshot/'; // Folder to save the image
            
            $image_name = basename($url); // Get the image name from the URL
            
            $image = file_get_contents($url); // Get the contents of the image
            
            file_put_contents($destination_folder . $image_name, $image);
            
            return $image_name;
	    }else{
	        return "Image Url cant be blank.";
	    }
	}
	
	public function importCSV() {
	    $data['error_msg'] = '';
        $config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'csv';
        $config['max_size'] = '10000';
        $this->load->library('upload', $config);
        $this->upload->initialize($config);
        if(!$this->upload->do_upload('importData')) {
            $data['error_msg'] = $this->upload->display_errors();
            $this->load->view('template/includes/header');
            $this->load->view('template/Property/manageProp', $data);
            $this->load->view('template/includes/footer');
        }else{
            $file_data = $this->upload->data();
            $file_path = './uploads/'.$file_data['file_name'];
            
            if($this->csvimport->get_array($file_path)) {
                $csv_array = $this->csvimport->get_array($file_path);
                foreach($csv_array as $row) {
                    $query = $this->db->query('SELECT * FROM `property` WHERE `new_pro_no` = "'.$row['new_pro_no'].'"');
                    if(!$query->num_rows() > 0){
                        $url = $row['property_image'];
                        $destination_folder = 'public/admin/screenshot/'; // Folder to save the image
            
                        $image_name = basename($url); // Get the image name from the URL
                        
                        $image = file_get_contents($url); // Get the contents of the image
                        
                        file_put_contents($destination_folder . $image_name, $image);
                        $newImageUrl = site_url('public/admin/screenshot/'.$image_name);
                        $property = array(
                            'parikshetra_number' => !empty($row['parikshetra_number'])?$row['parikshetra_number']:NULL,
                            'road_type' => !empty($row['road_type'])?$row['road_type']:NULL,
                            'floor_SBA' => !empty($row['floor_SBA'])?$row['floor_SBA']:NULL,
                            'const_type' => !empty($row['const_type'])?$row['const_type']:NULL,
                            'floor_type' => !empty($row['floor_usage_type'])?$row['floor_usage_type']:NULL,
                            'last_tax_pay_amount' => !empty($row['last_tax_paid_amount'])?$row['last_tax_paid_amount']:NULL,
                            'year_of_last_tax_paid' => !empty($row['year_of_last_tax_paid'])?$row['year_of_last_tax_paid']:NULL,
                            'owner_name' => !empty($row['owner_name'])?$row['owner_name']:NULL,
                            'guardian_name' => !empty($row['guardian_name'])?$row['guardian_name']:NULL,
                            'gender' => !empty($row['gender'])?$row['gender']:NULL,
                            'mobile' => !empty($row['mobile'])?$row['mobile']:NULL,
                            'address' => !empty($row['address'])?$row['address']:NULL,
                            'colony' => !empty($row['colony'])?$row['colony']:NULL,
                            'floor_wise_occup_type' => !empty($row['floor_wise_occup_type'])?$row['floor_wise_occup_type']:NULL,
                            'pin_code' => !empty($row['pin_code'])?$row['pin_code']:NULL,
                            'area_of_plot_as_per_gis' => !empty($row['area_of_plot_as_per_drone'])?$row['area_of_plot_as_per_drone']:NULL,
                            'area_of_building_footprint_as_per_gis' => !empty($row['area_of_building_footprint_as_per_drone'])?$row['area_of_building_footprint_as_per_drone']:NULL,
                            'total_floors' => !empty($row['total_floors'])?$row['total_floors']:NULL,
                            'latitude' => !empty($row['latitude'])?$row['latitude']:NULL,
                            'longitude' => !empty($row['longitude'])?$row['longitude']:NULL,
                            'is_property_available_in_BMC_record' => !empty($row['is_property_available_in_bmc_record'])?$row['is_property_available_in_bmc_record']:NULL,
                            'property_image' => !empty($row['property_image'])?$newImageUrl:NULL,
                            'open_plots' => !empty($row['open_plot'])?$row['open_plot']:NULL,
                            'penality' => !empty($row['penalty'])?$row['penalty']:NULL,
                            'year_of_construction' => !empty($row['year_of_construction'])?$row['year_of_construction']:NULL,
                            'new_pro_no' => !empty($row['new_pro_no'])?$row['new_pro_no']:NULL,
                            'DDN' => !empty($row['DDN'])?$row['DDN']:NULL,
                            'ward_no' => !empty($row['ward_no'])?$row['ward_no']:NULL,
                            'zone_no' => !empty($row['zone_no'])?$row['zone_no']:NULL,
                        );
                        
                        
                        $this->Ward_model->insert($property);
                    }else{
                        $data['error_msg'] = "Error Occured";
                        $this->load->view('template/includes/header');
                        $this->load->view('template/Property/manageProp', $data);
                        $this->load->view('template/includes/footer');
                    }
                }
                $this->session->set_userdata('success_msg', 'CSV Data Imported Successfully.');
                redirect('Property/getData');
            }else{
                $data['error_msg'] = "Error Occured";
                $this->load->view('template/includes/header');
                $this->load->view('template/Property/manageProp', $data);
                $this->load->view('template/includes/footer');
            }
        }
	}


}