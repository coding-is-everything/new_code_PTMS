<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MDDash extends CI_Controller {

public function __construct(){
		parent::__construct();
		$this->load->model(['Admin_model', 'Incentive_model', 'Batch_model', 'Crm_leads_model', 'Property_model', 'Ward_model']);
		if($this->session->userdata('logged_in')!= TRUE){
			redirect('Login');
		}
	}
	public function index()
	{
		
		if($this->session->userdata('roleId') === '5')
		{	
		    $data = [];
    	    $data['MDData'] = $this->Property_model->getMDData();
    	    $data['totalProperty'] = $this->Property_model->totalProperty();
    		$data['approvedProperty'] = $this->Property_model->approvedProperty();
    		$data['rejectedProperty'] = $this->Property_model->rejectedProperty();
    		$data['property'] = $this->Property_model->getProperty();
    	    $this->load->view('template/includes/header');
    	    $this->load->view('template/homePage/mdDashboard', $data);
    	    $this->load->view('template/includes/footer');
		}
		else{
			echo "Access Denied!"; 
		}
	}


}