<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Reports extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        error_reporting(E_ALL & ~E_NOTICE);
        // Load member model
        $this->load->model('Incentive_model');
        $this->load->model('Batch_model');
        $this->load->model('Reports_model');
        $this->load->model('Ward_model');
        // Load form helper and library
        $this->load->helper('form');
        $this->load->library('form_validation');
        $this->load->library('upload');

        // Load pagination library
        $this->load->library('pagination');
    }

     public function AdminApprovedReports() {
         $data = array();
         $data['properties'] = $this->Ward_model->ApprovedRecord();
         $this->load->view('template/includes/header');
         $this->load->view('template/Reports/AdminApprovedReports', $data);
         $this->load->view('template/includes/footer');
     }
     
     public function AdminRejectedReports() {
         $data = array();
         $data['properties'] = $this->Ward_model->RejectedRecord();
         $this->load->view('template/includes/header');
         $this->load->view('template/Reports/AdminRejectedReports', $data);
         $this->load->view('template/includes/footer');
     }
     
     public function ARIGenerateReports() {
         $this->load->view('template/includes/header');
         $this->load->view('template/includes/footer');
     }
     
     public function AROGenerateReports() {
         $this->load->view('template/includes/header');
         $this->load->view('template/includes/footer');
     }
     
     public function ZCGenerateReports() {
         $this->load->view('template/includes/header');
         $this->load->view('template/includes/footer');
     }
}
