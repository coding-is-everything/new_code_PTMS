<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Aro extends CI_Controller {
    
function __construct() {
        parent::__construct();
        
        // Load member model
        $this->load->model('User_model');
        $this->load->model('Ward_model');
        $this->load->model('Property_model');
        // Load form helper and library
        $this->load->helper('form');
        $this->load->library('form_validation');
        $this->load->library('upload');
        $this->load->library('csvimport');
        // Load pagination library
        $this->load->library('pagination');
        
    }

	public function manageAro(){ 

	$data = array();
        
        // Get messages from the session
        if($this->session->userdata('success_msg')){
            $data['success_msg'] = $this->session->userdata('success_msg');
            $this->session->unset_userdata('success_msg');
        }
        if($this->session->userdata('error_msg')){
            $data['error_msg'] = $this->session->userdata('error_msg');
            $this->session->unset_userdata('error_msg');
        }
        $data['ARODetails'] = $this->Ward_model->getAllAro();
        // Load the list page view
        $this->load->view('template/includes/header');
		$this->load->view('template/ARO/manageAro',$data);
		$this->load->view('template/includes/footer'); 
}

    public function wardWiseReport() {
        $data = array();
        $ward = $this->Property_model->getAROData($this->session->userdata('userId'))[0]->AROZoneNo;
	    $data['properties'] = $this->Ward_model->getPropertyZoneData($ward);
	    $data['wards'] = $this->Ward_model->getAllWardsZoneWise();
        $this->load->view('template/includes/header');
	    $this->load->view('template/ARO/wardWiseReport', $data);
	    $this->load->view('template/includes/footer');
    }
    
    public function ajaxPropertyData() {
        $wardId = $_POST['wardId'];
        $zoneId = $this->Property_model->getAROData($this->session->userdata('userId'))[0]->AROZoneNo;
        $properties = $this->Ward_model->getPropertyZoneWardWise($zoneId, $wardId);
        ?>
        <table id="example1" class="table table-bordered table-striped table-responsive">
                  <thead class="bg-success">
                  <tr>
                    <th>Sr.No</th>
                    <th>Owner Name</th>
                    <th>Guardian Name</th>
                    <th>Zone Name</th>
                    <th>Ward Name</th>
                    <th>Parikshetra Number</th>
                    <th>Main road or internal road</th>
                    <th>Floor(SBA)</th>
                    <th>Type of property( Pucca, kaccha, ard pucca)</th>
                    <th>Property Id</th>
                    <th>ARI Audit Status</th>
                    <th>ARO Audit Status</th>
                    <th>Zone Commissioner Audit Status</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php
                    $sr = 1;
                    if(!empty($properties)){ foreach($properties as $prop) {
                    ?>
                    <tr>
                        <td><?php echo $sr++; ?></td>
                        <td><?php echo strtoupper($prop->owner_name); ?></td>
                        <td><?php echo strtoupper($prop->guardian_name); ?></td>
                        <td><?php echo $this->Ward_model->getZoneDetail($prop->zone_no)[0]->zoneName; ?></td>
                        <td><?php echo $this->Ward_model->getWardDetail($prop->ward_no)[0]->wardName; ?>( <?php echo $this->Ward_model->getWardDetail($prop->ward_no)[0]->wardId ?> )</td>
                        <td><?php echo !empty($prop->parikshetra_number)?$prop->parikshetra_number:'No Data'; ?></td>
                        <td><?php echo !empty($prop->road_type)?$prop->road_type:'No Data'; ?></td>
                        <td><?php echo !empty($prop->floor_SBA)?$prop->floor_SBA:'No Data'; ?></td>
                        <td><?php echo $prop->const_type; ?></td>
                        <td><?php echo $prop->new_pro_no ?></td>
                        <td><?php echo !empty($prop->ARI_audit_status)?$prop->ARI_audit_status:'Approval Pending From ARI'; ?></td>
                        <td><?php echo !empty($prop->ARO_audit_status)?$prop->ARO_audit_status:'Approval Pending From ARO'; ?></td>
                        <td><?php echo !empty($prop->ZC_audit_status)?$prop->ZC_audit_status:'Approval Pending From Zone Commissioner'; ?></td>
                        <td>
                      &nbsp;<?php if($this->session->userdata('roleId') == 1){ ?>
                        <a href="<?php echo site_url('Property/edit/'.$prop->id); ?>"><i class="fa fa-edit" style="font-size:20px"></i></a>&nbsp;
                      <?php }elseif($this->session->userdata('roleId') == 2){ ?>
                        <a href="<?php echo site_url('Ari/editProperty/'.$prop->id); ?>"><i class="fa fa-edit" style="font-size:20px"></i></a>&nbsp;
                      <?php }elseif($this->session->userdata('roleId') == 3){ ?>
                        <a href="<?php echo site_url('Aro/editProperty/'.$prop->id); ?>"><i class="fa fa-edit" style="font-size:20px"></i></a>&nbsp;
                      <?php }elseif($this->session->userdata('roleId') == 4){ ?>
                        <a href="<?php echo site_url('Zonecommissioner/editProperty/'.$prop->id); ?>"><i class="fa fa-edit" style="font-size:20px"></i></a>&nbsp;
                      <?php } ?>
                        <a href="<?php echo site_url('Property/delete/'.$prop->id); ?>" onclick="return confirm('Are you sure to delete?')"><i class="fa fa-trash" style="font-size:20px;"></i></a></td>
                    </tr>
                    <?php
                    }}
                    ?>
                  </tbody>
                </table>
        <?php
    }

public function view($id){
        $data = array();
        
        // Check whether member id is not empty
        if(!empty($id)){
            // $data['user'] = $this->User_model->getRows(array('userId' => $id));;
            $data['aro'] = $this->Ward_model->getARODataBasedOnId($id);
            // $data['title']  = 'User Details';
            // $data['roles'] = $this->User_model->getAllRoles();
            // Load the details page view
            $this->load->view('template/includes/header');
			$this->load->view('template/ARO/viewUser',$data);
			$this->load->view('template/includes/footer');
        }else{
            redirect('Aro/manageAro');
        }
    }

    public function add(){
        $data = array();
        $userData = array();
        $data['wardDetail'] = $this->Ward_model->getAllWards();
        $data['zoneDetail'] = $this->Ward_model->getAllZones();
        
        // If add request is submitted
        if($this->input->post('userSubmit')){
            // Form field validation rules
            $this->form_validation->set_rules('AROName','ARI Name','required|trim');
            $this->form_validation->set_rules('AROPhone', 'ARI Phone', 'required|trim');
            $this->form_validation->set_rules('AROEmail', 'ARI Email', 'required|trim');
            $this->form_validation->set_rules('userPassword', 'user password', 'required|trim');
            $this->form_validation->set_rules('AROZoneNo', 'ARI Zone', 'required|trim');
            $this->form_validation->set_rules('status', 'user status', 'required|trim');
            // Prepare course data
            $userData = array(
                'roleId'=> 3,
                'userName' => $this->input->post('AROName'),
                'userMobile' => $this->input->post('AROPhone'),
                'userEmail'=> $this->input->post('AROEmail'),
                'userPassword' => base64_encode($this->input->post('userPassword')),
                'roleType'=> 'ARO',
                'createdDate' => date('Y-m-d H:i:s')
            );
            
            // Validate submitted form data
            if($this->form_validation->run() == true){
                // Insert member data
                $insert = $this->User_model->insert($userData);
                $ARIData = array(
                    'userId' => $this->db->insert_id(),
                    'AROName' => $this->input->post('AROName'),
                    'AROPhone' => $this->input->post('AROPhone'),
                    'AROEmail' => $this->input->post('AROEmail'),
                    'AROZoneNo' => $this->input->post('AROZoneNo'),
                    'status' => 1
                );
                $this->db->insert('aro_data_table', $ARIData);
                if($insert){
                    $this->session->set_userdata('success_msg', 'ARO has been added successfully.');
                    redirect('Aro/manageAro');
                }else{
                    $data['error_msg'] = 'Some problems occured, please try again.';
                }
            }
        }
        
        $data['user'] = $userData;
        
        // Load the add page view
        	$this->load->view('template/includes/header');
			$this->load->view('template/ARO/addAro',$data);
			$this->load->view('template/includes/footer');
        
    }

public function edit($id){
        $data = array();
        
        $data = array();
        $userData = array();
        // Get course data
        $data['aro'] = $this->Ward_model->getARODataBasedOnId($id);
        $data['wardDetail'] = $this->Ward_model->getAllWards();
        $data['zoneDetail'] = $this->Ward_model->getAllZones();
        $data['id'] = $id;
        // If add request is submitted
        if($this->input->post('userSubmit')){
            // Form field validation rules
            $this->form_validation->set_rules('AROName','ARI Name','required|trim');
            $this->form_validation->set_rules('AROPhone', 'ARI Phone', 'required|trim');
            $this->form_validation->set_rules('AROEmail', 'ARI Email', 'required|trim');
            // $this->form_validation->set_rules('userPassword', 'user password', 'required|trim');
            $this->form_validation->set_rules('AROZoneNo', 'ARI Zone', 'required|trim');
            $this->form_validation->set_rules('status', 'user status', 'required|trim');
            // Prepare course data
            $userData = array(
                'roleId'=> 3,
                'userName' => $this->input->post('AROName'),
                'userMobile' => $this->input->post('AROPhone'),
                'userEmail'=> $this->input->post('AROEmail'),
                // 'userPassword' => base64_encode($this->input->post('userPassword')),
                'roleType'=> 'ARO',
                'createdDate' => date('Y-m-d H:i:s')
            );
            
            // Validate submitted form data
            if($this->form_validation->run() == true){
                // Insert member data
                $insert = $this->User_model->update($userData, $id);
                $ARIData = array(
                    // 'userId' => $this->db->insert_id(),
                    'AROName' => $this->input->post('AROName'),
                    'AROPhone' => $this->input->post('AROPhone'),
                    'AROEmail' => $this->input->post('AROEmail'),
                    'AROZoneNo' => $this->input->post('AROZoneNo'),
                    'status' => 1
                );
                $this->db->update('aro_data_table', $ARIData, array('userId' => $id));
                if($insert){
                    $this->session->set_userdata('success_msg', 'ARO has been added successfully.');
                    redirect('Aro/manageAro');
                }else{
                    $data['error_msg'] = 'Some problems occured, please try again.';
                }
            }
        }
        
        $data['user'] = $userData;
        
        // Load the add page view
        	$this->load->view('template/includes/header');
			$this->load->view('template/ARO/editAro',$data);
			$this->load->view('template/includes/footer');
    }

    public function delete($id){
        // Check whether course id is not empty
        if($id){
            // Delete course
            // $delete = $this->User_model->delete($id);
            // $this->db->where('userId', $id);
            // $this->db->delete('aro_data_table');
            // $this->db->where('userId', $id);
            // $this->db->delete('users');
            $user_update = $this->db->update('users', array('deleteStatus' => 1,'deletedAt' => date('Y-m-d H:i:s')), array('userId' => $id));
            $aro_update = $this->db->update('aro_data_table', array('deleteStatus' => 1, 'deletedAt' => date('Y-m-d H:i:s')), array('userId' => $id));
            if($user_update && $aro_update){
                $this->session->set_userdata('success_msg', 'User has been removed successfully.');
            }else{
                $this->session->set_userdata('error_msg', 'Some problems occured, please try again.');
            }
        }
        
        // Redirect to the list page
        redirect('Aro/manageAro');
    }
    
    public function editProperty($propId) {
        $data = array();
        if(!empty($propId)) {
            $data['wardData'] = $this->Ward_model->getAllWards();
	        $data['zoneData'] = $this->Ward_model->getAllZones();
	        $data['id'] = $propId;
            $data['prop'] = $this->Ward_model->getPropData($propId);
            // print_r($data);
    	    $this->load->view('template/includes/header');
    	    $this->load->view('template/Property/editPropertyARO', $data);
    	    $this->load->view('template/includes/footer');
        }else{
            redirect('Property/getData');
        }
    }
    
    public function editEntry($id) {
	    if($this->input->post('userSubmit')){
	        //Logging purpose
	        $prop_old_data = $this->Ward_model->getPropData1($id);
	        print_r($prop_old_data);
	        $new_data = $this->input->post();
	       // $parikshetra_number_old = $prop[0]->parikshetra_number;
	       // $road_type_old = $prop[0]->road_type;
	       // $floor_SBA_old = $prop[0]->floor_SBA;
	       // $const_type_old = $prop[0]->const_type;
	       // $floor_type_old = $prop[0]->floor_type;
	       // $floor_remarks_old = $prop[0]->floor_remarks;
	       // $last_tax_pay_amount_old = $prop[0]->last_tax_pay_amount;
	       // $year_of_last_tax_paid_old = $prop[0]->year_of_last_tax_paid;
	       // $owner_name_old = $prop[0]->owner_name;
	       // $guardian_name_old = $prop[0]->guardian_name;
	       // $gender_old = $prop[0]->gender;
	       // $mobile_old = $prop[0]->mobile;
	       // $address_old = $prop[0]->address;
	       // $colony_old = $prop[0]->colony;
	       // $floor_wise_occup_type_old = $prop[0]->floor_wise_occup_type;
	       // $pin_code_old = $prop[0]->pin_code;
	       // $total_floors_old = $prop[0]->total_floors;
	       // $is_property_available_in_bmc_record_old = $prop[0]->is_property_available_in_bmc_record;
	       // $property_image_old = $prop[0]->is_
	        if(!empty($_POST['floor_SBA'])){
	            $SBA = json_encode($_POST['floor_SBA']);
	        }else{
	            $SBA = NULL;
	        }
	        if(!empty($_POST['floor_type'])){
	            $floorType = json_encode($_POST['floor_type']);
	        }else{
	            $floorType = NULL;
	        }
	        if(!empty($_POST['occup_type'])) {
	            $occupType = json_encode($_POST['occup_type']);
	        }else{
	            $occupType = NULL;
	        }
	        if(!empty($_POST['total_floor'])) {
	            $totalFloor = json_encode($_POST['total_floor']);
	        }else{
	            $totalFloor = NULL;
	        }
	        if(!empty($_POST['parikshetra_number'])) {
	            $pn = $_POST['parikshetra_number'];
	        }else{
	            $pn = NULL;
	        }
	        if(!empty($_POST['road_type'])) {
	            $rt = $_POST['road_type'];
	        }else{
	            $rt = NULL;
	        }
	        if(!empty($_POST['const_type'])) {
	            $ct = $_POST['const_type'];
	        }else{
	            $ct = NULL;
	        }
	        $picture = array(
                 'upload_path'=>'public/admin/screenshot',
                 'allowed_types'=> 'jpg|png|jpeg',
                 'max_size' => 4000
                );
            $this->load->library("upload",$picture);
            $this->upload->initialize($picture);
            $zoneId = $this->Ward_model->getWardDetailWard($_POST['ward_no'])[0]->zoneId;
            if(!$this->upload->do_upload('property_image')){
                $property = array(
    	            'parikshetra_number' => $pn,
    	            'road_type' => $rt,
    	            'const_type' => $ct,
    	            'last_tax_pay_amount' => $_POST['last_tax_pay_amount'],
    	            'year_of_last_tax_paid' => $_POST['year_of_last_tax_paid'],
    	            'owner_name' => $_POST['owner_name'],
    	            'guardian_name' => $_POST['guardian_name'],
    	            'gender' => $_POST['gender'],
    	            'mobile' => $_POST['mobile'],
    	            'address' => $_POST['address'],
    	            'colony' => $_POST['colony'],
    	            'pin_code' => $_POST['pin_code'],
    	            'area_of_plot_as_per_gis' => $_POST['area_of_plot_as_per_gis'],
    	            'area_of_building_footprint_as_per_gis' => $_POST['area_of_building_footprint_as_per_gis'],
    	            'latitude' => $_POST['latitude'],
    	            'longitude' => $_POST['longitude'],
    	            'is_property_available_in_bmc_record' => $_POST['is_property_available_in_bmc_record'],
    	            'open_plots' => $_POST['open_plots'],
    	            'new_pro_no' => $_POST['new_pro_no'],
    	            'DDN' => $_POST['DDN'],
    	            'ward_no' => $_POST['ward_no'],
    	            'zone_no' => $zoneId,//$_POST['zone_no'],
    	            'floor_SBA' => $SBA,
    	            'floor_type' => $floorType,
    	            'floor_wise_occup_type' => $occupType,
    	            'total_floors' => $totalFloor,
    	            'ARO_audit_status' => $_POST['ARO_audit_status'],
    	            'ARO_reason_reject' => $_POST['ARO_reason_reject'],
    	            'ARO_remark' => $_POST['ARO_remark'],
    	            'ARO_updated_at' => date('Y-m-d H:i:s')
    	        );
            }else{
                $fd = $this->upload->data();
                $fn = $fd['file_name'];
                $property = array(
    	            'parikshetra_number' => $pn,
    	            'road_type' => $rt,
    	            'const_type' => $ct,
    	            'last_tax_pay_amount' => $_POST['last_tax_pay_amount'],
    	            'year_of_last_tax_paid' => $_POST['year_of_last_tax_paid'],
    	            'owner_name' => $_POST['owner_name'],
    	            'guardian_name' => $_POST['guardian_name'],
    	            'gender' => $_POST['gender'],
    	            'mobile' => $_POST['mobile'],
    	            'address' => $_POST['address'],
    	            'colony' => $_POST['colony'],
    	            'pin_code' => $_POST['pin_code'],
    	            'area_of_plot_as_per_gis' => $_POST['area_of_plot_as_per_gis'],
    	            'area_of_building_footprint_as_per_gis' => $_POST['area_of_building_footprint_as_per_gis'],
    	            'latitude' => $_POST['latitude'],
    	            'longitude' => $_POST['longitude'],
    	            'is_property_available_in_bmc_record' => $_POST['is_property_available_in_bmc_record'],
    	            'open_plots' => $_POST['open_plots'],
    	            'new_pro_no' => $_POST['new_pro_no'],
    	            'DDN' => $_POST['DDN'],
    	            'ward_no' => $_POST['ward_no'],
    	            'zone_no' => $_POST['zone_no'],
    	            'floor_SBA' => $SBA,
    	            'floor_type' => $floorType,
    	            'floor_wise_occup_type' => $occupType,
    	            'total_floors' => $totalFloor,
    	            'property_image' => $fn,
    	            'ARO_audit_status' => $_POST['ARO_audit_status'],
    	            'ARO_reason_reject' => $_POST['ARO_reason_reject'],
    	            'ARO_remark' => $_POST['ARO_remark'],
    	            'ARO_updated_at' => date('Y-m-d H:i:s')
    	        );
            }
	        
    	        $update = $this->Ward_model->update($property, $id);
    	        if($update) {
    	            foreach($property as $key => $value){
    	                $old_value = $prop_old_data[0]->$key;
    	                $this->Ward_model->logChanges($id, $old_value, $value, 'Property', $key);
    	            }
    	            $data['success_msg'] =  'Property has been added successfully.';
                    redirect('Property/getData');
    	        }else{
    	            $data['error_msg'] = 'Some problems occured, please try again.';
    	            redirect('Property/getData');
    	        }
	        
	    }
	}
    
}