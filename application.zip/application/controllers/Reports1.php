<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Reports extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        error_reporting(E_ALL & ~E_NOTICE);
        // Load member model
        $this->load->model('Incentive_model');
        $this->load->model('Batch_model');
        $this->load->model('Reports_model');
        // Load form helper and library
        $this->load->helper('form');
        $this->load->library('form_validation');
        $this->load->library('upload');

        // Load pagination library
        $this->load->library('pagination');
    }

     public function incentive_tab()
    {
        $data = array();

        // Get messages from the session
        if ($this->session->userdata('success_msg')) {
            $data['success_msg'] = $this->session->userdata('success_msg');
            $this->session->unset_userdata('success_msg');
        }
        if ($this->session->userdata('error_msg')) {
            $data['error_msg'] = $this->session->userdata('error_msg');
            $this->session->unset_userdata('error_msg');
        }
        $data['incentives'] = $this->Incentive_model->getRows();
        $data['users'] = $this->Incentive_model->getAllUsers();

        // Load the list page view
        $this->load->view('template/header');
        $this->load->view('template/manageIncentive', $data);
        $this->load->view('template/footer');
    }
    
    public function ajaxFeeDetails($data) {
        echo $data;
    }
    
    public function ajaxReportData($sd, $ed, $roleId){
        if ($this->session->userdata('success_msg')) {
            $data['success_msg'] = $this->session->userdata('success_msg');
            $this->session->unset_userdata('success_msg');
        }
        if ($this->session->userdata('error_msg')) {
            $data['error_msg'] = $this->session->userdata('error_msg');
            $this->session->unset_userdata('error_msg');
        }
        // $sd = $_POST['SD'];
        // $ed = $_POST['ED'];
        // $roleId = $_POST['roleId'];
        
        $totalFeePending = $this->Reports_model->getTotalFPendingAjax($sd, $ed, $roleId);
        $sales = $this->Reports_model->getSalesAjax($sd, $ed, $roleId);
        $users = $this->Reports_model->getAllUsers();
        ?>
        <table class="table table-bordered table-striped">
                   <thead>
                       <tr>
                           <th>Total Fee Pending</th>
                           <th><?php echo $totalFeePending[0]->CPR ?></th>
                           <th>Total Fee Pending Without GST</th>
                           <th><?php echo round($totalFeePending[0]->CPR - $totalFeePending[0]->CPR*18/100, 0) ?></th>
                           <th>Total Fee Given</th>
                           <th><?php echo $totalFeePending[0]->CPG ?></th>
                           <th>Total Fee Given Without GST</th>
                           <th><?php echo round($totalFeePending[0]->CPG - $totalFeePending[0]->CPG*18/100, 0) ?></th>
                       </tr>
                   </thead>
               </table>
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>Sr.No</th>
                    <th>Student Name</th>
                    <th>Course Name</th>
                    <th>Mobile Number</th>
                    <!--<th>Email Id</th>-->
                    <th>Sales Representative</th>
                    <th>Last Transaction Date</th>
                    <th>Next Transaction Date</th>
                    <th>Total Fee Committed</th>
                    <th>Total Fee Given</th>
                    <th>Total Fee Given Without GST</th>
                    <th>Total Fee Remaining</th>
                    <th>Notes</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $sr = 1;
                  ?>
                  <?php if(!empty($sales)){ foreach($sales as $row){ ?>
                  <tr>
                    <td><?php echo $sr++; ?></td>
                    <td><?php echo ucfirst($this->Reports_model->getStudentName($row->studentId)[0]->studentName) ?></td>
                    <td><?php echo $this->Incentive_model->courseName($row->batchId)->courseName ?></td>
                    <td><?php echo $this->Reports_model->getStudentName($row->studentId)[0]->studentMobile." / ".$this->Reports_model->getStudentName($row->studentId)[0]->studentMobile2 ?></td>
                    <!--<td><?php //echo $this->Reports_model->getStudentName($row->studentId)[0]->studentEmail ?></td>-->
                    <td><?php echo $this->Reports_model->getSRUser($row->userId)[0]->userName ?></td>
                    <td><?php echo date('d-M-Y', strtotime($row->transactionDate)); ?></td>
                    <td><?php echo date('d-M-Y', strtotime($row->nextCommitedDate)); ?></td>
                    <td><?php echo $row->coursePriceCommited; ?></td>
                    <td><?php echo $this->Reports_model->getPriceById($row->studentId, $row->batchId)[0]->CPG ?></td>
                    <td><?php echo round($this->Reports_model->getPriceById($row->studentId, $row->batchId)[0]->CPG - $this->Reports_model->getPriceById($row->studentId, $row->batchId)[0]->CPG*18/100, 0) ?></td>
                    <td><?php echo $row->coursePriceCommited - $this->Reports_model->getPriceById($row->studentId, $row->batchId)[0]->CPG ?></td>
                    <td><?php echo $row->details; ?></td>
                  </tr>
                  <?php } } ?>
                </tbody>
              </table>
        <?php
    }
    
    public function reports_tab()
    {
        // Get messages from the session
        if ($this->session->userdata('success_msg')) {
            $data['success_msg'] = $this->session->userdata('success_msg');
            $this->session->unset_userdata('success_msg');
        }
        if ($this->session->userdata('error_msg')) {
            $data['error_msg'] = $this->session->userdata('error_msg');
            $this->session->unset_userdata('error_msg');
        }
        $data['totalFeePending'] = $this->Reports_model->getTotalFPending();
        $data['totalFeePendingRep'] = $this->Reports_model->getTotalFPendingRep();
        $data['sales'] = $this->Reports_model->getSales();
        $data['users'] = $this->Reports_model->getAllUsers();
        $data['title'] = "Reports";
        $this->load->view('template/header');
        $this->load->view('template/manageReports', $data);
        $this->load->view('template/footer');
    }
    
    public function gst_tab() {
        $data['title'] = 'GST Report';
        $data['gstData'] = $this->Incentive_model->getSalesData();
        $this->load->view('template/header');
        $this->load->view('template/Setting/GST_report', $data);
        $this->load->view('template/footer');
    }
    
    public function reports_staff_tab()
    {
        // Get messages from the session
        if ($this->session->userdata('success_msg')) {
            $data['success_msg'] = $this->session->userdata('success_msg');
            $this->session->unset_userdata('success_msg');
        }
        if ($this->session->userdata('error_msg')) {
            $data['error_msg'] = $this->session->userdata('error_msg');
            $this->session->unset_userdata('error_msg');
        }
        $data['totalFeePending'] = $this->Reports_model->getTotalFPending1();
        $data['totalFeePendingRep'] = $this->Reports_model->getTotalFPendingRep1();
        $data['sales'] = $this->Reports_model->getSales1();
        $data['users'] = $this->Reports_model->getAllUsers();
        $data['title'] = "Reports";
        $this->load->view('template/header');
        $this->load->view('template/manageReports', $data);
        $this->load->view('template/footer');
    }
    
    public function incentive_staff_tab()
    {
        $data = array();

        // Get messages from the session
        if ($this->session->userdata('success_msg')) {
            $data['success_msg'] = $this->session->userdata('success_msg');
            $this->session->unset_userdata('success_msg');
        }
        if ($this->session->userdata('error_msg')) {
            $data['error_msg'] = $this->session->userdata('error_msg');
            $this->session->unset_userdata('error_msg');
        }
        $data['incentives'] = $this->Incentive_model->getRows1();
        $data['users'] = $this->Incentive_model->getAllUsers11();

        // Load the list page view
        $this->load->view('template/header');
        $this->load->view('template/manageIncentive', $data);
        $this->load->view('template/footer');
    }
     public function incentive_team_tab()
    {
        $data = array();

        // Get messages from the session
        if ($this->session->userdata('success_msg')) {
            $data['success_msg'] = $this->session->userdata('success_msg');
            $this->session->unset_userdata('success_msg');
        }
        if ($this->session->userdata('error_msg')) {
            $data['error_msg'] = $this->session->userdata('error_msg');
            $this->session->unset_userdata('error_msg');
        }
        $data['incentives'] = $this->Incentive_model->getRows1();
        $data['users'] = $this->Incentive_model->getAllUsers12();

        // Load the list page view
        $this->load->view('template/header');
        $this->load->view('template/manageIncentive', $data);
        $this->load->view('template/footer');
    }
    public function incentive_fin_tab()
    {
        $data = array();

        // Get messages from the session
        if ($this->session->userdata('success_msg')) {
            $data['success_msg'] = $this->session->userdata('success_msg');
            $this->session->unset_userdata('success_msg');
        }
        if ($this->session->userdata('error_msg')) {
            $data['error_msg'] = $this->session->userdata('error_msg');
            $this->session->unset_userdata('error_msg');
        }
        $data['incentives'] = $this->Incentive_model->getRows1();
        $data['users'] = $this->Incentive_model->getAllUsers13();

        // Load the list page view
        $this->load->view('template/header');
        $this->load->view('template/manageIncentive', $data);
        $this->load->view('template/footer');
    }

   public function checkIncentive($id, $incentivePer)
    {
        $data = array();
        if(!empty($id)) {
            $data['sales'] = $this->Incentive_model->checkIncentive($id);
            $data['studentSales'] = $this->Incentive_model->studentList($id);
            $data['users'] = $this->Batch_model->getAllUsers();
            $data['IP'] = $incentivePer;
            $data['id'] = $id;
            $data['user'] = $this->Incentive_model->checkTL($id);
            $data['TLIncentive'] = $this->Incentive_model->incentiveForTL($id);
            
            $data['title'] = "Check Incentive";
            $this->load->view('template/header');
            $this->load->view('template/viewIncentive', $data);
            $this->load->view('template/footer');
        }
    }
    public function checkIncentive_staff($id, $incentivePer)
    {
        $data = array();
        if(!empty($id)) {
            $data['sales'] = $this->Incentive_model->checkIncentive($id);
            $data['studentSales'] = $this->Incentive_model->studentList($id);
            $data['users'] = $this->Batch_model->getAllUsers11();
            $data['IP'] = $incentivePer;
            $data['id'] = $id;
            $data['user'] = $this->Incentive_model->checkTL($id);
            $data['TLIncentive'] = $this->Incentive_model->incentiveForTL($id);
            $data['SSRIncentive1'] = $this->Incentive_model->incentiveForSSR($id);
            $data['title'] = "Check Incentive";
            $this->load->view('template/header');
            $this->load->view('template/viewIncentive', $data);
            $this->load->view('template/footer');
        }
    }

    public function checkIncentive_team($id, $incentivePer)
    {
        $data = array();
        if(!empty($id)) {
            $data['sales'] = $this->Incentive_model->checkIncentive($id);
            $data['studentSales'] = $this->Incentive_model->studentList($id);
            $data['users'] = $this->Batch_model->getAllUsers12();
            $data['IP'] = $incentivePer;
            $data['id'] = $id;
            $data['user'] = $this->Incentive_model->checkTL($id);
            $data['TLIncentive'] = $this->Incentive_model->incentiveForTL($id);
            $data['SSRIncentive1'] = $this->Incentive_model->incentiveForSSR($id);
            $data['title'] = "Check Incentive";
            $this->load->view('template/header');
            $this->load->view('template/viewIncentive', $data);
            $this->load->view('template/footer');
        }
    }

    public function checkIncentive_fin($id, $incentivePer)
    {
        $data = array();
        if(!empty($id)) {
            $data['sales'] = $this->Incentive_model->checkIncentive($id);
            $data['studentSales'] = $this->Incentive_model->studentList($id);
            $data['users'] = $this->Batch_model->getAllUsers13();
            $data['IP'] = $incentivePer;
            $data['id'] = $id;
            $data['user'] = $this->Incentive_model->checkTL($id);
            $data['TLIncentive'] = $this->Incentive_model->incentiveForTL($id);
            $data['SSRIncentive1'] = $this->Incentive_model->incentiveForSSR($id);
            $data['title'] = "Check Incentive";
            $this->load->view('template/header');
            $this->load->view('template/viewIncentive', $data);
            $this->load->view('template/footer');
        }
    }

    public function ajaxTableData($id, $incentivePer) {
        $startDate = $_POST['SD'];
        $endDate = $_POST['ED'];
        $sales = $this->Incentive_model->checkIncentiveAjax($startDate, $endDate, $id);
        $student = $this->Incentive_model->getDataAjax($startDate, $endDate, $id);
        $studentSales = $this->Incentive_model->studentList($id);
        $users = $this->Batch_model->getAllUsers();
        $IP = $incentivePer;
        $id = $id;
        $user = $this->Incentive_model->checkTL($id);
        //$TLIncentive = $this->Incentive_model->incentiveForTL($id);
        $TLIncentive = $this->Incentive_model->incentiveForTLAjax($startDate, $endDate, $id);
        $SSRIncentive = $this->Incentive_model->incentiveForSSRAjax($startDate, $endDate, $id);
        ?>
        <table class="table table-bordered table-striped table-responsive">
                  <center><tr>
                    <td><p class="card-text"><b>Sales Committed : </b>
                <?php echo $sales[0]->coursePriceCommited; ?>
                </p></td>
                    <td><p class="card-text"><b>Incentive Commited : </b><?php echo $sales[0]->coursePriceCommited * $IP; ?></p></td>
                    <td><p class="card-text"><b>Amount Received : </b><?php echo $sales[0]->couesePriceGive; ?></p></td>
                    <td><p class="card-text"><b>Incentive Garunated : </b> <?php echo $sales[0]->couesePriceGive * $IP + $TLIncentive[0]->ITL + $SSRIncentive[0]->SSR; ?></p></td>
                    <td>
                        <p class="card-text"><b>Amount Remaining : </b> <?php echo $sales[0]->coursePriceRemain; ?></p></td>
                        <td><p class="card-text"><b>Incentive Forcast : </b> <?php echo $sales[0]->coursePriceRemain * $IP ?></p>
                    </td>
                  </tr></center>
                </table>
        <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>Sr.No</th>
                    <th>Student Name</th>
                    <th>Course Fees</th>
                    <th>Fees Given</th>
                    <th>Fees Remaining</th>
                    <th>Incentive Amount / TL Incentive Amount / Second SR</th>
                    <th>Transaction Date</th>
                    <th>Next Commited Transaction Date</th>
                    <th>Sales Representative</th>
                    <!--<th>Action</th>-->
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $sr = 1;
                  ?>
                  <?php if(!empty($student)){ foreach($student as $row){ ?>
                  <tr>
                    <td><?php echo $sr++; ?></td>
                    <td><?php echo ucfirst($this->Batch_model->studentData(array('studentId' => $row->studentId))['studentName']); ?></td>
                    <td><?php echo $row->coursePriceCommited ?></td>
                    <td><?php echo $row->couesePriceGiven ?></td>
                    <td><?php echo $row->coursePriceRemain ?></td>
                    <td>
                        <?php
                            if($row->userId == $id) {
                                echo round($row->courseIncentive, 2)." ( Incentive )";
                            }else if($row->TLId == $id){
                                echo round($row->courseIncentiveTeam, 2)." ( Team Lead Incentive ) ";
                            }else{
                                echo round($row->incentiveAmtSR, 2)." ( Second SR Incentive )";
                            }
                        ?>
                    </td>
                    <td><?php echo date('d-M-Y', strtotime($row->transactionDate)) ?></td>
                    <td><?php echo date('d-M-Y', strtotime($row->nextCommitedDate)) ?></td>
                    <td><?php foreach ($users as $row3) {
                                                        if ($row3->userId == $row->userId) { ?>
                                                            <?php echo ucfirst($row3->userName); ?>
                                                    <?php }
                                                    } ?></td>
                  </tr>
                  <?php } } ?>
                </tbody>
              </table>
        <?php
    }
    public function view($id)
    {
        $data = array();

        // Check whether batch id is not empty
        if (!empty($id)) {
            $data['incentive'] = $this->Incentive_model->getRows(array('incentiveId' => $id));
            $data['title']  = 'Incentive Details';
            $data['users'] = $this->Incentive_model->getAllUsers();
            $data['leads'] = $this->Incentive_model->getAllLeads();
            // Load the details page view
            $this->load->view('template/header');
            $this->load->view('template/viewIncentive', $data);
            $this->load->view('template/footer');
        } else {
            redirect('Incentive/incentive_tab');
        }
    }

    public function add()
    {

        $data = array();
        $incentiveData = array();
        $data['batches'] = $this->Incentive_model->getAllBatches();
        $data['users'] = $this->Incentive_model->getAllUsers();
        $data['students'] = $this->Incentive_model->getAllStudents();
        $data['leads'] = $this->Incentive_model->getAllLeads();
        // If add request is submitted
        if ($this->input->post('incentiveSubmit')) {

            // Form field validation rules
            $this->form_validation->set_rules('userId', 'Sale representative', 'required');
            $this->form_validation->set_rules('roleType', 'role type', 'required|trim');

            // Prepare batch data
            $incentiveData = array(
                'userId' => $this->input->post('userId'),
                'batchId' => $this->input->post('batchId'),
                'studentId' => $this->input->post('studentId'),
                'courseCommited' => $this->input->post('courseCommited'),
                'courseDiscount' => $this->input->post('courseDiscount'),
                'actualCourseFee' => $this->input->post('actualCourseFee'),
                'coursePriceGiven' => $this->input->post('coursePriceGiven'),
                'coursePriceRemain' => $this->input->post('coursePriceRemain'),
                'transDate' => $this->input->post('transDate'),
                'nextDate' => $this->input->post('nextDate'),
                'roleType' => $this->input->post('roleType'),
                'incecntivePer' => $this->input->post('incecntivePer'),
                'courseIncentive' => $this->input->post('courseIncentive'),
                'checked' => $this->input->post('checked'),
                'teamLeadName' => $this->input->post('teamLeadName'),
                'teamLeadPer' => $this->input->post('teamLeadPer'),
                'teamLeadIncentive' => $this->input->post('teamLeadIncentive'),
                'createdDate' => $this->input->post('createdDate')
            );
        }
        // Validate submitted form data
        if ($this->form_validation->run() == true) {
            // Insert batch data
            $insert = $this->Incentive_model->insert($incentiveData);
            if ($insert) {
                $this->session->set_userdata('success_msg', 'Incentive has been added successfully.');
                redirect('Incentive/incentive_tab');
            } else {
                $data['error_msg'] = 'Some problems occured, please try again.';
            }
        }

        $data['incentive'] = $incentiveData;

        // Load the add page view
        $this->load->view('template/header');
        $this->load->view('template/addIncentive', $data);
        $this->load->view('template/footer');
    }

    public function edit($id)
    {
        $data = array();
        // Get batch data
        $incentiveData = $this->Incentive_model->getRows(array('incentiveId' => $id));
        $data['batches'] = $this->Incentive_model->getAllBatches();
        $data['users'] = $this->Incentive_model->getAllUsers();
        $data['students'] = $this->Incentive_model->getAllStudents();
        $data['leads'] = $this->Incentive_model->getAllLeads();
        // If update request is submitted
        if ($this->input->post('incentiveSubmit')) {

            //print_r($_POST);

            // Form field validation rules
            /*  $this->form_validation->set_rules('userId','Sale representative','required');
            $this->form_validation->set_rules('roleType', 'role type', 'required|trim');
            $this->form_validation->set_rules('incecntivePer', 'incentive percentage', 'required');
             $this->form_validation->set_rules('teamLeadName', 'team lead', 'required');
              $this->form_validation->set_rules('teamLeadPer', 'incentive percentage', 'required');*/
            // Prepare batch data
            $incentiveData = array(
                //'saleId'=> $id,   
                'userId' => $this->input->post('userId'),
                'batchId' => $this->input->post('batchId'),
                'studentId' => $this->input->post('studentId'),
                'courseCommited' => $this->input->post('courseCommited'),
                'courseDiscount' => $this->input->post('courseDiscount'),
                'actualCourseFee' => $this->input->post('actualCourseFee'),
                'coursePriceGiven' => $this->input->post('coursePriceGiven'),
                'coursePriceRemain' => $this->input->post('coursePriceRemain'),
                'transDate' => $this->input->post('transDate'),
                'nextDate' => $this->input->post('nextDate'),
                'roleType' => $this->input->post('roleType'),
                'incecntivePer' => $this->input->post('incecntivePer'),
                'courseIncentive' => $this->input->post('courseIncentive'),
                'checked' => $this->input->post('checked'),
                'teamLeadName' => $this->input->post('teamLeadName'),
                'teamLeadPer' => $this->input->post('teamLeadPer'),
                'teamLeadIncentive' => $this->input->post('teamLeadIncentive'),
                'updatedDate' => $this->input->post('updatedDate')
            );


            // Validate submitted form data
            if ($this->form_validation->run() == false) {
                // Update batch data
                //print_r($saleData);
                $update = $this->Incentive_model->update($incentiveData, $id);

                if ($update) {
                    $this->session->set_userdata('success_msg', 'Incentive has been updated successfully.');
                    redirect('Incentive/incentive_tab');
                } else {
                    $data['error_msg'] = 'Some problems occured, please try again.';
                }
            }
        }

        $data['incentive'] = $incentiveData;

        // Load the edit page view
        $this->load->view('template/header');
        $this->load->view('template/editIncentive', $data);
        $this->load->view('template/footer');
    }

    public function delete($id)
    {
        // Check whether batch id is not empty
        if ($id) {
            // Delete batch
            $delete = $this->Incentive_model->delete($id);

            if ($delete) {
                $this->session->set_userdata('success_msg', 'Incentive has been removed successfully.');
            } else {
                $this->session->set_userdata('error_msg', 'Some problems occured, please try again.');
            }
        }

        // Redirect to the list page
        redirect('Incentive/incentive_tab');
    }
}
