<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function __construct(){
		parent::__construct();
		error_reporting(E_ALL & ~E_NOTICE);
		if (!$this->session->userdata('logged_in')){
			redirect('Login');
		}
		$this->load->model(['Admin_model', 'Incentive_model', 'Batch_model', 'Crm_leads_model', 'Property_model', 'Ward_model']);
	}

	public function index()
	{
		if($this->session->userdata('roleId') === '1')
		{
			$this->load->view('template/header');
			$this->load->view('template/dashboard');
			$this->load->view('template/footer');
			return;
		}

		echo "Access Denied!"; 
	}
         
	public function proptax()
	{
		$data = [];
		$data['totalProperty'] = $this->Property_model->totalProperty();
		$data['approvedProperty'] = $this->Property_model->approvedProperty();
		$data['rejectedProperty'] = $this->Property_model->rejectedProperty();
		$data['property'] = $this->Property_model->getProperty();
		$this->load->view('template/includes/header');
		$this->load->view('template/homePage/dashboard', $data);
		$this->load->view('template/includes/footer');
	}
	
	public function MDDash() {
	    $data = [];
	    $data['MDData'] = $this->Property_model->getMDData();
	    $data['totalProperty'] = $this->Property_model->totalProperty();
		$data['approvedProperty'] = $this->Property_model->approvedProperty();
		$data['rejectedProperty'] = $this->Property_model->rejectedProperty();
		$data['property'] = $this->Property_model->getProperty();
	    $this->load->view('template/includes/header');
	    $this->load->view('template/homePage/mdDashboard', $data);
	    $this->load->view('template/includes/footer');
	}
}