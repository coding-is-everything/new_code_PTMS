<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Staff extends CI_Controller {

public function __construct(){
		parent::__construct();
		$this->load->model(['Admin_model', 'Incentive_model', 'Batch_model', 'Crm_leads_model', 'Property_model', 'Ward_model']);
		if($this->session->userdata('logged_in')!= TRUE){
			redirect('Login');
		}
	}
	public function index()
	{
		if($this->session->userdata('roleType') === 'ARI')
		{
		    $wardId = $this->Property_model->getWardId($this->session->userdata('userId'));
		    $data = array();
		    $data['totalProperty'] = $this->Property_model->totalPropertyARI($wardId);
    		$data['approvedProperty'] = $this->Property_model->approvedPropertyARI($wardId);
    		$data['rejectedProperty'] = $this->Property_model->rejectedPropertyARI($wardId);
    		$data['property'] = $this->Property_model->getPropertyARI($wardId);
		    $data['ARI'] = $this->Ward_model->getARIData($this->session->userdata('userId'));
		  //  print_r($this->session->userdata());
    		$this->load->view('template/includes/header');	
    		$this->load->view('template/homePage/dashboard', $data);
    		$this->load->view('template/includes/footer');
		}
		else{
			echo "Access Denied!"; 
		}
	}


}