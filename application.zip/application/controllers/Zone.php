<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Zone extends CI_Controller {

public function __construct(){
		parent::__construct();
		if($this->session->userdata('logged_in')!= TRUE){
			redirect('Login');
		}
		$this->load->model('Ward_model');
	}
	public function index()
	{
	    $data = array();
	    $data['wardDetails'] = $this->Ward_model->getAllZones();
		$this->load->view('template/includes/header');
		$this->load->view('template/Zone/manageZone', $data);
		$this->load->view('template/includes/footer');
	}
	
	public function view($id){
	    if(!empty($id)){
    	    $data = array();
    	    $data['zone'] = $this->Ward_model->getZoneDetail($id);
    	    $this->load->view('template/includes/header');
    	    $this->load->view('template/Zone/viewZone', $data);
    	    $this->load->view('template/includes/footer');
	    }
	}
	
	public function delete($id){
        // Check whether course id is not empty
        if($id){
            // Delete course
            // $this->db->where('id', $id);
            // $this->db->delete('zone_table');
            $zc_table = $this->db->update('zone_table', array('deleteStatus' => 1, 'deletedAt' => date('Y-m-d H:i:s')), array('id' => $id));
            if($zc_table){
                $this->session->set_userdata('success_msg', 'Zone has been removed successfully.');
            }else{
                $this->session->set_userdata('error_msg', 'Some problems occured, please try again.');
            }
        }
        
        // Redirect to the list page
        redirect('zone/index');
    }


}